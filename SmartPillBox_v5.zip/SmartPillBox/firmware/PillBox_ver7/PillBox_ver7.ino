/*
  약속 스마트 약통 ver7 — 앱 연동 펌웨어
  보드: Arduino UNO R3 / RTC: DS1302 / 서보: SG90 x 6 / 피에조 부저
  라이브러리: "Rtc by Makuna", "Servo" (Arduino IDE 라이브러리 매니저에서 설치)

  배선 (ver6과 동일)
    DS1302  DAT(IO)=D4, CLK(SCLK)=D5, RST(CE)=D2, VCC=5V, GND=GND
    서보 1..6 신호 = D3 / D6 / D7 / D8 / D10 / D11
    부저 = D9 / GND

  안전 원칙
    1. 약통이 스스로 RTC 시각을 확인하고 판단한다. 앱은 '설정'만 보낸다.
       → USB/블루투스 연결이 끊겨도 예약은 계속 동작하고, 임의로 열리지 않는다.
    2. 예약 시각(통과 순간)에 '그 칸만' 연다. 다른 칸은 닫힘을 유지한다.
    3. 같은 복용 회차는 한 번만 자동으로 연다(firedDay). 앱의 '다시 열기'는
       허용 시간(grace) 안에서 회차당 1번만, 복용 완료 확인 후에는 불가.
    4. 지나간 예약은 뒤늦게 열지 않는다. 시계가 2초 넘게 점프하면 건너뛴다.
    5. 서보는 한 번에 하나씩만 움직인다(UNO 5V 전원 보호). 닫기 요청이 열기보다 우선.
    6. 움직이는 도중 전원이 끊기면(연속회전형) 위치를 알 수 없으므로 '위치 복구 필요'로
       전환하고 모터를 움직이지 않는다.

  통신: 9600bps, 줄바꿈(\n) 단위 텍스트. 시리얼 모니터에서 직접 입력해 시험할 수 있다.
    명령 앞에 "#<번호> "를 붙이면 응답이 "@<번호> "로 시작한다(앱이 사용).
    같은 번호의 명령이 다시 오면 다시 실행하지 않고 이전 결과만 돌려준다(중복 명령 방지).
    자세한 명령 목록은 docs/PROTOCOL.md 참고.
*/
#include <ThreeWire.h>
#include <RtcDS1302.h>
#include <Servo.h>
#include <EEPROM.h>
#include <string.h>
#include <stdlib.h>

#define FW_VERSION 7

// ───────── 서보 종류 선택 ─────────
// 1 = 360° 연속회전형 SG90 (ver6과 같은 방식: 정해진 시간만큼 회전)
// 0 = 180° 일반 SG90 (각도 지정 방식: 전원이 다시 들어와도 닫힘 각도로 복귀 가능)
#ifndef SERVO_CONTINUOUS
#define SERVO_CONTINUOUS 1
#endif

// ───────── 블루투스 (HC-05 / HC-06) 선택 ─────────
// 0 = USB만 사용 (기본) / 1 = USB + 블루투스 모듈 동시 사용
// 배선: 모듈 TXD → A0, 모듈 RXD ← A1 (1kΩ/2kΩ 분압으로 3.3V), VCC=5V, GND=GND. 모듈 속도 9600.
#ifndef USE_BT
#define USE_BT 0
#endif

#if USE_BT
#include <SoftwareSerial.h>
SoftwareSerial bt(A0, A1);   // RX, TX
bool btEcho = true;
// 모든 출력을 USB와 블루투스로 함께 보냄
class DualOut : public Print {
 public:
  size_t write(uint8_t c) override {
    Serial.write(c);
    if (btEcho) bt.write(c);
    return 1;
  }
};
DualOut OUT;
#else
#define OUT Serial
#endif

const uint8_t SLOTS = 6;
const uint8_t SERVO_PINS[SLOTS] = {3, 6, 7, 8, 10, 11};
const uint8_t BUZZER_PIN = 9;
ThreeWire rtcWire(4, 5, 2);
RtcDS1302<ThreeWire> rtc(rtcWire);
Servo motors[SLOTS];

#if SERVO_CONTINUOUS
// 빈 기구로 칸마다 보정하세요. (ver6 초기값)
const uint16_t OPEN_US[SLOTS]      = {1350, 1350, 1350, 1350, 1350, 1350};
const uint16_t CLOSE_US[SLOTS]     = {1650, 1650, 1650, 1650, 1650, 1650};
const uint16_t OPEN_RUN_MS[SLOTS]  = {200, 200, 200, 200, 200, 200};
const uint16_t CLOSE_RUN_MS[SLOTS] = {200, 200, 200, 200, 200, 200};
#else
const uint8_t OPEN_DEG[SLOTS]  = {90, 90, 90, 90, 90, 90};
const uint8_t CLOSE_DEG[SLOTS] = {0, 0, 0, 0, 0, 0};
const uint16_t MOVE_MS = 700;
#endif

const uint16_t REFILL_HOLD_SEC = 180;   // 보충용으로 연 칸은 3분 뒤 자동으로 닫음
const uint8_t MAX_ENTRIES = 24;
const uint8_t NONE = 255;

// ───────── 데이터 구조 ─────────
struct Entry {          // 8바이트
  uint8_t slot;         // 1..6
  uint8_t hour, minute;
  uint8_t days;         // bit0=월 … bit6=일
  uint16_t startDay;    // 2000-01-01부터 날짜 수 (이 날 포함)
  uint16_t endDay;      // 이 날 포함, 65535 = 종료일 없음
};
struct Config {
  uint8_t count;
  uint8_t graceMin;     // '다시 열기' 허용 시간(분)
  uint16_t holdSec;     // 자동으로 연 칸을 열어두는 시간(초)
  Entry e[MAX_ENTRIES];
};
struct DoseState { uint16_t firedDay, takenDay, reopenDay; };
struct LogEv { uint16_t seq; uint8_t type; uint8_t arg; uint32_t t; };
struct LineBuf { char b[72]; uint8_t n; bool over; };   // 수신 줄 버퍼 (USB / 블루투스 각각)

enum Phase : uint8_t { CLOSED, Q_OPEN, OPENING, OPEN, Q_CLOSE, CLOSING };
enum Kind : uint8_t { DOSE, REFILL };
enum EvType : uint8_t {
  EV_BOOT = 1, EV_TIME_SET, EV_SCHED_SAVED, EV_DOSE_OPEN, EV_AUTO_CLOSE, EV_REOPEN,
  EV_TAKEN, EV_REFILL_OPEN, EV_SLOT_CLOSE, EV_STOP, EV_RECOVERY_NEEDED, EV_RECOVERED,
  EV_CLOCK_GAP, EV_CLOCK_INVALID, EV_STORAGE_ERROR, EV_DOSE_BLOCKED, EV_SLOT_CLOSED
};

Config cfg, stage;
bool stageOpen = false;
DoseState dose[MAX_ENTRIES];

Phase phase[SLOTS];
Kind kind[SLOTS];
bool reopenAfter[SLOTS];
unsigned long openAt[SLOTS];
uint8_t activeSlot = NONE;
unsigned long motionAt = 0;
uint8_t openMask = 0, movingMask = 0;
bool recovery = false, clockReady = false, baselineValid = false;
uint32_t previousSecond = 0;
unsigned long lastPoll = 0, lastStatus = 0, alarmAt = 0;
bool alarmActive = false, sounding = false;
uint16_t logSeq = 0;
uint32_t cfgSeq = 0, stSeq = 0;
uint8_t cfgBank = NONE, stBank = NONE;

LineBuf usbBuf = {{0}, 0, false};
#if USE_BT
LineBuf btBuf = {{0}, 0, false};
#endif
uint16_t lastId = 0;
const char *lastCode = 0;
long lastVal = 0;
bool lastHasVal = false;

// ───────── EEPROM 배치 ─────────
const int EE_MAGIC = 0;       // 'P','B','0','7'
const int EE_OPEN = 4, EE_MOVING = 5, EE_RECOVERY = 6;
const int EE_CFG = 8, CFG_BANK = 208;     // 2뱅크 = 8..423
const int EE_ST = 424, ST_BANK = 160;     // 2뱅크 = 424..743
const int EE_LOG = 744, LOG_N = 24;       // 24 x 8 = 744..935
const uint8_t REC_MARK = 0xB7;
const uint8_t MAGIC[4] = {'P', 'B', '0', '7'};

void motorTick();
void serviceMotors();
void logEvent(uint8_t type, uint8_t arg);

// ───────── 공통 유틸 ─────────
uint16_t crcByte(uint16_t c, uint8_t b) {
  c ^= (uint16_t)b << 8;
  for (uint8_t j = 0; j < 8; j++) c = (c & 0x8000) ? (c << 1) ^ 0x1021 : c << 1;
  return c;
}
uint8_t weekdayOf(uint16_t day) { return (day + 5) % 7; }  // 2000-01-01 = 토요일, 월=0
uint32_t todSec(const Entry &e) { return (uint32_t)e.hour * 3600UL + (uint32_t)e.minute * 60UL; }
bool activeOn(const Entry &e, uint16_t day) {
  return (e.days & (1 << weekdayOf(day))) && day >= e.startDay && day <= e.endDay;
}

// 레코드: [0]=표시(마지막에 기록) [1]=종류 [2..5]=순번 [payload] [CRC 2바이트]
uint16_t recCrc(uint8_t type, uint32_t seq, const uint8_t *p, uint16_t n) {
  uint16_t c = 0xFFFF;
  c = crcByte(c, type);
  for (uint8_t i = 0; i < 4; i++) c = crcByte(c, (seq >> (8 * i)) & 255);
  for (uint16_t i = 0; i < n; i++) c = crcByte(c, p[i]);
  return c;
}
bool recValid(int a, uint8_t type, uint16_t n, uint32_t &seq) {
  if (EEPROM.read(a) != REC_MARK || EEPROM.read(a + 1) != type) return false;
  seq = 0;
  for (uint8_t i = 0; i < 4; i++) seq |= (uint32_t)EEPROM.read(a + 2 + i) << (8 * i);
  uint16_t c = 0xFFFF;
  c = crcByte(c, type);
  for (uint8_t i = 0; i < 4; i++) c = crcByte(c, (seq >> (8 * i)) & 255);
  for (uint16_t i = 0; i < n; i++) c = crcByte(c, EEPROM.read(a + 6 + i));
  uint16_t s = EEPROM.read(a + 6 + n) | ((uint16_t)EEPROM.read(a + 7 + n) << 8);
  return c == s;
}
bool readRec(int base, int bankSize, uint8_t type, void *out, uint16_t n, uint32_t &seq, uint8_t &bank) {
  bank = NONE;
  for (uint8_t b = 0; b < 2; b++) {
    uint32_t s;
    if (!recValid(base + bankSize * b, type, n, s)) continue;
    if (bank != NONE && (int32_t)(s - seq) <= 0) continue;
    seq = s; bank = b;
  }
  if (bank == NONE) return false;
  uint8_t *p = (uint8_t *)out;
  int a = base + bankSize * bank + 6;
  for (uint16_t i = 0; i < n; i++) p[i] = EEPROM.read(a + i);
  return true;
}
// 사용하지 않는 뱅크에 쓰고 검증한 뒤에만 교체 → 쓰는 도중 전원이 끊겨도 이전 값이 남는다.
bool writeRec(int base, int bankSize, uint8_t type, const void *data, uint16_t n, uint32_t &seq, uint8_t &bank) {
  const uint8_t *p = (const uint8_t *)data;
  uint8_t b = (bank == 0) ? 1 : 0;
  int a = base + bankSize * b;
  uint32_t ns = seq + 1;
  EEPROM.update(a, 0);
  EEPROM.update(a + 1, type);
  for (uint8_t i = 0; i < 4; i++) EEPROM.update(a + 2 + i, (ns >> (8 * i)) & 255);
  for (uint16_t i = 0; i < n; i++) { EEPROM.update(a + 6 + i, p[i]); if ((i & 7) == 0) motorTick(); }
  uint16_t c = recCrc(type, ns, p, n);
  EEPROM.update(a + 6 + n, c & 255);
  EEPROM.update(a + 7 + n, c >> 8);
  EEPROM.update(a, REC_MARK);
  uint32_t chk;
  if (!recValid(a, type, n, chk) || chk != ns) return false;
  for (uint16_t i = 0; i < n; i++) if (EEPROM.read(a + 6 + i) != p[i]) return false;
  seq = ns; bank = b;
  return true;
}
bool saveDose() {
  bool ok = writeRec(EE_ST, ST_BANK, 2, dose, sizeof(dose), stSeq, stBank);
  if (!ok) logEvent(EV_STORAGE_ERROR, 2);
  return ok;
}

// Fletcher-16 체크섬 — 앱과 같은 방식으로 계산해 설정 일치 여부를 확인한다.
uint16_t cfgChecksum(const Config &c) {
  uint16_t s1 = 0, s2 = 0;
#define FL(x) do { s1 = (s1 + (uint8_t)(x)) % 255; s2 = (s2 + s1) % 255; } while (0)
  FL(c.count); FL(c.holdSec & 255); FL(c.holdSec >> 8); FL(c.graceMin);
  for (uint8_t i = 0; i < c.count; i++) {
    const Entry &e = c.e[i];
    FL(e.slot); FL(e.hour); FL(e.minute); FL(e.days);
    FL(e.startDay & 255); FL(e.startDay >> 8); FL(e.endDay & 255); FL(e.endDay >> 8);
  }
#undef FL
  return (s2 << 8) | s1;
}

// ───────── 이벤트 기록 (EEPROM 링 버퍼, 재연결 후 앱이 LOG 명령으로 가져감) ─────────
void readLogAt(uint8_t idx, LogEv &ev) {
  uint8_t *p = (uint8_t *)&ev;
  for (uint8_t i = 0; i < sizeof(LogEv); i++) p[i] = EEPROM.read(EE_LOG + idx * 8 + i);
}
void printEv(const LogEv &ev) {
  OUT.print(F("EV ")); OUT.print(ev.seq); OUT.print(' ');
  OUT.print(ev.type); OUT.print(' '); OUT.print(ev.arg); OUT.print(' ');
  OUT.println(ev.t);
}
bool validClock();
void logEvent(uint8_t type, uint8_t arg) {
  LogEv ev;
  ev.seq = ++logSeq;
  if (logSeq >= 65000) logSeq = 0;   // 사실상 도달하지 않음(하루 10건 기준 17년)
  ev.type = type; ev.arg = arg;
  ev.t = validClock() ? rtc.GetDateTime().TotalSeconds() : 0;
  int a = EE_LOG + (ev.seq % LOG_N) * 8;
  EEPROM.update(a, 0xFF); EEPROM.update(a + 1, 0xFF);     // 먼저 무효화
  const uint8_t *p = (const uint8_t *)&ev;
  for (uint8_t i = 2; i < 8; i++) { EEPROM.update(a + i, p[i]); motorTick(); }
  EEPROM.update(a, p[0]); EEPROM.update(a + 1, p[1]);     // 순번을 마지막에 기록
  printEv(ev);
}
void loadLogSeq() {
  logSeq = 0;
  for (uint8_t i = 0; i < LOG_N; i++) {
    LogEv ev; readLogAt(i, ev);
    if (ev.seq != 0xFFFF && ev.seq != 0 && ev.seq > logSeq) logSeq = ev.seq;
  }
}

// ───────── 시계 ─────────
bool hasClockMarker() {
  for (uint8_t i = 0; i < 4; i++) if (rtc.GetMemory(i) != MAGIC[i]) return false;
  return true;
}
bool validClock() { return clockReady && rtc.GetIsRunning() && rtc.GetDateTime().IsValid(); }
void resetBaseline() {
  baselineValid = false;
  if (validClock()) { previousSecond = rtc.GetDateTime().TotalSeconds(); baselineValid = true; }
}

// ───────── 모터 ─────────
void saveMasks() { EEPROM.update(EE_OPEN, openMask); EEPROM.update(EE_MOVING, movingMask); }
void detachMotor(uint8_t i) {
  if (motors[i].attached()) motors[i].detach();
  pinMode(SERVO_PINS[i], OUTPUT);
  digitalWrite(SERVO_PINS[i], LOW);
}
void startMotion(uint8_t i, bool open) {
  movingMask |= 1 << i; saveMasks();      // 움직이기 전에 '이동 중' 표시
  phase[i] = open ? OPENING : CLOSING;
  activeSlot = i; motionAt = millis();
#if SERVO_CONTINUOUS
  uint16_t us = open ? OPEN_US[i] : CLOSE_US[i];
  motors[i].writeMicroseconds(us);        // 펄스를 먼저 정한 뒤 attach → 중립 펄스 없음
  motors[i].attach(SERVO_PINS[i]);
#else
  motors[i].write(open ? OPEN_DEG[i] : CLOSE_DEG[i]);
  motors[i].attach(SERVO_PINS[i]);
#endif
}
unsigned long runMs(uint8_t i, bool open) {
#if SERVO_CONTINUOUS
  return open ? OPEN_RUN_MS[i] : CLOSE_RUN_MS[i];
#else
  (void)i; (void)open; return MOVE_MS;
#endif
}
// 회전 종료만 처리(EEPROM 기록 중에도 호출됨)
void motorTick() {
  if (activeSlot == NONE) return;
  uint8_t i = activeSlot;
  bool opening = phase[i] == OPENING;
  if (millis() - motionAt < runMs(i, opening)) return;
  detachMotor(i);
  activeSlot = NONE;
  movingMask &= ~(1 << i);
  if (opening) { phase[i] = OPEN; openAt[i] = millis(); openMask |= 1 << i; }
  else {
    openMask &= ~(1 << i);
    phase[i] = reopenAfter[i] ? Q_OPEN : CLOSED;
    reopenAfter[i] = false;
  }
  saveMasks();
}
void requestOpen(uint8_t i, Kind k) {
  kind[i] = k;
  switch (phase[i]) {
    case CLOSED: phase[i] = Q_OPEN; break;
    case OPEN: openAt[i] = millis(); break;               // 이미 열려 있으면 대기 시간만 갱신
    case Q_CLOSE: phase[i] = OPEN; openAt[i] = millis(); break;
    case CLOSING: reopenAfter[i] = true; break;
    default: break;                                       // Q_OPEN / OPENING: 이미 진행 중
  }
}
void requestClose(uint8_t i) {
  reopenAfter[i] = false;
  if (phase[i] == OPEN) phase[i] = Q_CLOSE;
  else if (phase[i] == Q_OPEN) phase[i] = CLOSED;        // 아직 안 열었으면 취소
}
void serviceMotors() {
  motorTick();
  unsigned long ms = millis();
  for (uint8_t i = 0; i < SLOTS; i++) {
    if (phase[i] != OPEN) continue;
    unsigned long hold = (kind[i] == REFILL ? REFILL_HOLD_SEC : cfg.holdSec) * 1000UL;
    if (ms - openAt[i] >= hold) { phase[i] = Q_CLOSE; logEvent(EV_AUTO_CLOSE, i + 1); }
  }
  bool busy = false;
  for (uint8_t i = 0; i < SLOTS; i++) if (phase[i] == OPEN || phase[i] == Q_OPEN || phase[i] == OPENING) busy = true;
  if (!busy) alarmActive = false;
  bool on = alarmActive && (ms - alarmAt < 30000UL) && ((ms - alarmAt) % 1000UL) < 500;
  if (on != sounding) { sounding = on; if (on) tone(BUZZER_PIN, 2000); else noTone(BUZZER_PIN); }
  if (recovery || activeSlot != NONE) return;
  for (uint8_t i = 0; i < SLOTS; i++) if (phase[i] == Q_CLOSE) { startMotion(i, false); return; }   // 닫기 우선
  for (uint8_t i = 0; i < SLOTS; i++) if (phase[i] == Q_OPEN) { startMotion(i, true); return; }
}

// ───────── 예약 판단 ─────────
void fireEntry(uint8_t idx, uint16_t today) {
  dose[idx].firedDay = today;
  uint8_t s = cfg.e[idx].slot - 1;
  if (recovery) { saveDose(); logEvent(EV_DOSE_BLOCKED, s + 1); return; }
  bool already = (phase[s] == OPEN || phase[s] == Q_OPEN || phase[s] == OPENING) && kind[s] == DOSE;
  requestOpen(s, DOSE);
  saveDose();
  alarmActive = true; alarmAt = millis();
  if (!already) logEvent(EV_DOSE_OPEN, s + 1);
}
void checkSchedule() {
  if (!validClock()) { if (baselineValid) logEvent(EV_CLOCK_INVALID, 0); baselineValid = false; return; }
  uint32_t now = rtc.GetDateTime().TotalSeconds();
  if (!baselineValid) { previousSecond = now; baselineValid = true; return; }
  if (now == previousSecond) return;
  uint32_t prev = previousSecond;
  previousSecond = now;
  if (now < prev || now - prev > 2) { logEvent(EV_CLOCK_GAP, 0); return; }   // 지난 예약은 실행하지 않음
  uint16_t today = now / 86400UL;
  for (uint8_t i = 0; i < cfg.count; i++) {
    const Entry &e = cfg.e[i];
    if (!activeOn(e, today)) continue;
    uint32_t target = (uint32_t)today * 86400UL + todSec(e);
    if (prev < target && target <= now && dose[i].firedDay != today) fireEntry(i, today);
  }
}
// 해당 칸에서 가장 최근에 자동으로 열린 회차 (오늘 또는 어제 밤 회차)
int8_t latestFired(uint8_t slot, uint32_t now, uint32_t &target) {
  int8_t best = -1; uint32_t bestT = 0;
  for (uint8_t i = 0; i < cfg.count; i++) {
    if (cfg.e[i].slot != slot || dose[i].firedDay == 0) continue;
    uint32_t t = (uint32_t)dose[i].firedDay * 86400UL + todSec(cfg.e[i]);
    if (t > now || now - t > 86400UL) continue;
    if (best < 0 || t > bestT) { best = i; bestT = t; }
  }
  target = bestT;
  return best;
}

// ───────── 명령 처리 ─────────
uint16_t curId = 0;
void head() { if (curId) { OUT.print('@'); OUT.print(curId); OUT.print(' '); } }
void replyCode(const char *code, bool hasVal, long val) {
  head(); OUT.print(code);
  if (hasVal) { OUT.print(' '); OUT.print(val); }
  OUT.println();
}
void printStatus() {
#if USE_BT
  btEcho = (activeSlot == NONE);   // 모터가 움직이는 동안에는 블루투스로 상태를 보내지 않음(서보 펄스 보호)
#endif
  OUT.print(F("ST ")); OUT.print(validClock() ? 1 : 0); OUT.print(' ');
  OUT.print(validClock() ? rtc.GetDateTime().TotalSeconds() : 0UL); OUT.print(' ');
  OUT.print(recovery ? 2 : (validClock() ? 0 : 1)); OUT.print(' ');
  for (uint8_t i = 0; i < SLOTS; i++) {
    const char m[] = "CqoOxc";      // CLOSED,Q_OPEN,OPENING,OPEN,Q_CLOSE,CLOSING
    char c = m[phase[i]];
    if (phase[i] == OPEN && kind[i] == REFILL) c = 'R';
    if (recovery) c = '?';
    OUT.print(c);
  }
  OUT.print(' '); OUT.print(logSeq);
  OUT.print(' '); OUT.print(cfgChecksum(cfg));
  OUT.print(' '); OUT.println(cfg.count);
#if USE_BT
  btEcho = true;
#endif
}
// 공백으로 구분된 숫자를 읽는다
bool nextNum(char *&p, long &v) {
  while (*p == ' ') p++;
  if (!*p) return false;
  char *end; v = strtol(p, &end, 10);
  if (end == p) return false;
  p = end; return true;
}
bool parseSlot(char *p, uint8_t &s) {
  long v; if (!nextNum(p, v) || v < 1 || v > SLOTS) return false;
  s = v - 1; return true;
}

// 상태를 바꾸는 명령 — 결과 코드를 돌려주며, 같은 번호로 다시 오면 결과만 재전송한다.
const char *mutating(const char *cmd, char *args, bool &hasVal, long &val) {
  hasVal = false;
  if (!strcmp(cmd, "TIME")) {
    long y, mo, d, h, mi, se; char *p = args;
    for (char *q = args; *q; q++) if (*q == '-' || *q == ':') *q = ' ';
    if (!nextNum(p, y) || !nextNum(p, mo) || !nextNum(p, d) || !nextNum(p, h) || !nextNum(p, mi) || !nextNum(p, se)) return "ERR FORMAT";
    if (y < 2000 || y > 2099 || mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59 || se > 59 || h < 0 || mi < 0 || se < 0) return "ERR RANGE";
    RtcDateTime t(y, mo, d, h, mi, se);
    if (!t.IsValid()) return "ERR RANGE";
    clockReady = false;
    rtc.SetIsWriteProtected(false);
    rtc.SetTrickleChargeSettings(DS1302Tcr_Disabled);
    rtc.SetMemory((uint8_t)0, (uint8_t)0);
    rtc.SetDateTime(t);
    rtc.SetIsRunning(true);
    RtcDateTime got = rtc.GetDateTime();
    if (got.IsValid() && rtc.GetIsRunning() && got.TotalSeconds() >= t.TotalSeconds() && got.TotalSeconds() - t.TotalSeconds() <= 1) {
      for (uint8_t i = 1; i < 4; i++) rtc.SetMemory(i, MAGIC[i]);
      rtc.SetMemory((uint8_t)0, MAGIC[0]);
      clockReady = hasClockMarker();
    }
    rtc.SetIsWriteProtected(true);
    resetBaseline();
    if (!clockReady) return "ERR RTC";
    logEvent(EV_TIME_SET, 0);
    return "OK";
  }
  if (!strcmp(cmd, "SB")) { stageOpen = true; stage.count = 0; return "OK"; }
  if (!strcmp(cmd, "SE")) {
    if (!stageOpen) return "ERR NOSTAGE";
    if (stage.count >= MAX_ENTRIES) return "ERR FULL";
    long s, h, m, dd, st, en; char *p = args;
    if (!nextNum(p, s) || !nextNum(p, h) || !nextNum(p, m) || !nextNum(p, dd) || !nextNum(p, st) || !nextNum(p, en)) return "ERR FORMAT";
    if (s < 1 || s > SLOTS || h < 0 || h > 23 || m < 0 || m > 59 || dd < 1 || dd > 127 || st < 0 || st > 65535 || en < st || en > 65535) return "ERR RANGE";
    Entry &e = stage.e[stage.count++];
    e.slot = s; e.hour = h; e.minute = m; e.days = dd; e.startDay = st; e.endDay = en;
    hasVal = true; val = stage.count; return "OK";
  }
  if (!strcmp(cmd, "SC")) {
    long n, hold, grace, sum; char *p = args;
    if (!stageOpen) return "ERR NOSTAGE";
    if (!nextNum(p, n) || !nextNum(p, hold) || !nextNum(p, grace) || !nextNum(p, sum)) return "ERR FORMAT";
    if (n != stage.count) return "ERR COUNT";
    if (hold < 10 || hold > 900 || grace < 0 || grace > 180) return "ERR RANGE";
    stage.holdSec = hold; stage.graceMin = grace;
    if ((long)cfgChecksum(stage) != sum) return "ERR CHECKSUM";
    // 같은 칸·같은 시각의 회차는 실행/복용 기록을 이어받는다 → 설정을 다시 보내도 중복으로 열리지 않음
    DoseState nd[MAX_ENTRIES];
    for (uint8_t i = 0; i < stage.count; i++) {
      nd[i].firedDay = nd[i].takenDay = nd[i].reopenDay = 0;
      for (uint8_t j = 0; j < cfg.count; j++) {
        const Entry &a = stage.e[i], &b = cfg.e[j];
        if (a.slot == b.slot && a.hour == b.hour && a.minute == b.minute) { nd[i] = dose[j]; break; }
      }
    }
    if (!writeRec(EE_CFG, CFG_BANK, 1, &stage, sizeof(Config), cfgSeq, cfgBank)) { logEvent(EV_STORAGE_ERROR, 1); return "ERR STORAGE"; }
    cfg = stage;
    memcpy(dose, nd, sizeof(nd));
    for (uint8_t i = stage.count; i < MAX_ENTRIES; i++) dose[i].firedDay = dose[i].takenDay = dose[i].reopenDay = 0;
    saveDose();
    stageOpen = false;
    resetBaseline();
    logEvent(EV_SCHED_SAVED, cfg.count);
    hasVal = true; val = cfgChecksum(cfg); return "OK";
  }
  if (!strcmp(cmd, "REOPEN")) {
    uint8_t s; if (!parseSlot(args, s)) return "ERR FORMAT";
    if (recovery) return "ERR STATE";
    if (!validClock()) return "ERR RTC";
    uint32_t now = rtc.GetDateTime().TotalSeconds(), target;
    int8_t i = latestFired(s + 1, now, target);
    if (i < 0) return "ERR NODOSE";
    uint16_t day = dose[i].firedDay;
    if (dose[i].takenDay == day) return "ERR TAKEN";
    if (now - target > (uint32_t)cfg.graceMin * 60UL) return "ERR LATE";
    if (kind[s] == DOSE && (phase[s] == OPEN || phase[s] == OPENING || phase[s] == Q_OPEN)) return "OK";   // 이미 열려 있음
    if (dose[i].reopenDay == day) return "ERR USED";
    dose[i].reopenDay = day; saveDose();
    requestOpen(s, DOSE);
    logEvent(EV_REOPEN, s + 1);
    return "OK";
  }
  if (!strcmp(cmd, "TAKEN")) {
    uint8_t s; if (!parseSlot(args, s)) return "ERR FORMAT";
    if (!validClock()) return "ERR RTC";
    uint32_t now = rtc.GetDateTime().TotalSeconds(), target;
    int8_t i = latestFired(s + 1, now, target);
    if (i < 0) return "ERR NODOSE";
    if (dose[i].takenDay != dose[i].firedDay) { dose[i].takenDay = dose[i].firedDay; saveDose(); logEvent(EV_TAKEN, s + 1); }
    if (kind[s] == DOSE && (phase[s] == OPEN || phase[s] == Q_OPEN)) requestClose(s);    // 복용 확인되면 바로 닫음
    return "OK";
  }
  if (!strcmp(cmd, "REFILL")) {
    uint8_t s; if (!parseSlot(args, s)) return "ERR FORMAT";
    if (recovery) return "ERR STATE";
    if (phase[s] != CLOSED) return "ERR BUSY";
    requestOpen(s, REFILL);
    logEvent(EV_REFILL_OPEN, s + 1);
    return "OK";
  }
  if (!strcmp(cmd, "CLOSE")) {
    uint8_t s; if (!parseSlot(args, s)) return "ERR FORMAT";
    if (phase[s] == CLOSED) return "OK";
    requestClose(s);
    logEvent(EV_SLOT_CLOSE, s + 1);
    return "OK";
  }
  if (!strcmp(cmd, "STOP")) {
    for (uint8_t i = 0; i < SLOTS; i++) { detachMotor(i); reopenAfter[i] = false; phase[i] = CLOSED; }
    activeSlot = NONE; alarmActive = false; noTone(BUZZER_PIN); sounding = false;
    recovery = true; EEPROM.update(EE_RECOVERY, 1);
    logEvent(EV_STOP, 0);
    return "OK";
  }
  if (!strcmp(cmd, "RECOVER")) {
    if (!recovery) return "ERR STATE";
    recovery = false; EEPROM.update(EE_RECOVERY, 0);
    for (uint8_t i = 0; i < SLOTS; i++) { detachMotor(i); reopenAfter[i] = false; }
#if SERVO_CONTINUOUS
    // 사용자가 기구를 손으로 닫힘 위치에 맞췄다고 확인한 경우
    for (uint8_t i = 0; i < SLOTS; i++) phase[i] = CLOSED;
    openMask = movingMask = 0; saveMasks();
#else
    // 각도형은 닫힘 각도로 직접 복귀
    for (uint8_t i = 0; i < SLOTS; i++) phase[i] = Q_CLOSE;
#endif
    logEvent(EV_RECOVERED, 0);
    return "OK";
  }
  return 0;
}

void handleLine(char *s) {
  curId = 0;
  if (*s == '#') {
    long id = strtol(s + 1, &s, 10);
    if (id < 1 || id > 65535) { OUT.println(F("ERR ID")); return; }
    curId = id;
    while (*s == ' ') s++;
  }
  char *args = s;
  while (*args && *args != ' ') args++;
  if (*args) *args++ = 0;
  // 읽기 전용 명령
  if (!strcmp(s, "HELLO") || !strcmp(s, "INFO")) {
    head(); OUT.print(F("OK PILLBOX ")); OUT.print(FW_VERSION); OUT.print(' ');
    OUT.print(SLOTS); OUT.print(' '); OUT.print(SERVO_CONTINUOUS ? 1 : 0); OUT.print(' ');
    OUT.println(MAX_ENTRIES);
    return;
  }
  if (!strcmp(s, "STATUS")) { printStatus(); head(); OUT.println(F("OK")); return; }
  if (!strcmp(s, "GETSCHED")) {
    for (uint8_t i = 0; i < cfg.count; i++) {
      const Entry &e = cfg.e[i];
      OUT.print(F("S ")); OUT.print(i); OUT.print(' '); OUT.print(e.slot); OUT.print(' ');
      OUT.print(e.hour); OUT.print(' '); OUT.print(e.minute); OUT.print(' '); OUT.print(e.days); OUT.print(' ');
      OUT.print(e.startDay); OUT.print(' '); OUT.println(e.endDay);
    }
    head(); OUT.print(F("OK ")); OUT.print(cfg.count); OUT.print(' '); OUT.print(cfg.holdSec); OUT.print(' ');
    OUT.print(cfg.graceMin); OUT.print(' '); OUT.println(cfgChecksum(cfg));
    return;
  }
  if (!strcmp(s, "LOG")) {
    long from = 1; char *p = args; nextNum(p, from);
    // 링 버퍼에 남아 있는 기록을 순번 순으로 출력
    uint16_t start = logSeq > LOG_N ? logSeq - LOG_N + 1 : 1;
    if (from > start) start = from;
    for (uint16_t q = start; q <= logSeq && q != 0; q++) {
      LogEv ev; readLogAt(q % LOG_N, ev);
      if (ev.seq == q) printEv(ev);
      motorTick();
    }
    head(); OUT.print(F("OK ")); OUT.println(logSeq);
    return;
  }
  // 상태를 바꾸는 명령
  if (curId && curId == lastId && lastCode) { replyCode(lastCode, lastHasVal, lastVal); return; }
  bool hasVal; long val;
  const char *code = mutating(s, args, hasVal, val);
  if (!code) { head(); OUT.println(F("ERR COMMAND")); return; }
  if (curId) { lastId = curId; lastCode = code; lastHasVal = hasVal; lastVal = val; }
  replyCode(code, hasVal, val);
}

// 한 줄씩 모아서 명령 처리 (USB와 블루투스 각각 버퍼)
void feedChar(LineBuf &L, char c) {
  if (c == '\r') return;
  if (c == '\n') {
    L.b[L.n] = 0;
    if (L.over) OUT.println(F("ERR LENGTH"));
    else if (L.n) handleLine(L.b);
    L.n = 0; L.over = false;
  } else if (L.n < sizeof(L.b) - 1) L.b[L.n++] = c;
  else L.over = true;
}
void readSerial() {
  while (Serial.available()) { motorTick(); feedChar(usbBuf, Serial.read()); }
#if USE_BT
  while (bt.available()) { motorTick(); feedChar(btBuf, bt.read()); }
#endif
}

void setup() {
  Serial.begin(9600);
#if USE_BT
  bt.begin(9600);
#endif
  pinMode(BUZZER_PIN, OUTPUT); digitalWrite(BUZZER_PIN, LOW);
  for (uint8_t i = 0; i < SLOTS; i++) { detachMotor(i); phase[i] = CLOSED; kind[i] = DOSE; reopenAfter[i] = false; }
  rtc.Begin();
  rtc.SetIsWriteProtected(false);
  rtc.SetTrickleChargeSettings(DS1302Tcr_Disabled);
  rtc.SetIsWriteProtected(true);
  clockReady = hasClockMarker() && rtc.GetIsRunning() && rtc.GetDateTime().IsValid();

  bool fresh = false;
  for (uint8_t i = 0; i < 4; i++) if (EEPROM.read(EE_MAGIC + i) != MAGIC[i]) fresh = true;
  if (fresh) {   // 처음 실행: 저장 영역 초기화 (ver6 데이터는 형식이 달라 사용하지 않음)
    EEPROM.update(EE_OPEN, 0); EEPROM.update(EE_MOVING, 0); EEPROM.update(EE_RECOVERY, 0);
    EEPROM.update(EE_CFG, 0); EEPROM.update(EE_CFG + CFG_BANK, 0);
    EEPROM.update(EE_ST, 0); EEPROM.update(EE_ST + ST_BANK, 0);
    for (int a = EE_LOG; a < EE_LOG + LOG_N * 8; a++) EEPROM.update(a, 0xFF);
    for (uint8_t i = 0; i < 4; i++) EEPROM.update(EE_MAGIC + i, MAGIC[i]);
  }
  memset(&cfg, 0, sizeof(cfg)); cfg.holdSec = 60; cfg.graceMin = 30;
  memset(dose, 0, sizeof(dose));
  Config tmp;
  if (readRec(EE_CFG, CFG_BANK, 1, &tmp, sizeof(Config), cfgSeq, cfgBank) && tmp.count <= MAX_ENTRIES) cfg = tmp;
  readRec(EE_ST, ST_BANK, 2, dose, sizeof(dose), stSeq, stBank);
  loadLogSeq();

  openMask = EEPROM.read(EE_OPEN) & 63;
  movingMask = EEPROM.read(EE_MOVING) & 63;
  recovery = EEPROM.read(EE_RECOVERY) == 1;
  // 부팅 직후 모터 처리
#if SERVO_CONTINUOUS
  if (movingMask) { recovery = true; EEPROM.update(EE_RECOVERY, 1); }   // 회전 중 끊김 → 위치 불명
  else if (!recovery) for (uint8_t i = 0; i < SLOTS; i++) if (openMask & (1 << i)) phase[i] = Q_CLOSE;   // 열린 위치가 확실한 칸만 닫음
#else
  if (!recovery) for (uint8_t i = 0; i < SLOTS; i++) phase[i] = Q_CLOSE;    // 각도형: 전체 닫힘 각도로 정렬
#endif
  resetBaseline();
  OUT.print(F("PILLBOX ")); OUT.println(FW_VERSION);
  logEvent(EV_BOOT, recovery ? 1 : 0);
  if (recovery) logEvent(EV_RECOVERY_NEEDED, movingMask);
}

void loop() {
  serviceMotors();
  readSerial();
  unsigned long ms = millis();
  if (ms - lastStatus >= 1000) { lastStatus = ms; printStatus(); }
  if (ms - lastPoll >= 100) { lastPoll = ms; checkSchedule(); }
}
