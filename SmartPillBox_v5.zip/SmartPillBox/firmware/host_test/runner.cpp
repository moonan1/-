// 펌웨어를 PC에서 실제 시간으로 실행: stdin → Serial 입력, Serial 출력 → stdout
#include "mock/ArduinoMock.h"
#include <chrono>
#include <thread>
#include <mutex>
#include <iostream>
unsigned long g_ms=0; bool g_tone=false; MockSerial Serial;
uint32_t g_rtc=0; bool g_rtcRun=true; uint8_t g_rtcMem[31];
int g_maxSimul=0; std::vector<std::string> g_motion;
#include "mock/EEPROM.h"
EEPROMClass EEPROM;
#include "../PillBox_ver7/PillBox_ver7.ino"
int Servo::live=0;
std::mutex mu; std::deque<char> inq;
int main(){
  std::thread([]{ std::string l; while(std::getline(std::cin,l)){ std::lock_guard<std::mutex> g(mu); for(char c:l) inq.push_back(c); inq.push_back('\n'); } exit(0); }).detach();
  auto t0=std::chrono::steady_clock::now(); unsigned long lastSec=0;
  setup();
  size_t printed=0;
  while(true){
    g_ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-t0).count();
    if(g_ms/1000!=lastSec){ g_rtc+= (g_ms/1000-lastSec); lastSec=g_ms/1000; }
    { std::lock_guard<std::mutex> g(mu); while(!inq.empty()){ Serial.in.push_back(inq.front()); inq.pop_front(); } }
    loop();
    while(printed<Serial.lines.size()){ std::cout<<Serial.lines[printed++]<<"\n"; }
    std::cout.flush();
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
}
