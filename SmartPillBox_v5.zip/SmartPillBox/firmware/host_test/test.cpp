#include "mock/ArduinoMock.h"
unsigned long g_ms=0; bool g_tone=false; MockSerial Serial;
uint32_t g_rtc=0; bool g_rtcRun=true; uint8_t g_rtcMem[31];
int g_maxSimul=0; std::vector<std::string> g_motion;
#include "mock/EEPROM.h"
EEPROMClass EEPROM;
#include "../PillBox_ver7/PillBox_ver7.ino"
#include <cassert>
int Servo::live=0;
int fails=0;
#define CHECK(c,msg) do{ if(!(c)){printf("FAIL: %s\n",msg);fails++;} else printf("ok: %s\n",msg);}while(0)
unsigned long subms=0;
void step(unsigned long ms){ for(unsigned long t=0;t<ms;t+=10){ g_ms+=10; subms+=10; if(subms>=1000){subms-=1000; if(g_rtcRun) g_rtc++;} loop(); } }
std::vector<std::string> cmd(const std::string&c){ size_t n=Serial.lines.size(); Serial.send(c); step(30); return std::vector<std::string>(Serial.lines.begin()+n,Serial.lines.end()); }
bool has(const std::vector<std::string>&v,const std::string&s){ for(auto&x:v) if(x.find(s)!=std::string::npos) return true; return false; }
int countEv(int type,int arg){int n=0; for(auto&l:Serial.lines){ unsigned a,b,c; unsigned long t; if(sscanf(l.c_str(),"EV %u %u %u %lu",&a,&b,&c,&t)==4 && (int)b==type && (arg<0||(int)c==arg)) n++;} return n;}
std::string lastST(){ for(int i=Serial.lines.size()-1;i>=0;i--) if(Serial.lines[i].rfind("ST ",0)==0) return Serial.lines[i]; return "";}
std::string slots(){ char a[8]; unsigned x,y,z; unsigned long t; sscanf(lastST().c_str(),"ST %u %lu %u %7s",&x,&t,&y,a); return a;}
void reboot(){ for(int i=0;i<6;i++) motors[i].detach(); activeSlot=NONE; stageOpen=false; lastId=0; lastCode=0; usbBuf.n=0; alarmActive=false; setup(); }
long checksumOf(std::vector<Entry> es,int hold,int grace){ Config c; memset(&c,0,sizeof c); c.count=es.size(); c.holdSec=hold; c.graceMin=grace; for(size_t i=0;i<es.size();i++) c.e[i]=es[i]; return cfgChecksum(c);}
void push(std::vector<Entry> es,int hold=60,int grace=30){ cmd("SB"); for(auto&e:es){ char b[80]; snprintf(b,80,"SE %d %d %d %d %d %d",e.slot,e.hour,e.minute,e.days,e.startDay,e.endDay); cmd(b);} char b[80]; snprintf(b,80,"#%d SC %zu %d %d %ld",100+(int)es.size()+hold,es.size(),hold,grace,checksumOf(es,hold,grace)); auto r=cmd(b); CHECK(has(r,"OK"),"schedule commit OK"); }
int main(){
  setup(); step(100);
  CHECK(countEv(EV_BOOT,-1)==1,"boot event");
  auto r=cmd("#1 HELLO"); CHECK(has(r,"@1 OK PILLBOX 7 6"),"HELLO");
  r=cmd("#2 TIME 2026-11-07 08:59:50"); CHECK(has(r,"@2 OK"),"TIME set");
  uint16_t today=g_rtc/86400;
  std::vector<Entry> es={{1,9,0,127,0,65535},{3,9,0,127,0,65535},{2,12,0,127,0,65535},{4,9,0,127,0,(uint16_t)(today-1)},{5,9,0,(uint8_t)(127 & ~(1<<weekdayOf(today))),0,65535}};
  push(es);
  r=cmd("#3 SC 1 60 30 0"); CHECK(has(r,"ERR NOSTAGE"),"SC without stage rejected");
  g_maxSimul=0;
  step(12000);
  CHECK(countEv(EV_DOSE_OPEN,1)==1 && countEv(EV_DOSE_OPEN,3)==1,"slot1 & slot3 opened at 09:00");
  CHECK(countEv(EV_DOSE_OPEN,4)==0,"expired entry (endDay) did not open");
  CHECK(countEv(EV_DOSE_OPEN,5)==0,"weekday-excluded entry did not open");
  CHECK(g_maxSimul==1,"only one servo driven at a time");
  printf("  slots=%s\n",slots().c_str());
  CHECK(slots()=="OCOCCC","slot1/3 open, others closed");
  r=cmd("#4 REOPEN 1"); CHECK(has(r,"@4 OK"),"reopen while open is OK (no extra motion)");
  step(60000);
  CHECK(slots()=="CCCCCC","auto close after hold");
  CHECK(countEv(EV_AUTO_CLOSE,-1)==2,"two auto close events");
  r=cmd("#5 REOPEN 3"); CHECK(has(r,"@5 OK"),"reopen slot3 within grace");
  step(1000); CHECK(slots()[2]=='O',"slot3 reopened");
  r=cmd("#6 REOPEN 3"); CHECK(has(r,"OK"),"reopen while still open is idempotent OK");
  step(61000);
  r=cmd("#7 REOPEN 3"); CHECK(has(r,"ERR USED"),"second reopen blocked");
  r=cmd("#8 TAKEN 1"); CHECK(has(r,"@8 OK"),"taken slot1");
  r=cmd("#9 REOPEN 1"); CHECK(has(r,"ERR TAKEN"),"reopen after taken blocked");
  r=cmd("#10 REOPEN 2"); CHECK(has(r,"ERR NODOSE"),"reopen slot without fired dose blocked");
  int before=countEv(EV_REFILL_OPEN,2);
  r=cmd("#11 REFILL 2"); r=cmd("#11 REFILL 2");
  CHECK(countEv(EV_REFILL_OPEN,2)==before+1,"duplicate command id executed once");
  step(1000); CHECK(slots()[1]=='R',"refill open shown as R");
  r=cmd("#12 CLOSE 2"); step(1000); CHECK(slots()[1]=='C',"manual close");
  // re-push same schedule: no re-fire, state preserved
  push(es); step(3000);
  CHECK(countEv(EV_DOSE_OPEN,1)==1,"re-push schedule does not reopen");
  r=cmd("#13 REOPEN 1"); CHECK(has(r,"ERR TAKEN"),"taken state preserved across schedule push");
  // time edge at 12:00
  cmd("#14 TIME 2026-11-07 11:59:55"); step(8000);
  CHECK(countEv(EV_DOSE_OPEN,2)==1,"slot2 opened at 12:00 after time set");
  // jump over a schedule: no catch-up
  push({{6,13,0,127,0,65535}});
  cmd("#15 TIME 2026-11-07 13:00:30"); step(5000);
  CHECK(countEv(EV_DOSE_OPEN,6)==0,"no late catch-up after time jump");
  step(70000);
  // reboot while moving (continuous) -> recovery
  push({{6,13,3,127,0,65535}});
  step(30000); // now ~13:02:4x
  while(!(g_rtc%86400 == 13*3600+3*60)) step(10);
  step(20); // start of opening motion
  printf("  moving mask=%d active=%d\n",movingMask,activeSlot);
  CHECK(movingMask!=0,"motor moving at 13:03");
  reboot(); step(2000);
  CHECK(recovery,"reboot during motion -> recovery");
  CHECK(slots()=="??????","status shows unknown while recovery");
  r=cmd("#16 REFILL 1"); CHECK(has(r,"ERR STATE"),"refill blocked in recovery");
  push({{1,13,5,127,0,65535}});
  while(!(g_rtc%86400 == 13*3600+5*60+2)) step(10);
  CHECK(countEv(EV_DOSE_BLOCKED,1)==1,"dose blocked during recovery");
  r=cmd("#17 RECOVER"); CHECK(has(r,"OK") && !recovery,"recover");
  // reboot while open (not moving) -> closes
  r=cmd("#18 REFILL 4"); step(1500); CHECK(slots()[3]=='R',"slot4 open");
  reboot(); step(1500);
  CHECK(!recovery && slots()[3]=='C',"reboot while open -> auto close known-open slot");
  // log sync
  r=cmd("#19 LOG 1"); int evs=0; for(auto&l:r) if(l.rfind("EV ",0)==0) evs++;
  printf("  log returned %d events, last seq=%u\n",evs,logSeq);
  CHECK(evs==24 || evs==(int)logSeq,"LOG returns ring contents");
  r=cmd("#20 GETSCHED"); CHECK(has(r,"S 0 1 13 5"),"GETSCHED");
  r=cmd("BOGUS"); CHECK(has(r,"ERR COMMAND"),"unknown command");
  r=cmd("#21 SE 1 1 1 1 1 1"); CHECK(has(r,"ERR NOSTAGE"),"SE without SB");
  printf("EEPROM writes=%ld sizeof(Config)=%zu dose=%zu\n",EEPROM.writes,sizeof(Config),sizeof(dose));
  printf("\n%d failures\n",fails); return fails?1:0;
}
