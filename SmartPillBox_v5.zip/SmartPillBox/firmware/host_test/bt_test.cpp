#include "mock/ArduinoMock.h"
unsigned long g_ms=0; bool g_tone=false; MockSerial Serial;
uint32_t g_rtc=0; bool g_rtcRun=true; uint8_t g_rtcMem[31];
int g_maxSimul=0; std::vector<std::string> g_motion;
#include "mock/EEPROM.h"
EEPROMClass EEPROM;
#include "mock/SoftwareSerial.h"
#include "../PillBox_ver7/PillBox_ver7.ino"
int Servo::live=0;
int main(){ setup(); for(char c: std::string("#7 HELLO\n#8 REFILL 2\n")) bt.in.push_back(c);
  for(int i=0;i<200;i++){ g_ms+=10; loop(); }
  bool ok = bt.out.find("@7 OK PILLBOX 7")!=std::string::npos && bt.out.find("@8 OK")!=std::string::npos && bt.out.find("ST ")!=std::string::npos;
  bool usb=false; for(auto&l:Serial.lines) if(l.find("@8 OK")!=std::string::npos) usb=true;
  printf("bt reply %s, usb mirror %s, slot2=%c\n", ok?"ok":"FAIL", usb?"ok":"FAIL", "CqoOxc"[phase[1]]); return ok&&usb?0:1; }
