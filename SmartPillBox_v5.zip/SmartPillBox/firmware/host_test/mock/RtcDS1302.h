#pragma once
#include "ArduinoMock.h"
extern uint32_t g_rtc; extern bool g_rtcRun; extern uint8_t g_rtcMem[31];
#define DS1302Tcr_Disabled 0
struct RtcDateTime{
  uint32_t s;
  RtcDateTime(uint32_t x=0):s(x){}
  RtcDateTime(int y,int mo,int d,int h,int mi,int se){
    static const int md[]={31,28,31,30,31,30,31,31,30,31,30,31};
    uint32_t days=0; for(int yy=2000;yy<y;yy++) days+= (yy%4==0)?366:365;
    for(int m=1;m<mo;m++){days+=md[m-1]; if(m==2&&y%4==0)days++;}
    days+=d-1; s=days*86400u+h*3600u+mi*60u+se;}
  uint32_t TotalSeconds()const{return s;}
  bool IsValid()const{return true;}
};
template<class W> struct RtcDS1302{
  RtcDS1302(W&){}
  void Begin(){} void SetIsWriteProtected(bool){} void SetTrickleChargeSettings(int){}
  bool GetIsRunning(){return g_rtcRun;} void SetIsRunning(bool b){g_rtcRun=b;}
  RtcDateTime GetDateTime(){return RtcDateTime(g_rtc);} void SetDateTime(const RtcDateTime&t){g_rtc=t.s;}
  uint8_t GetMemory(uint8_t a){return g_rtcMem[a];} void SetMemory(uint8_t a,uint8_t v){g_rtcMem[a]=v;}
};
