#pragma once
#include "ArduinoMock.h"
struct EEPROMClass{ uint8_t m[1024]; long writes=0; EEPROMClass(){memset(m,0xFF,sizeof m);}
  uint8_t read(int a){return m[a];} void update(int a,uint8_t v){if(a<0||a>=1024){printf("EEPROM OOB %d\n",a);abort();} if(m[a]!=v){m[a]=v;writes++;}} };
extern EEPROMClass EEPROM;
