#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <deque>
#include <vector>
#include <cstdio>
#define F(x) x
#define OUTPUT 1
#define LOW 0
extern unsigned long g_ms;
inline unsigned long millis(){return g_ms;}
inline void pinMode(int,int){}
inline void digitalWrite(int,int){}
extern bool g_tone;
inline void tone(int,int){g_tone=true;}
inline void noTone(int){g_tone=false;}
struct MockSerial{
  std::string out,cur; std::deque<char> in; std::vector<std::string> lines;
  void begin(long){}
  int available(){return in.size();}
  char read(){char c=in.front();in.pop_front();return c;}
  void w(const std::string&s){cur+=s;}
  void print(const char*s){w(s);} void print(char c){w(std::string(1,c));}
  void print(int v){w(std::to_string(v));} void print(unsigned v){w(std::to_string(v));}
  void print(long v){w(std::to_string(v));} void print(unsigned long v){w(std::to_string(v));}
  void print(unsigned char v){w(std::to_string((unsigned)v));}
  void print(unsigned short v){w(std::to_string((unsigned)v));}
  void println(){lines.push_back(cur);cur.clear();}
  template<class T> void println(T v){print(v);println();}
  void write(uint8_t c){ if(c=='\n') println(); else cur+=(char)c; }
  void send(const std::string&s){for(char c:s)in.push_back(c);in.push_back('\n');}
};
extern MockSerial Serial;
// USE_BT=1 컴파일 확인용
#define A0 14
#define A1 15
struct Print {
  virtual size_t write(uint8_t c) = 0;
  void print(const char*s){ while(*s) write(*s++); } void print(char c){ write(c); }
  void print(long v){ print(std::to_string(v).c_str()); } void print(unsigned long v){ print(std::to_string(v).c_str()); }
  void print(int v){ print((long)v); } void print(unsigned v){ print((unsigned long)v); }
  void print(unsigned char v){ print((unsigned long)v); } void print(unsigned short v){ print((unsigned long)v); }
  void println(){ write('\n'); } template<class T> void println(T v){ print(v); println(); }
  virtual ~Print(){}
};
