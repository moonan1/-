#pragma once
#include "ArduinoMock.h"
extern int g_attachCount; extern int g_maxSimul; extern std::vector<std::string> g_motion;
struct Servo{
  bool att=false; int us=0; int pin=0;
  static int live;
  void writeMicroseconds(int u){us=u;} void write(int d){us=d;}
  void attach(int p){if(!att){att=true;pin=p;live++; if(live>g_maxSimul)g_maxSimul=live; g_motion.push_back("A"+std::to_string(p)+":"+std::to_string(us));}}
  void detach(){if(att){att=false;live--;}}
  bool attached(){return att;}
};
