#pragma once
#include "ArduinoMock.h"
struct SoftwareSerial { std::string out; std::deque<char> in; SoftwareSerial(int,int){} void begin(long){} int available(){return in.size();} char read(){char c=in.front();in.pop_front();return c;} void write(uint8_t c){out+=(char)c;} };
