#pragma once
#include "ArduinoMock.h"
struct ThreeWire{ThreeWire(int,int,int){}};
