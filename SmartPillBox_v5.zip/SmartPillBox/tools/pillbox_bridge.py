# -*- coding: utf-8 -*-
"""
약속 약통 노트북 중계 프로그램
  휴대폰 앱  <--Wi-Fi/USB(TCP)-->  노트북(이 프로그램)  <--USB 시리얼-->  아두이노 우노

사용법 (Windows)
  1) Python 설치 (Microsoft Store 'Python 3.12' 또는 python.org)
  2) 명령 프롬프트에서:  pip install pyserial
  3) Arduino IDE 시리얼 모니터는 닫고, 이 파일을 더블클릭하거나:  python pillbox_bridge.py
     포트를 직접 지정하려면:  python pillbox_bridge.py COM5
  4) 화면에 나온 주소(IP:8765)를 앱 › 약통 › 노트북 에 입력하고 연결
     처음 실행 때 Windows 방화벽 창이 뜨면 '개인 네트워크' 허용을 눌러주세요.
"""
import socket
import sys
import threading
import time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    print("pyserial 이 필요해요. 명령 프롬프트에서  pip install pyserial  을 실행한 뒤 다시 시작하세요.")
    input("엔터를 누르면 닫혀요...")
    sys.exit(1)

TCP_PORT = 8765
BAUD = 9600
KNOWN_VIDS = {0x2341, 0x2A03, 0x1A86, 0x0403, 0x10C4}   # Arduino, CH340, FTDI, CP210x

lock = threading.Lock()
client = None          # 현재 연결된 휴대폰 소켓 (한 대만)
ser = None


def find_port():
    ports = list(list_ports.comports())
    for p in ports:
        desc = (p.description or "") + " " + (p.manufacturer or "")
        if p.vid in KNOWN_VIDS or "Arduino" in desc or "CH340" in desc:
            return p.device
    return ports[0].device if ports else None


def local_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))   # 실제로 전송하지 않음, 내 IP 확인용
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."):
                ips.add(ip)
    except OSError:
        pass
    return sorted(ips)


def open_serial(port_name):
    global ser
    while True:
        name = port_name or find_port()
        if not name:
            print("아두이노를 찾지 못했어요. USB 연결을 확인하세요. (3초 후 다시 시도)")
            time.sleep(3)
            continue
        try:
            s = serial.Serial(name, BAUD, timeout=0.2)
            print(f"[우노] {name} 연결됨 (우노가 재시작되는 중, 2초 대기)")
            time.sleep(2.2)
            ser = s
            return
        except serial.SerialException as e:
            print(f"[우노] {name} 열기 실패: {e}\n  → Arduino IDE 시리얼 모니터가 열려 있으면 닫아주세요. (3초 후 다시 시도)")
            time.sleep(3)


def serial_reader(port_name):
    """우노 → 휴대폰"""
    global ser, client
    buf = b""
    while True:
        try:
            data = ser.read(256)
        except (serial.SerialException, OSError):
            print("[우노] 연결이 끊겼어요. 다시 찾는 중...")
            try:
                ser.close()
            except Exception:
                pass
            open_serial(port_name)
            continue
        if not data:
            continue
        buf += data
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            text = line.decode("ascii", "replace").strip()
            if text.startswith("EV ") or text.startswith("@") or text.startswith("PILLBOX"):
                print(f"[우노→앱] {text}")
            with lock:
                c = client
            if c:
                try:
                    c.sendall(line + b"\n")
                except OSError:
                    pass


def handle_client(conn, addr):
    """휴대폰 → 우노"""
    global client
    print(f"[앱] {addr[0]} 연결됨")
    buf = b""
    try:
        while True:
            data = conn.recv(512)
            if not data:
                break
            buf += data
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                text = line.decode("ascii", "replace").strip()
                if not text:
                    continue
                print(f"[앱→우노] {text}")
                try:
                    ser.write((text + "\n").encode("ascii", "replace"))
                except (serial.SerialException, OSError):
                    print("[우노] 전송 실패 (연결 확인 중)")
    except OSError:
        pass
    finally:
        with lock:
            if client is conn:
                client = None
        try:
            conn.close()
        except OSError:
            pass
        print(f"[앱] {addr[0]} 연결 끊김 — 약통은 저장된 일정대로 계속 동작해요")


def main():
    global client
    port_name = sys.argv[1] if len(sys.argv) > 1 else None
    print("=" * 52)
    print(" 약속 약통 노트북 중계 프로그램")
    print("=" * 52)
    open_serial(port_name)
    threading.Thread(target=serial_reader, args=(port_name,), daemon=True).start()

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", TCP_PORT))
    srv.listen(1)
    print("\n앱 › 약통 › '노트북' 에 아래 주소를 입력하세요:")
    for ip in local_ips():
        print(f"   노트북 IP: {ip}    포트: {TCP_PORT}")
    print(f"   (USB 케이블 + adb reverse 사용 시: 127.0.0.1 / {TCP_PORT})")
    print("\n종료하려면 이 창을 닫으세요.\n")

    while True:
        conn, addr = srv.accept()
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        with lock:
            old = client
            client = conn
        if old:
            try:
                old.close()
            except OSError:
                pass
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
