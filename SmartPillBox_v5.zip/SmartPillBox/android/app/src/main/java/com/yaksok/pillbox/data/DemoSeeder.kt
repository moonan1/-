package com.yaksok.pillbox.data

import com.yaksok.pillbox.domain.DoseGenerator
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.random.Random

/**
 * 발표 시연용 30일 복용 기록. '시연 데이터' 모드에서만 사용하며 실제 기록 파일과 분리 저장된다.
 * 패턴: 아침은 대체로 정시, 점심은 주말에 자주 누락, 저녁은 최근 일주일 동안 10~20분 지연이 반복.
 */
object DemoSeeder {
    fun create(now: LocalDateTime): AppData {
        val today = now.toLocalDate()
        val start = today.minusDays(30)
        val everyDay = DayOfWeek.entries.toSet()
        val weekdays = setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)
        val meds = listOf(
            Medication("demo-1", "혈압약", 1, listOf(LocalTime.of(8, 0)), everyDay, start, null, 1),
            Medication("demo-2", "위장약", 1, listOf(LocalTime.of(12, 30)), everyDay, start, null, 2),
            Medication("demo-3", "고지혈증약", 1, listOf(LocalTime.of(19, 0)), everyDay, start, null, 3),
            Medication("demo-4", "관절 영양제", 2, listOf(LocalTime.of(19, 0)), weekdays, start, null, 4),
        )
        val rnd = Random(20261107)
        val records = ArrayList<DoseRecord>()
        var date = start
        while (!date.isAfter(today)) {
            val daysAgo = java.time.temporal.ChronoUnit.DAYS.between(date, today).toInt()
            val weekend = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY
            for (r in DoseGenerator.occurrences(meds, date)) {
                val sched = r.scheduledAt
                if (sched.isAfter(now)) { records += r; continue }
                val boxOnline = rnd.nextInt(100) >= 8           // 가끔 약통 미연결(열림 기록 없음)
                val opened = if (boxOnline) sched.plusSeconds(rnd.nextLong(0, 3)) else null
                // 결과: 지연(분) 또는 null(복용 확인 없음)
                val delay: Int? = when (r.medId) {
                    "demo-1" -> when {
                        rnd.nextInt(100) < 3 -> null
                        weekend -> rnd.nextInt(5, 22)
                        else -> rnd.nextInt(0, 8)
                    }
                    "demo-2" -> when {
                        weekend && rnd.nextInt(100) < (if (daysAgo < 14) 45 else 60) -> null
                        else -> rnd.nextInt(0, 14)
                    }
                    else -> when {   // 저녁 약
                        daysAgo in 1..7 -> when {
                            r.medId == "demo-3" && (daysAgo == 3 || daysAgo == 6) -> null
                            rnd.nextInt(100) < 75 -> rnd.nextInt(11, 21)
                            else -> rnd.nextInt(0, 6)
                        }
                        daysAgo in 8..14 && rnd.nextInt(100) < 15 -> null
                        rnd.nextInt(100) < 35 -> rnd.nextInt(10, 26)
                        else -> rnd.nextInt(0, 8)
                    }
                }
                val confirmed = delay?.let { sched.plusMinutes(it.toLong()).plusSeconds(rnd.nextLong(0, 50)) }
                if (confirmed != null && confirmed.isAfter(now)) { records += r.copy(openedAt = opened); continue }
                records += r.copy(openedAt = opened, confirmedAt = confirmed, confirmSource = confirmed?.let { "app" })
            }
            date = date.plusDays(1)
        }
        return AppData(
            meds = meds,
            records = records,
            lastGenerated = today,
            deviceLog = listOf(DeviceLogEntry(now, "시연 데이터 30일치를 만들었습니다.")),
        )
    }
}
