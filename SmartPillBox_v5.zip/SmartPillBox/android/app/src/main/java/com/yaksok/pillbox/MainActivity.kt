@file:OptIn(ExperimentalMaterial3Api::class)

package com.yaksok.pillbox

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.screens.DeviceScreen
import com.yaksok.pillbox.ui.screens.HistoryScreen
import com.yaksok.pillbox.ui.screens.HomeScreen
import com.yaksok.pillbox.ui.screens.MedEditScreen
import com.yaksok.pillbox.ui.screens.MedsScreen
import com.yaksok.pillbox.ui.screens.SettingsScreen
import com.yaksok.pillbox.ui.screens.SmartScreen
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.YaksokTheme

/** 하단 탭 위에 겹쳐 열리는 화면 */
sealed class Overlay {
    data object Device : Overlay()
    data object Settings : Overlay()
    data class EditMed(val medId: String?, val slot: Int? = null) : Overlay()
}

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { YaksokTheme { AppRoot(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshNow()
    }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val overlays = remember { mutableStateListOf<Overlay>() }
    val snackbar = remember { SnackbarHostState() }
    val open: (Overlay) -> Unit = { overlays.add(it) }
    val close: () -> Unit = { if (overlays.isNotEmpty()) overlays.removeAt(overlays.lastIndex) }

    // 알림 권한 (Android 13+)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    BackHandler(enabled = overlays.isNotEmpty()) { close() }

    val top = overlays.lastOrNull()
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (top == null) {
                NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                    val items = listOf(
                        Triple("홈", Icons.Filled.Home, 0),
                        Triple("약 관리", Icons.Filled.Medication, 1),
                        Triple("복용 기록", Icons.Filled.CalendarMonth, 2),
                        Triple("스마트 관리", Icons.Filled.Insights, 3),
                    )
                    items.forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icon, null) },
                            label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Mint, selectedTextColor = Mint, indicatorColor = MintSoft,
                            ),
                        )
                    }
                }
            }
        },
    ) { inner ->
        val mod = Modifier.padding(inner)
        when (val o = top) {
            is Overlay.Device -> DeviceScreen(vm, onBack = close, modifier = mod)
            is Overlay.Settings -> SettingsScreen(vm, onBack = close, modifier = mod)
            is Overlay.EditMed -> MedEditScreen(vm, o.medId, o.slot, onBack = close, modifier = mod)
            null -> when (tab) {
                0 -> HomeScreen(vm, open, mod)
                1 -> MedsScreen(vm, open, mod)
                2 -> HistoryScreen(vm, mod)
                else -> SmartScreen(vm, open, mod)
            }
        }
    }
}
