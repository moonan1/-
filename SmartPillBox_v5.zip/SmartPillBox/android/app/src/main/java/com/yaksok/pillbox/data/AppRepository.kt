package com.yaksok.pillbox.data

import android.content.Context
import android.util.Log
import com.yaksok.pillbox.domain.DoseGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime

/**
 * 앱 데이터 저장소 (로그인 없음, 기기 내부 JSON 파일).
 * 실제 데이터와 시연 데이터는 서로 다른 파일에 저장해 절대 섞이지 않는다.
 * 추후 DB/클라우드로 확장할 때는 readFile/writeFile 부분만 교체하면 된다.
 */
class AppRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("yaksok_prefs", Context.MODE_PRIVATE)
    private val mutex = Mutex()

    private val _mode = MutableStateFlow(
        runCatching { DataMode.valueOf(prefs.getString("dataMode", DataMode.REAL.name)!!) }.getOrDefault(DataMode.REAL)
    )
    val mode: StateFlow<DataMode> = _mode.asStateFlow()

    private val _deviceKind = MutableStateFlow(
        runCatching { DeviceKind.valueOf(prefs.getString("deviceKind", DeviceKind.SIMULATION.name)!!) }.getOrDefault(DeviceKind.SIMULATION)
    )
    val deviceKind: StateFlow<DeviceKind> = _deviceKind.asStateFlow()

    private val _data = MutableStateFlow(AppData())
    val data: StateFlow<AppData> = _data.asStateFlow()

    var onboardingDone: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(v) { prefs.edit().putBoolean("onboarded", v).apply() }

    private fun fileOf(m: DataMode) = File(context.filesDir, if (m == DataMode.DEMO) "data_demo.json" else "data_real.json")

    private fun readFile(m: DataMode): AppData? {
        val f = fileOf(m)
        if (!f.exists()) return null
        return try { JsonCodec.decode(f.readText()) } catch (e: Exception) {
            Log.e("Repo", "데이터 파일을 읽지 못했습니다", e)
            f.copyTo(File(f.parentFile, f.name + ".broken"), overwrite = true)
            null
        }
    }

    private fun writeFile(m: DataMode, d: AppData) {
        val f = fileOf(m)
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(JsonCodec.encode(d))
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    /** 앱 시작 시(메인 스레드 밖이 아니어도 될 만큼 작음) 동기 로드 */
    fun loadBlocking() {
        val m = _mode.value
        var d = readFile(m) ?: if (m == DataMode.DEMO) DemoSeeder.create(LocalDateTime.now()) else AppData()
        d = DoseGenerator.ensure(d, LocalDateTime.now().toLocalDate())
        _data.value = d
        runCatching { writeFile(m, d) }
    }

    suspend fun update(transform: (AppData) -> AppData): AppData = mutex.withLock {
        val next = transform(_data.value)
        _data.value = next
        val m = _mode.value
        withContext(Dispatchers.IO) { runCatching { writeFile(m, next) }.onFailure { Log.e("Repo", "저장 실패", it) } }
        next
    }

    /** 날짜가 바뀌었으면 회차 생성 */
    suspend fun ensureToday() {
        val today = LocalDateTime.now().toLocalDate()
        if (_data.value.lastGenerated != today) update { DoseGenerator.ensure(it, today) }
    }

    suspend fun switchMode(m: DataMode) = mutex.withLock {
        if (m == _mode.value) return@withLock
        prefs.edit().putString("dataMode", m.name).apply()
        _mode.value = m
        var d = withContext(Dispatchers.IO) { readFile(m) } ?: if (m == DataMode.DEMO) DemoSeeder.create(LocalDateTime.now()) else AppData()
        d = DoseGenerator.ensure(d, LocalDateTime.now().toLocalDate())
        _data.value = d
        withContext(Dispatchers.IO) { runCatching { writeFile(m, d) } }
    }

    /** 시연 데이터를 오늘 기준 30일치로 다시 만든다 */
    suspend fun resetDemo() = mutex.withLock {
        val d = DemoSeeder.create(LocalDateTime.now())
        withContext(Dispatchers.IO) { runCatching { writeFile(DataMode.DEMO, d) } }
        if (_mode.value == DataMode.DEMO) _data.value = d
    }

    fun setDeviceKind(k: DeviceKind) {
        prefs.edit().putString("deviceKind", k.name).apply()
        _deviceKind.value = k
    }

    /** 선택한 블루투스 모듈 주소 */
    var btAddress: String?
        get() = prefs.getString("btAddress", null)
        set(v) { prefs.edit().putString("btAddress", v).apply() }
    var btName: String?
        get() = prefs.getString("btName", null)
        set(v) { prefs.edit().putString("btName", v).apply() }

    /** 노트북 중계 프로그램 주소 */
    var laptopHost: String
        get() = prefs.getString("laptopHost", "192.168.0.2") ?: "192.168.0.2"
        set(v) { prefs.edit().putString("laptopHost", v).apply() }
    var laptopPort: Int
        get() = prefs.getInt("laptopPort", 8765)
        set(v) { prefs.edit().putInt("laptopPort", v).apply() }

    // 알림 스케줄러가 중복 알림을 막기 위해 사용
    var lastAlarmCheck: Long
        get() = prefs.getLong("lastAlarmCheck", 0L)
        set(v) { prefs.edit().putLong("lastAlarmCheck", v).apply() }
}
