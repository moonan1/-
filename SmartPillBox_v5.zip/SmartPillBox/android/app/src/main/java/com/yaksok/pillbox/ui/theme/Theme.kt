package com.yaksok.pillbox.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yaksok.pillbox.domain.DoseStatus

val Mint = Color(0xFF12A594)
val MintDark = Color(0xFF0B7A6E)
val MintSoft = Color(0xFFDDF4F0)
val MintFaint = Color(0xFFF0FAF8)
val Bg = Color(0xFFF5FAF9)
val Ink = Color(0xFF17302C)
val InkSoft = Color(0xFF5E716D)
val Line = Color(0xFFE2ECEA)

val OkGreen = Color(0xFF2E9E62)
val LateAmber = Color(0xFFE39B2D)
val MissRed = Color(0xFFDD5546)
val UnconfGray = Color(0xFF8B90A6)
val PlanBlue = Color(0xFF5A7A96)
val OpenTeal = Color(0xFF1E95B5)

fun statusColor(s: DoseStatus): Color = when (s) {
    DoseStatus.SCHEDULED -> PlanBlue
    DoseStatus.DUE -> Mint
    DoseStatus.OPENED -> OpenTeal
    DoseStatus.TAKEN -> OkGreen
    DoseStatus.LATE -> LateAmber
    DoseStatus.MISSED -> MissRed
    DoseStatus.UNCONFIRMED -> UnconfGray
}

private val colors = lightColorScheme(
    primary = Mint,
    onPrimary = Color.White,
    primaryContainer = MintSoft,
    onPrimaryContainer = MintDark,
    secondary = MintDark,
    background = Bg,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = MintFaint,
    onSurfaceVariant = InkSoft,
    outline = Line,
    outlineVariant = Line,
    error = MissRed,
    surfaceContainer = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainerHigh = Color.White,
    surfaceContainerHighest = MintFaint,
)

// 고령자도 읽기 쉽게 기본보다 큰 글자
private val type = Typography(
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, lineHeight = 40.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 35.sp, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.Bold, lineHeight = 31.sp),
    titleLarge = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp),
    titleMedium = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.SemiBold, lineHeight = 26.sp),
    titleSmall = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontSize = 18.sp, lineHeight = 27.sp),
    bodyMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodySmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
)

private val shapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun YaksokTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = type, shapes = shapes, content = content)
}
