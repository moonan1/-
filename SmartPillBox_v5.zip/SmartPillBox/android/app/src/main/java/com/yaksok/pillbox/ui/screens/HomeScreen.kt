package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.rememberCoroutineScope
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.Line
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.Overlay
import com.yaksok.pillbox.data.DataMode
import com.yaksok.pillbox.data.DeviceKind
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.device.BoxMode
import com.yaksok.pillbox.device.DeviceStatus
import com.yaksok.pillbox.device.LinkState
import com.yaksok.pillbox.device.SlotPhase
import com.yaksok.pillbox.domain.DoseStatus
import com.yaksok.pillbox.domain.Rules
import com.yaksok.pillbox.domain.status
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.EmptyState
import com.yaksok.pillbox.ui.components.IconCircle
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.ProgressBar
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.SlotBadge
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.components.StatusChip
import com.yaksok.pillbox.ui.dateLong
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.untilText
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen
import com.yaksok.pillbox.ui.theme.OpenTeal
import com.yaksok.pillbox.ui.theme.UnconfGray
import com.yaksok.pillbox.ui.theme.statusColor
import java.time.LocalDateTime

@Composable
fun HomeScreen(vm: AppViewModel, open: (Overlay) -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val newRx = d.prescriptions.count { it.status == RxStatus.NEW }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 20.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dateLong(now.toLocalDate()), style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                Text(if (pager.currentPage == 0) "오늘의 복약" else "의료진", style = MaterialTheme.typography.headlineLarge)
            }
            if (mode == DataMode.DEMO) Pill("시연 모드", LateAmber, filled = true)
            IconButton(onClick = { open(Overlay.Settings) }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.Settings, "설정", tint = InkSoft, modifier = Modifier.size(28.dp))
            }
        }
        // 페이지 표시 (옆으로 밀거나 눌러서 이동)
        Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("내 약통", "의료진 · 처방").forEachIndexed { i, label ->
                val sel = pager.currentPage == i
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(if (sel) Mint else Color.White)
                        .border(1.dp, if (sel) Mint else Line, RoundedCornerShape(50))
                        .clickable { scope.launch { pager.animateScrollToPage(i) } }
                        .heightIn(min = 44.dp).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(label, color = if (sel) Color.White else Ink, style = MaterialTheme.typography.labelLarge)
                    if (i == 1 && newRx > 0) {
                        Spacer(Modifier.width(6.dp))
                        Box(Modifier.size(22.dp).clip(CircleShape).background(MissRed), contentAlignment = Alignment.Center) {
                            Text("$newRx", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text(if (pager.currentPage == 0) "밀어서 의료진 ›" else "‹ 약통", style = MaterialTheme.typography.bodySmall, color = InkSoft,
                modifier = Modifier.align(Alignment.CenterVertically))
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f), beyondViewportPageCount = 1) { page ->
            if (page == 0) PillboxPage(vm, open) else CarePage(vm)
        }
    }
}

@Composable
private fun PillboxPage(vm: AppViewModel, open: (Overlay) -> Unit) {
    val d by vm.data.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val st by vm.deviceStatus.collectAsStateWithLifecycle()
    val kind by vm.deviceKind.collectAsStateWithLifecycle()

    val today = now.toLocalDate()
    val todays = d.records.filter { it.date == today }.sortedBy { it.time }
    val done = todays.count { it.confirmedAt != null }
    val next = todays.firstOrNull { it.confirmedAt == null && it.status(now) in setOf(DoseStatus.DUE, DoseStatus.OPENED, DoseStatus.SCHEDULED) }
    val views = slotViews(d, st, now)

    var detail by remember { mutableStateOf<DoseRecord?>(null) }
    var timeChoice by remember { mutableStateOf<DoseRecord?>(null) }
    var sheetSlot by remember { mutableStateOf<Int?>(null) }
    val confirm: (DoseRecord) -> Unit = { r -> if (needsTimeChoice(r, now)) timeChoice = r else vm.confirm(r.key) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { PillboxCard(views, st, kind, now, onSlot = { sheetSlot = it.slot }, onManage = { open(Overlay.Device) }) }
        item {
            NextDoseCard(
                next = next, now = now, allDone = todays.isNotEmpty() && done == todays.size, st = st,
                onConfirm = { confirm(it) },
                onReopen = { vm.devices.reopen(it.slot) },
            )
        }
        item { ProgressCard(done, todays.size, todays.count { it.status(now) == DoseStatus.MISSED || it.status(now) == DoseStatus.UNCONFIRMED }) }
        item {
            SectionTitle("오늘 복용할 약", trailing = { Text("${todays.size}회", color = InkSoft, style = MaterialTheme.typography.bodyLarge) })
        }
        if (todays.isEmpty()) {
            item {
                AppCard {
                    EmptyState(Icons.Filled.Medication, "오늘 복용할 약이 없어요", "약 관리에서 약과 복용 시간을 등록해 주세요.")
                    BigButton("약 추가하기", onClick = { open(Overlay.EditMed(null)) }, icon = Icons.Filled.Add, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        items(todays, key = { it.key }) { r ->
            DoseRow(r, now, onConfirm = { confirm(r) }, onClick = { detail = r })
        }
    }

    detail?.let { r0 ->
        val r = d.records.firstOrNull { it.key == r0.key } ?: r0
        DoseDetailDialog(r, now, onConfirm = { confirm(r) }, onUndo = { vm.undoConfirm(r.key) }, onDismiss = { detail = null })
    }
    timeChoice?.let { r -> ConfirmTimeDialog(r, now, onPick = { vm.confirm(r.key, it) }, onDismiss = { timeChoice = null }) }
    sheetSlot?.let { s ->
        val v = views[s - 1]
        CompartmentSheet(
            vm, v, now, connected = st.link == LinkState.CONNECTED, onDismiss = { sheetSlot = null },
            onConfirm = { confirm(it) },
            onReopen = { vm.devices.reopen(it) },
            onEditMed = { m -> sheetSlot = null; open(Overlay.EditMed(m?.id, s)) },
        )
    }
}

@Composable
private fun ProgressCard(done: Int, total: Int, missed: Int) {
    val p = if (total == 0) 0f else done.toFloat() / total
    AppCard(color = Mint) {
        Text("오늘 복용 진행", style = MaterialTheme.typography.titleMedium, color = Color.White.copy(alpha = 0.9f))
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$done", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(" / ${total}회 완료", style = MaterialTheme.typography.titleMedium, color = Color.White.copy(alpha = 0.9f), modifier = Modifier.padding(bottom = 4.dp))
            Spacer(Modifier.weight(1f))
            Text("${Math.round(p * 100)}%", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        }
        Spacer(Modifier.height(12.dp))
        ProgressBar(p, height = 18.dp, color = Color.White, track = Color.White.copy(alpha = 0.28f))
        if (missed > 0) {
            Spacer(Modifier.height(10.dp))
            Text("놓치거나 확인되지 않은 복용 ${missed}회", style = MaterialTheme.typography.bodyMedium, color = Color.White)
        }
    }
}

@Composable
private fun NextDoseCard(
    next: DoseRecord?,
    now: LocalDateTime,
    allDone: Boolean,
    st: DeviceStatus,
    onConfirm: (DoseRecord) -> Unit,
    onReopen: (DoseRecord) -> Unit,
) {
    AppCard {
        if (next == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconCircle(Icons.Filled.CheckCircle, OkGreen, size = 52.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(if (allDone) "오늘 복용을 모두 마쳤어요" else "남은 복용이 없어요", style = MaterialTheme.typography.titleLarge)
                    Text("수고하셨어요. 내일도 잊지 않게 알려드릴게요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                }
            }
            return@AppCard
        }
        val s = next.status(now)
        val due = s == DoseStatus.DUE || s == DoseStatus.OPENED
        Text(
            if (due) "지금 복용할 시간이에요" else "다음 복용 · ${untilText(now, next.scheduledAt)}",
            style = MaterialTheme.typography.titleMedium, color = if (due) Mint else InkSoft,
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(hm(next.time), style = MaterialTheme.typography.headlineLarge, color = statusColor(s))
                Text("${next.medName} · ${next.pills}정", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(6.dp))
                StatusChip(s)
            }
            SlotBadge(next.slot, size = 72.dp, color = statusColor(s))
        }
        if (due) {
            Spacer(Modifier.height(14.dp))
            BigButton("복용 완료", onClick = { onConfirm(next) }, icon = Icons.Filled.CheckCircle, modifier = Modifier.fillMaxWidth())
            val slotPhase = st.slots.getOrNull(next.slot - 1)
            val canReopen = st.link == LinkState.CONNECTED && next.openedAt != null && slotPhase == SlotPhase.CLOSED
            if (canReopen) {
                Spacer(Modifier.height(8.dp))
                SoftButton("약통 칸 다시 열기", onClick = { onReopen(next) }, icon = Icons.Filled.Refresh, modifier = Modifier.fillMaxWidth())
            }
            if (s == DoseStatus.DUE && st.link == LinkState.CONNECTED && next.openedAt == null) {
                Spacer(Modifier.height(8.dp))
                Text("약통이 칸을 열면 '약통 개방 감지'로 표시돼요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
            Spacer(Modifier.height(6.dp))
            Text("예정 시각 ${Rules.CONFIRM_WINDOW_MIN / 60}시간 이내에 확인해 주세요. 10분 넘게 늦으면 '복용 지연'으로 기록돼요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
        }
    }
}
