package com.yaksok.pillbox.device

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate
import java.time.LocalDateTime

/*
 * 하드웨어 통신 계층.
 *  - PillBoxDevice: 앱이 사용하는 약통 기능 (구현: 시뮬레이터 / 실제 약통)
 *  - LineTransport: 실제 약통과 한 줄 단위 텍스트를 주고받는 통로 (USB 유선, 추후 블루투스·Wi-Fi)
 * 통신 모듈이 정해지면 LineTransport 구현 하나만 추가하면 된다. 명령 형식은 docs/PROTOCOL.md 참고.
 */

enum class LinkState(val label: String) {
    DISCONNECTED("연결 안 됨"), CONNECTING("연결 중"), CONNECTED("연결됨"), ERROR("연결 오류")
}

enum class SlotPhase(val label: String) {
    CLOSED("닫힘"), QUEUED("열기 대기"), OPENING("여는 중"), OPEN("열림"),
    CLOSING("닫는 중"), REFILL("보충 열림"), UNKNOWN("확인 불가");

    val isOpenish get() = this == QUEUED || this == OPENING || this == OPEN || this == REFILL

    companion object {
        fun fromChar(c: Char) = when (c) {
            'C' -> CLOSED; 'q' -> QUEUED; 'o' -> OPENING; 'O' -> OPEN
            'x', 'c' -> CLOSING; 'R' -> REFILL; else -> UNKNOWN
        }
    }
}

enum class BoxMode(val label: String) {
    NORMAL("정상"), NEED_TIME("시간 설정 필요"), RECOVERY("위치 복구 필요"), UNKNOWN("확인 전")
}

data class DeviceStatus(
    val link: LinkState = LinkState.DISCONNECTED,
    val message: String = "",
    val firmware: String? = null,
    val clockOk: Boolean = false,
    val boxTime: LocalDateTime? = null,
    val mode: BoxMode = BoxMode.UNKNOWN,
    val slots: List<SlotPhase> = List(6) { SlotPhase.UNKNOWN },
    val lastSeq: Int = 0,
    val scheduleChecksum: Int? = null,
    val scheduleCount: Int = 0,
    val lastSeenMillis: Long = 0,
    val simLinkDown: Boolean = false,
)

/** 약통 이벤트 (약통 → 앱). 약통 EEPROM에 순번과 함께 저장되어 재연결 후 다시 받을 수 있다. */
data class BoxEvent(val seq: Int, val type: Int, val arg: Int, val at: LocalDateTime?) {
    val text: String get() = BoxProtocol.describe(this)
}

/** 약통에 저장되는 예약 1건 */
data class BoxEntry(val slot: Int, val hour: Int, val minute: Int, val days: Int, val startDay: Int, val endDay: Int)

data class BoxSchedule(val entries: List<BoxEntry>, val holdSec: Int, val graceMin: Int) {
    val checksum: Int get() = BoxProtocol.checksum(this)
}

sealed class CmdResult {
    data class Ok(val value: String = "") : CmdResult()
    data class Err(val code: String) : CmdResult()

    val isOk get() = this is Ok
    val errorText: String get() = if (this is Err) BoxProtocol.errorText(code) else ""
}

interface PillBoxDevice {
    val status: StateFlow<DeviceStatus>
    val events: SharedFlow<BoxEvent>
    val kindKey: String

    suspend fun connect(): Boolean
    suspend fun disconnect()
    suspend fun setTime(t: LocalDateTime): CmdResult
    suspend fun pushSchedule(s: BoxSchedule): CmdResult
    suspend fun fetchLog(fromSeq: Int): List<BoxEvent>?
    suspend fun reopen(slot: Int): CmdResult
    suspend fun markTaken(slot: Int): CmdResult
    suspend fun refill(slot: Int): CmdResult
    suspend fun close(slot: Int): CmdResult
    suspend fun stop(): CmdResult
    suspend fun recover(): CmdResult
}

interface LineTransport {
    val name: String
    /** 줄 수신 콜백 (수신 스레드에서 호출됨) */
    var onLine: ((String) -> Unit)?
    /** 연결이 끊겼을 때 */
    var onClosed: ((Throwable?) -> Unit)?
    suspend fun open()
    suspend fun close()
    suspend fun writeLine(line: String)
}

/** 약통 프로토콜 공통 정의 */
object BoxProtocol {
    const val EV_BOOT = 1
    const val EV_TIME_SET = 2
    const val EV_SCHED_SAVED = 3
    const val EV_DOSE_OPEN = 4
    const val EV_AUTO_CLOSE = 5
    const val EV_REOPEN = 6
    const val EV_TAKEN = 7
    const val EV_REFILL_OPEN = 8
    const val EV_SLOT_CLOSE = 9
    const val EV_STOP = 10
    const val EV_RECOVERY_NEEDED = 11
    const val EV_RECOVERED = 12
    const val EV_CLOCK_GAP = 13
    const val EV_CLOCK_INVALID = 14
    const val EV_STORAGE_ERROR = 15
    const val EV_DOSE_BLOCKED = 16

    private val EPOCH: LocalDateTime = LocalDateTime.of(2000, 1, 1, 0, 0)
    private val EPOCH_DATE: LocalDate = LocalDate.of(2000, 1, 1)

    fun toBoxSeconds(t: LocalDateTime): Long = java.time.Duration.between(EPOCH, t).seconds
    fun fromBoxSeconds(s: Long): LocalDateTime? = if (s <= 0) null else EPOCH.plusSeconds(s)
    fun dayNumber(d: LocalDate): Int = java.time.temporal.ChronoUnit.DAYS.between(EPOCH_DATE, d).toInt()

    /** 펌웨어 cfgChecksum()과 같은 Fletcher-16 */
    fun checksum(s: BoxSchedule): Int {
        var s1 = 0; var s2 = 0
        fun f(x: Int) { s1 = (s1 + (x and 0xFF)) % 255; s2 = (s2 + s1) % 255 }
        f(s.entries.size); f(s.holdSec and 0xFF); f(s.holdSec shr 8); f(s.graceMin)
        for (e in s.entries) {
            f(e.slot); f(e.hour); f(e.minute); f(e.days)
            f(e.startDay and 0xFF); f(e.startDay shr 8); f(e.endDay and 0xFF); f(e.endDay shr 8)
        }
        return (s2 shl 8) or s1
    }

    fun describe(e: BoxEvent): String {
        val slot = "${e.arg}번 칸"
        return when (e.type) {
            EV_BOOT -> if (e.arg == 1) "약통 시작 (위치 복구 필요 상태)" else "약통 전원 켜짐"
            EV_TIME_SET -> "약통 시계 설정"
            EV_SCHED_SAVED -> "복용 일정 ${e.arg}건 저장"
            EV_DOSE_OPEN -> "$slot 복용 시간 · 열림"
            EV_AUTO_CLOSE -> "$slot 자동 닫힘"
            EV_REOPEN -> "$slot 다시 열림"
            EV_TAKEN -> "$slot 복용 완료 반영"
            EV_REFILL_OPEN -> "$slot 약 보충용 열림"
            EV_SLOT_CLOSE -> "$slot 닫기 요청"
            EV_STOP -> "모터 정지"
            EV_RECOVERY_NEEDED -> "움직이는 중 전원이 끊겨 위치 복구 필요"
            EV_RECOVERED -> "닫힘 위치 복구 완료"
            EV_CLOCK_GAP -> "시계 변경 감지 · 지난 예약은 건너뜀"
            EV_CLOCK_INVALID -> "약통 시계 오류"
            EV_STORAGE_ERROR -> if (e.arg == 9) "기기 오류 (시뮬레이션)" else "약통 저장 공간 오류"
            EV_DOSE_BLOCKED -> "$slot 복용 시간이지만 위치 복구 상태라 열지 않음"
            else -> "알 수 없는 이벤트 (${e.type})"
        }
    }

    fun level(e: BoxEvent): Int = when (e.type) {
        EV_RECOVERY_NEEDED, EV_CLOCK_INVALID, EV_STORAGE_ERROR, EV_DOSE_BLOCKED -> 2
        EV_STOP, EV_CLOCK_GAP -> 1
        else -> 0
    }

    fun errorText(code: String): String = when (code.removePrefix("ERR ").trim()) {
        "NODOSE" -> "지금은 이 칸의 복용 회차가 없어요."
        "TAKEN" -> "이미 복용 완료로 기록되어 다시 열 수 없어요."
        "USED" -> "이 회차의 다시 열기는 이미 사용했어요."
        "LATE" -> "다시 열기 허용 시간이 지났어요."
        "BUSY" -> "칸이 이미 열려 있거나 움직이는 중이에요."
        "STATE" -> "약통이 위치 복구 상태예요. 기기 화면에서 복구를 먼저 진행하세요."
        "RTC" -> "약통 시계가 설정되지 않았어요."
        "STORAGE" -> "약통 저장에 실패했어요."
        "CHECKSUM", "COUNT" -> "일정 전송이 손상됐어요. 다시 시도하세요."
        "FULL" -> "약통에 저장할 수 있는 일정(24개)을 넘었어요."
        "TIMEOUT" -> "약통 응답이 없어요."
        "OFFLINE" -> "약통이 연결되어 있지 않아요."
        else -> "약통 오류: $code"
    }
}
