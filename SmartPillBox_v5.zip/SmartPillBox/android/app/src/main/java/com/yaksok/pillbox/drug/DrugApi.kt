package com.yaksok.pillbox.drug

import com.yaksok.pillbox.data.DrugInfo
import com.yaksok.pillbox.data.DurItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDateTime

/** 검색 결과 한 건 */
data class DrugHit(val itemSeq: String, val name: String, val entpName: String, val imageUrl: String?, val kind: String = "")

class DrugLookupException(message: String) : Exception(message)

/**
 * 식약처 공개 의약품 정보 조회 (공공데이터포털).
 *  - e약은요(DrbEasyDrugInfoService): 효능, 사용법, 주의사항, 상호작용, 부작용, 보관법, 사진
 *  - 의약품 제품 허가정보(DrugPrdtPrmsnInfoService08): 전문약 검색, 성상(생김새), 성분, 효능효과/용법용량/주의사항 문서
 *  - DUR 품목정보(DURPrdlstInfoService03): 병용금기, 노인주의, 임부금기, 연령금기, 용량·투여기간 주의, 효능군 중복, 분할주의
 * 인증키는 빌드할 때 BuildConfig.DATA_GO_KR_KEY 로 들어온다(GitHub Secret). 코드에는 키를 두지 않는다.
 */
class DrugApi(private val serviceKey: String) {
    val available: Boolean get() = serviceKey.isNotBlank()

    private val base = "https://apis.data.go.kr/1471000"

    private fun keyParam(): String =
        // Decoding 키(+,/,= 포함)는 인코딩하고, 이미 인코딩된 키(% 포함)는 그대로 사용
        if (serviceKey.contains('%')) serviceKey else URLEncoder.encode(serviceKey, "UTF-8")

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private suspend fun getItems(path: String, params: Map<String, String>): List<JSONObject> = withContext(Dispatchers.IO) {
        val q = buildString {
            append("serviceKey=").append(keyParam())
            append("&type=json")
            params.forEach { (k, v) -> append('&').append(k).append('=').append(enc(v)) }
        }
        val conn = (URL("$base/$path?$q").openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 12000
            setRequestProperty("Accept", "application/json")
        }
        val text = try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        } catch (e: IOException) {
            throw DrugLookupException("인터넷 연결을 확인해 주세요.")
        } finally { conn.disconnect() }
        parseItems(text)
    }

    /** 응답 본문에서 items 배열을 꺼낸다 (서비스마다 모양이 조금씩 다름) */
    internal fun parseItems(text: String): List<JSONObject> {
        val t = text.trim()
        if (t.startsWith("<")) {
            // 키 오류 등은 XML로 온다
            if (t.contains("SERVICE_KEY") || t.contains("SERVICE ERROR") || t.contains("UNREGISTERED"))
                throw DrugLookupException("약 정보 서비스에 연결하지 못했어요. 잠시 후 다시 시도해 주세요.")
            if (t.contains("NODATA") || t.contains("totalCount>0<")) return emptyList()
            throw DrugLookupException("약 정보 서비스 응답을 읽지 못했어요.")
        }
        if (t.isEmpty()) return emptyList()
        val root = JSONObject(t)
        val body = root.optJSONObject("body") ?: root.optJSONObject("response")?.optJSONObject("body") ?: return emptyList()
        val items = body.opt("items")
        return when (items) {
            // 일부 서비스는 배열 원소가 {"item": {...}} 형태
            is JSONArray -> (0 until items.length()).mapNotNull { k -> items.optJSONObject(k)?.let { o -> o.optJSONObject("item") ?: o } }
            is JSONObject -> when (val item = items.opt("item")) {
                is JSONArray -> (0 until item.length()).mapNotNull { item.optJSONObject(it) }
                is JSONObject -> listOf(item)
                else -> emptyList()
            }
            else -> emptyList()
        }
    }

    private fun JSONObject.s(vararg keys: String): String {
        for (k in keys) {
            if (has(k) && !isNull(k)) {
                val v = optString(k, "").trim()
                if (v.isNotEmpty() && v != "null") return v
            }
        }
        return ""
    }

    /** 이름으로 검색: 일반약(e약은요) + 전문약(허가정보)을 합쳐 중복 제거 */
    suspend fun search(name: String): List<DrugHit> = coroutineScope {
        val q = name.trim()
        if (q.length < 2) return@coroutineScope emptyList()
        val easy = async { runCatching { getItems("DrbEasyDrugInfoService/getDrbEasyDrugList", mapOf("itemName" to q, "pageNo" to "1", "numOfRows" to "20")) } }
        val permit = async { runCatching { getItems("DrugPrdtPrmsnInfoService08/getDrugPrdtPrmsnInq08", mapOf("item_name" to q, "pageNo" to "1", "numOfRows" to "30")) } }
        val a = easy.await(); val b = permit.await()
        if (a.isFailure && b.isFailure) throw (a.exceptionOrNull() as? DrugLookupException ?: DrugLookupException("검색에 실패했어요. 인터넷 연결을 확인해 주세요."))
        val out = LinkedHashMap<String, DrugHit>()
        a.getOrNull().orEmpty().forEach { o ->
            val seq = o.s("itemSeq", "ITEM_SEQ"); if (seq.isEmpty()) return@forEach
            out[seq] = DrugHit(seq, o.s("itemName", "ITEM_NAME"), o.s("entpName", "ENTP_NAME"), o.s("itemImage").ifEmpty { null }, "일반의약품")
        }
        b.getOrNull().orEmpty().forEach { o ->
            val seq = o.s("ITEM_SEQ", "itemSeq"); if (seq.isEmpty()) return@forEach
            val prev = out[seq]
            val kind = o.s("ETC_OTC_CODE", "SPCLTY_PBLC").ifEmpty { prev?.kind ?: "" }
            val img = prev?.imageUrl ?: o.s("BIG_PRDT_IMG_URL", "ITEM_IMAGE").ifEmpty { null }
            out[seq] = DrugHit(seq, prev?.name ?: o.s("ITEM_NAME"), prev?.entpName ?: o.s("ENTP_NAME"), img, kind)
        }
        // 검색어로 시작하는 이름을 먼저
        out.values.sortedWith(compareBy<DrugHit>({ !it.name.startsWith(q) }, { it.name.length })).take(40)
    }

    /** 상세 정보 (세 서비스 결과를 합친다). 일부 서비스가 실패해도 가능한 정보는 돌려준다. */
    suspend fun detail(itemSeq: String, fallbackName: String = ""): DrugInfo = coroutineScope {
        val easy = async { runCatching { getItems("DrbEasyDrugInfoService/getDrbEasyDrugList", mapOf("itemSeq" to itemSeq)).firstOrNull() } }
        val permit = async { runCatching { getItems("DrugPrdtPrmsnInfoService08/getDrugPrdtPrmsnDtlInq08", mapOf("item_seq" to itemSeq)).firstOrNull() } }
        val durList = async { runCatching { getItems("DURPrdlstInfoService03/getDurPrdlstInfoList03", mapOf("itemSeq" to itemSeq)) } }
        val e = easy.await().getOrNull()
        val p = permit.await().getOrNull()
        if (e == null && p == null && easy.await().isFailure && permit.await().isFailure)
            throw (easy.await().exceptionOrNull() as? DrugLookupException ?: DrugLookupException("약 정보를 불러오지 못했어요."))

        // DUR: 해당되는 유형만 상세 조회
        val types = durList.await().getOrNull().orEmpty().flatMap { it.s("TYPE_NAME", "typeName").split(",", "/") }.map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        val durEndpoints = mapOf(
            "병용금기" to "getUsjntTabooInfoList03", "노인주의" to "getOdsnAtentInfoList03", "특정연령대금기" to "getSpcifyAgrdeTabooInfoList03",
            "연령금기" to "getSpcifyAgrdeTabooInfoList03", "임부금기" to "getPwnmTabooInfoList03", "용량주의" to "getCpctyAtentInfoList03",
            "투여기간주의" to "getMdctnPdAtentInfoList03", "효능군중복" to "getEfcyDplctInfoList03", "분할주의" to "getSeobangjeongPartitnAtentInfoList03",
            "서방정분할주의" to "getSeobangjeongPartitnAtentInfoList03",
        )
        val wanted = types.mapNotNull { t -> durEndpoints.entries.firstOrNull { t.replace(" ", "").contains(it.key) }?.let { it.key to it.value } }.distinctBy { it.second }
        val dur = wanted.map { (type, ep) ->
            async {
                runCatching { getItems("DURPrdlstInfoService03/$ep", mapOf("itemSeq" to itemSeq, "numOfRows" to "30")) }.getOrNull().orEmpty().map { o ->
                    DurItem(
                        type = o.s("TYPE_NAME").ifEmpty { type },
                        content = clean(o.s("PROHBT_CONTENT", "REMARK", "SERS_NAME", "EFFECT_NAME")),
                        partner = o.s("MIXTURE_ITEM_NAME", "MIXTURE_INGR_KOR_NAME"),
                    )
                }
            }
        }.awaitAll().flatten().distinct().take(40)
        // 병용금기는 상대 약 목록만 따로 모으고, 나머지 유형은 내용별로 정리
        val merged = dur.groupBy { it.type to it.content }.map { (k, v) ->
            DurItem(k.first, k.second, v.mapNotNull { it.partner.ifBlank { null } }.distinct().take(8).joinToString(", "))
        }.ifEmpty { types.map { DurItem(it, "") } }

        fun pick(vararg v: String?): String = v.firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""
        DrugInfo(
            itemSeq = itemSeq,
            name = pick(e?.s("itemName"), p?.s("ITEM_NAME"), fallbackName),
            entpName = pick(e?.s("entpName"), p?.s("ENTP_NAME")),
            imageUrl = pick(e?.s("itemImage"), p?.s("BIG_PRDT_IMG_URL", "ITEM_IMAGE")).ifEmpty { null },
            kind = pick(p?.s("ETC_OTC_CODE", "SPCLTY_PBLC"), if (e != null) "일반의약품" else null),
            chart = clean(pick(p?.s("CHART"))),
            ingredients = clean(pick(p?.s("MAIN_ITEM_INGR", "MATERIAL_NAME", "MAIN_INGR_ENG"))).replace(Regex("\\[M\\d+\\]"), "").trim(),
            efficacy = clean(pick(e?.s("efcyQesitm"))).ifEmpty { docText(pick(p?.s("EE_DOC_DATA"))) },
            useMethod = clean(pick(e?.s("useMethodQesitm"))).ifEmpty { docText(pick(p?.s("UD_DOC_DATA"))) },
            warning = clean(pick(e?.s("atpnWarnQesitm"))),
            caution = clean(pick(e?.s("atpnQesitm"))).ifEmpty { docText(pick(p?.s("NB_DOC_DATA"))).take(1500) },
            interaction = clean(pick(e?.s("intrcQesitm"))),
            sideEffect = clean(pick(e?.s("seQesitm"))),
            storage = clean(pick(e?.s("depositMethodQesitm"), p?.s("STORAGE_METHOD"))),
            dur = merged,
            fetchedAt = LocalDateTime.now(),
        )
    }

    companion object {
        /** HTML 태그·엔티티 제거 */
        fun clean(s: String): String = s
            .replace(Regex("(?i)<br\\s*/?>|</p>|</PARAGRAPH>|</ARTICLE>"), "\n")
            .replace(Regex("<[^>]+>"), "")
            .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            .lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
            .trim()

        /** 허가 문서(XML 형태 문자열)를 읽기 좋은 글로 */
        fun docText(xml: String): String {
            if (xml.isBlank()) return ""
            val withTitles = xml.replace(Regex("<ARTICLE[^>]*title=\"([^\"]*)\"[^>]*>")) { m -> "\n" + m.groupValues[1] + "\n" }
            return clean(withTitles.replace("<![CDATA[", "").replace("]]>", ""))
        }
    }
}
