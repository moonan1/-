package com.yaksok.pillbox.domain

import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.ChatMessage
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.data.MsgKind
import com.yaksok.pillbox.data.Period
import com.yaksok.pillbox.data.Prescription
import com.yaksok.pillbox.data.RxItem
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.data.SLOT_COUNT
import java.time.LocalDateTime
import java.util.UUID
import kotlin.math.roundToInt

/**
 * 처방 반영. 의사가 보낸 처방은 자동 적용하지 않고, 사용자가 내용을 확인하고 칸을 정한 뒤에만 약 관리에 반영한다.
 * 실제 처방전 발급·조제는 병원/약국에서 이루어지며, 앱은 처방 내용을 복용 일정으로 옮기는 역할만 한다.
 */
object PrescriptionLogic {
    fun matchExisting(meds: List<Medication>, item: RxItem): Medication? =
        meds.firstOrNull { it.name.trim().equals(item.name.trim(), ignoreCase = true) }

    /** 새 칸이 필요한 처방 항목 index */
    fun itemsNeedingSlot(d: AppData, rx: Prescription): List<Int> =
        rx.items.indices.filter { matchExisting(d.meds, rx.items[it]) == null }

    fun freeSlots(d: AppData): List<Int> = (1..SLOT_COUNT).filter { s -> d.meds.none { it.slot == s } }

    /** @param slotFor 새 약 항목 index → 칸 번호 */
    fun apply(d: AppData, rx: Prescription, slotFor: Map<Int, Int>, now: LocalDateTime): AppData {
        val today = now.toLocalDate()
        var meds = d.meds
        val changed = ArrayList<String>()
        rx.items.forEachIndexed { i, item ->
            val end = today.plusDays(item.durationDays.toLong() - 1)
            val ex = matchExisting(meds, item)
            if (ex != null) {
                meds = meds.map {
                    if (it.id == ex.id) it.copy(
                        pillsPerDose = item.pillsPerDose, times = item.times.distinct().sorted(), weekdays = item.weekdays,
                        startDate = if (it.startDate.isAfter(today)) today else it.startDate, endDate = end,
                        memo = item.note.ifBlank { it.memo },
                    ) else it
                }
                changed += "${item.name}(${ex.slot}번 칸) 갱신"
            } else {
                val slot = slotFor[i] ?: error("칸이 지정되지 않은 처방 항목")
                require(meds.none { it.slot == slot }) { "${slot}번 칸은 이미 사용 중" }
                meds = meds + Medication(
                    id = UUID.randomUUID().toString(), name = item.name, pillsPerDose = item.pillsPerDose,
                    times = item.times.distinct().sorted(), weekdays = item.weekdays, startDate = today, endDate = end,
                    slot = slot, memo = item.note,
                )
                changed += "${item.name} → ${slot}번 칸"
            }
        }
        val msg = ChatMessage(UUID.randomUUID().toString(), now, false, "처방을 약 관리에 반영했어요: ${changed.joinToString(", ")}", MsgKind.SYSTEM, rx.id)
        val next = d.copy(
            meds = meds,
            prescriptions = d.prescriptions.map { if (it.id == rx.id) it.copy(status = RxStatus.APPLIED, handledAt = now) else it },
            chat = d.chat + msg,
        )
        return DoseGenerator.refreshToday(next, now)
    }

    fun decline(d: AppData, rx: Prescription, now: LocalDateTime): AppData = d.copy(
        prescriptions = d.prescriptions.map { if (it.id == rx.id) it.copy(status = RxStatus.DECLINED, handledAt = now) else it },
        chat = d.chat + ChatMessage(UUID.randomUUID().toString(), now, false, "처방을 반영하지 않았어요. 궁금한 점은 의료진에게 문의하세요.", MsgKind.SYSTEM, rx.id),
    )

    /** 의료진에게 보내는 복약 리포트 (최근 7일 / 30일) */
    fun buildReport(d: AppData, now: LocalDateTime): String {
        val a = Analytics(d.records, now)
        val w = a.summaryLast(7)
        val m = a.summaryLast(30)
        val weak = a.weakestPeriod(30)
        return buildString {
            appendLine("[복약 리포트] ${now.toLocalDate()} 기준")
            appendLine("· 복용 중인 약: " + d.meds.sortedBy { it.slot }.joinToString(", ") { "${it.name} ${it.pillsPerDose}정" }.ifBlank { "없음" })
            appendLine("· 최근 7일 이행률 ${pct(w.adherence)} (확인 ${w.taken}/${w.total}회, 미복용 ${w.missed}, 미확인 ${w.unconfirmed})")
            appendLine("· 최근 30일 이행률 ${pct(m.adherence)}, 정시 복용 ${pct(m.onTimeRate)}")
            append("· 평균 복용 지연 ${m.avgDelayMin?.let { "${it.roundToInt()}분" } ?: "-"}")
            if (weak != null) append("\n· 자주 늦거나 놓치는 시간대: ${weak.period.label}")
        }
    }

    fun periodsText(item: RxItem): String =
        item.times.sorted().joinToString(", ") { "${Period.of(it).label} %02d:%02d".format(it.hour, it.minute) }
}
