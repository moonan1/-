package com.yaksok.pillbox.domain

import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.data.Medication
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

/** 판정 기준 (규칙 기반) */
object Rules {
    const val ON_TIME_MIN = 10L          // 예정 시각 + 10분 이내 확인 = 정시 복용
    const val CONFIRM_WINDOW_MIN = 120L  // 예정 시각 + 2시간까지 확인이 없으면 미복용/확인되지 않음
    const val EARLY_CONFIRM_MIN = 60L    // 예정 시각 60분 전부터 복용 확인 가능
}

enum class DoseStatus(val label: String) {
    SCHEDULED("복용 예정"),
    DUE("복용 시간"),
    OPENED("약통 개방 감지"),
    TAKEN("복용 완료"),
    LATE("복용 지연"),
    MISSED("미복용"),
    UNCONFIRMED("확인되지 않음");

    val isFinal get() = this == TAKEN || this == LATE || this == MISSED || this == UNCONFIRMED
    val isTaken get() = this == TAKEN || this == LATE
}

fun DoseRecord.status(now: LocalDateTime): DoseStatus {
    val c = confirmedAt
    if (c != null) return if (delayMinutes()!! <= Rules.ON_TIME_MIN) DoseStatus.TAKEN else DoseStatus.LATE
    if (now.isBefore(scheduledAt)) return DoseStatus.SCHEDULED
    val windowEnd = scheduledAt.plusMinutes(Rules.CONFIRM_WINDOW_MIN)
    if (now.isBefore(windowEnd)) return if (openedAt != null) DoseStatus.OPENED else DoseStatus.DUE
    return if (openedAt != null) DoseStatus.UNCONFIRMED else DoseStatus.MISSED
}

/** 복용 확인 지연(분). 일찍 복용하면 0 */
fun DoseRecord.delayMinutes(): Long? =
    confirmedAt?.let { maxOf(0L, Duration.between(scheduledAt, it).toMinutes()) }

fun DoseRecord.canConfirm(now: LocalDateTime): Boolean =
    confirmedAt == null && !now.isBefore(scheduledAt.minusMinutes(Rules.EARLY_CONFIRM_MIN)) &&
        now.isBefore(scheduledAt.plusMinutes(Rules.CONFIRM_WINDOW_MIN))

/**
 * 복용 회차 생성.
 * - 지난 날짜는 한 번 생성하면 고정(약을 수정해도 과거 기록은 바뀌지 않음).
 * - 오늘 회차는 약을 수정하면 아직 오지 않은 회차만 다시 만든다.
 */
object DoseGenerator {
    private const val MAX_BACKFILL_DAYS = 31L

    fun occurrences(meds: List<Medication>, date: LocalDate): List<DoseRecord> =
        meds.filter { it.isActiveOn(date) }.flatMap { m ->
            m.times.distinct().sorted().map { t ->
                DoseRecord(DoseRecord.keyOf(m.id, date, t), m.id, m.name, m.pillsPerDose, m.slot, date, t)
            }
        }

    /** 마지막 생성일 다음 날부터 오늘까지 회차를 만든다 */
    fun ensure(d: AppData, today: LocalDate): AppData {
        val last = d.lastGenerated ?: today.minusDays(1)
        if (!last.isBefore(today)) return d
        var date = maxOf(last.plusDays(1), today.minusDays(MAX_BACKFILL_DAYS))
        val keys = d.records.mapTo(HashSet()) { it.key }
        val added = ArrayList<DoseRecord>()
        while (!date.isAfter(today)) {
            occurrences(d.meds, date).filterTo(added) { it.key !in keys }
            date = date.plusDays(1)
        }
        return d.copy(records = d.records + added, lastGenerated = today)
    }

    /** 약 추가/수정/삭제 뒤 오늘의 남은 회차를 다시 맞춘다 */
    fun refreshToday(d: AppData, now: LocalDateTime): AppData {
        val today = now.toLocalDate()
        val base = ensure(d, today)
        val medIds = base.meds.associateBy { it.id }
        val wanted = occurrences(base.meds, today).filter { it.scheduledAt.isAfter(now) }
        val wantedKeys = wanted.mapTo(HashSet()) { it.key }
        // 오늘, 아직 오지 않았고 아무 기록이 없는 회차 중 더 이상 필요 없는 것 제거
        val kept = base.records.filter { r ->
            if (r.isTest || r.date != today || !r.scheduledAt.isAfter(now)) true
            else if (r.openedAt != null || r.confirmedAt != null) true
            else r.key in wantedKeys && medIds.containsKey(r.medId)
        }
        val keptKeys = kept.mapTo(HashSet()) { it.key }
        // 이름/수량/칸 변경을 오늘 남은 회차에 반영
        val updated = kept.map { r ->
            val m = medIds[r.medId]
            if (m != null && r.date == today && r.scheduledAt.isAfter(now) && r.confirmedAt == null && !r.isTest)
                r.copy(medName = m.name, pills = m.pillsPerDose, slot = m.slot) else r
        }
        return base.copy(records = updated + wanted.filter { it.key !in keptKeys })
    }
}
