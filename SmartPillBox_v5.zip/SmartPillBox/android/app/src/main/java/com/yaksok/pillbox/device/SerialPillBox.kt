package com.yaksok.pillbox.device

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * 실제 약통(ver7 펌웨어)과 텍스트 명령으로 통신한다. 통신 수단(USB/블루투스)은 LineTransport가 담당.
 * - 모든 명령에 번호(#id)를 붙이고 같은 번호의 응답(@id)을 기다린다.
 * - 응답이 없으면 같은 번호로 1회 재전송한다. 약통은 같은 번호를 두 번 실행하지 않는다(중복 명령 방지).
 * - 1초마다 오는 ST(상태) 줄이 6초 넘게 없으면 연결이 끊긴 것으로 본다.
 */
class SerialPillBox(private val transport: LineTransport, override val kindKey: String) : PillBoxDevice {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _status = MutableStateFlow(DeviceStatus())
    override val status: StateFlow<DeviceStatus> = _status.asStateFlow()
    private val _events = MutableSharedFlow<BoxEvent>(extraBufferCapacity = 128)
    override val events: SharedFlow<BoxEvent> = _events.asSharedFlow()

    private class Pending(val id: Int, val deferred: CompletableDeferred<String>, val evs: MutableList<BoxEvent>)

    private val reqMutex = Mutex()
    @Volatile private var pending: Pending? = null
    @Volatile private var opened = false
    private var watchdog: Job? = null
    private var idCounter = (1..30000).random()   // 앱 재시작 후에도 약통의 '직전 번호'와 겹치지 않도록

    private fun nextId(): Int { idCounter = if (idCounter >= 65000) 1 else idCounter + 1; return idCounter }

    override suspend fun connect(): Boolean {
        if (opened && _status.value.link == LinkState.CONNECTED) return true
        _status.update { it.copy(link = LinkState.CONNECTING, message = "${transport.name} 연결 중…") }
        transport.onLine = { handleLine(it) }
        transport.onClosed = { err -> linkLost(err?.message ?: "연결이 끊겼어요") }
        return try {
            transport.open()
            opened = true
            _status.update { it.copy(message = "약통 재시작 대기 중…") }
            delay(2300)   // UNO는 시리얼 포트를 열면 재시작된다
            var hello: CmdResult = CmdResult.Err("TIMEOUT")
            repeat(3) { if (!hello.isOk) hello = request("HELLO", 2500, retries = 0) }
            val value = (hello as? CmdResult.Ok)?.value
                ?: throw IOException("약통 응답이 없어요. ver7 펌웨어 업로드와 시리얼 모니터 종료를 확인하세요.")
            val parts = value.split(" ")
            if (parts.getOrNull(0) != "PILLBOX") throw IOException("약속 약통 펌웨어가 아니에요.")
            _status.update { it.copy(firmware = "ver${parts.getOrNull(1) ?: "?"}", lastSeenMillis = System.currentTimeMillis()) }
            request("STATUS")
            _status.update { it.copy(link = LinkState.CONNECTED, message = "${transport.name} 연결됨") }
            startWatchdog()
            true
        } catch (e: Exception) {
            opened = false
            runCatching { transport.close() }
            _status.update { it.copy(link = LinkState.ERROR, message = e.message ?: "연결에 실패했어요") }
            false
        }
    }

    override suspend fun disconnect() {
        watchdog?.cancel()
        opened = false
        pending?.deferred?.cancel()
        runCatching { transport.close() }
        _status.update { DeviceStatus(link = LinkState.DISCONNECTED, message = "연결을 해제했어요", firmware = it.firmware) }
    }

    private fun linkLost(reason: String) {
        if (!opened) return
        opened = false
        watchdog?.cancel()
        pending?.deferred?.cancel()
        _status.update { it.copy(link = LinkState.ERROR, message = reason, slots = List(6) { SlotPhase.UNKNOWN }) }
        scope.launch { runCatching { transport.close() } }
    }

    private fun startWatchdog() {
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                delay(1000)
                if (opened && System.currentTimeMillis() - _status.value.lastSeenMillis > 6000) {
                    linkLost("약통 응답이 끊겼어요. 케이블과 전원을 확인하세요.")
                }
            }
        }
    }

    // ───────── 수신 처리 ─────────
    private fun handleLine(raw: String) {
        val line = raw.trim()
        if (line.isEmpty()) return
        when {
            line.startsWith("@") -> {
                val sp = line.indexOf(' ')
                val id = line.substring(1, if (sp < 0) line.length else sp).toIntOrNull() ?: return
                val rest = if (sp < 0) "" else line.substring(sp + 1)
                val p = pending
                if (p != null && p.id == id) p.deferred.complete(rest)
            }
            line.startsWith("ST ") -> parseStatus(line)
            line.startsWith("EV ") -> parseEvent(line)?.let { ev ->
                pending?.evs?.add(ev)
                _events.tryEmit(ev)
            }
        }
    }

    private fun parseStatus(line: String) {
        // ST <시계정상> <초> <모드> <칸6자> <마지막이벤트> <일정체크섬> <일정수>
        val p = line.split(" ")
        if (p.size < 8) return
        val clockOk = p[1] == "1"
        val secs = p[2].toLongOrNull() ?: 0L
        val mode = when (p[3]) { "0" -> BoxMode.NORMAL; "1" -> BoxMode.NEED_TIME; "2" -> BoxMode.RECOVERY; else -> BoxMode.UNKNOWN }
        val slots = p[4].map { SlotPhase.fromChar(it) }.let { if (it.size == 6) it else List(6) { SlotPhase.UNKNOWN } }
        _status.update {
            it.copy(
                clockOk = clockOk,
                boxTime = if (clockOk) BoxProtocol.fromBoxSeconds(secs) else null,
                mode = mode,
                slots = slots,
                lastSeq = p[5].toIntOrNull() ?: it.lastSeq,
                scheduleChecksum = p[6].toIntOrNull(),
                scheduleCount = p[7].toIntOrNull() ?: 0,
                lastSeenMillis = System.currentTimeMillis(),
            )
        }
    }

    private fun parseEvent(line: String): BoxEvent? {
        val p = line.split(" ")
        if (p.size < 5) return null
        val seq = p[1].toIntOrNull() ?: return null
        return BoxEvent(seq, p[2].toIntOrNull() ?: 0, p[3].toIntOrNull() ?: 0, BoxProtocol.fromBoxSeconds(p[4].toLongOrNull() ?: 0))
    }

    // ───────── 명령 ─────────
    private suspend fun requestRaw(cmd: String, timeoutMs: Long = 3000, retries: Int = 1): Pair<CmdResult, List<BoxEvent>> =
        reqMutex.withLock {
            if (!opened) return@withLock CmdResult.Err("OFFLINE") to emptyList()
            val id = nextId()
            repeat(retries + 1) {
                val p = Pending(id, CompletableDeferred(), mutableListOf())
                pending = p
                try {
                    transport.writeLine("#$id $cmd")
                } catch (e: Exception) {
                    pending = null
                    linkLost("전송 실패: ${e.message}")
                    return@withLock CmdResult.Err("OFFLINE") to emptyList()
                }
                val resp = try { withTimeoutOrNull(timeoutMs) { p.deferred.await() } } catch (e: Exception) { null }
                pending = null
                if (resp != null) {
                    val r = if (resp.startsWith("ERR")) CmdResult.Err(resp) else CmdResult.Ok(resp.removePrefix("OK").trim())
                    return@withLock r to p.evs.toList()
                }
                if (!opened) return@withLock CmdResult.Err("OFFLINE") to emptyList()
            }
            CmdResult.Err("TIMEOUT") to emptyList()
        }

    private suspend fun request(cmd: String, timeoutMs: Long = 3000, retries: Int = 1): CmdResult =
        requestRaw(cmd, timeoutMs, retries).first

    override suspend fun setTime(t: LocalDateTime): CmdResult {
        val r = request("TIME " + t.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
        if (r.isOk) request("STATUS")
        return r
    }

    override suspend fun pushSchedule(s: BoxSchedule): CmdResult {
        if (s.entries.size > 24) return CmdResult.Err("ERR FULL")
        var r = request("SB")
        if (!r.isOk) return r
        for (e in s.entries) {
            r = request("SE ${e.slot} ${e.hour} ${e.minute} ${e.days} ${e.startDay} ${e.endDay}")
            if (!r.isOk) return r
        }
        r = request("SC ${s.entries.size} ${s.holdSec} ${s.graceMin} ${s.checksum}")
        if (r.isOk) request("STATUS")
        return r
    }

    override suspend fun fetchLog(fromSeq: Int): List<BoxEvent>? {
        val (r, evs) = requestRaw("LOG $fromSeq", timeoutMs = 8000)
        return if (r.isOk) evs else null
    }

    override suspend fun reopen(slot: Int) = request("REOPEN $slot")
    override suspend fun markTaken(slot: Int) = request("TAKEN $slot")
    override suspend fun refill(slot: Int) = request("REFILL $slot")
    override suspend fun close(slot: Int) = request("CLOSE $slot")
    override suspend fun stop() = request("STOP")
    override suspend fun recover() = request("RECOVER")
}
