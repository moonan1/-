package com.yaksok.pillbox.ui

import com.yaksok.pillbox.domain.koreanDay
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

fun hm(t: LocalTime): String = "%02d:%02d".format(t.hour, t.minute)
fun hm(t: LocalDateTime): String = hm(t.toLocalTime())

fun ampm(t: LocalTime): String {
    val h = t.hour
    val label = if (h < 12) "오전" else "오후"
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$label $h12:%02d".format(t.minute)
}

fun dateLong(d: LocalDate): String = "${d.monthValue}월 ${d.dayOfMonth}일 ${koreanDay(d.dayOfWeek)}요일"
fun dateShort(d: LocalDate): String = "${d.monthValue}/${d.dayOfMonth}"

fun untilText(now: LocalDateTime, t: LocalDateTime): String {
    val min = Duration.between(now, t).toMinutes()
    return when {
        min <= 0 -> "지금"
        min < 60 -> "${min}분 후"
        else -> if (min % 60 == 0L) "${min / 60}시간 후" else "${min / 60}시간 ${min % 60}분 후"
    }
}

fun stamp(t: LocalDateTime, today: LocalDate = LocalDate.now()): String =
    if (t.toLocalDate() == today) hm(t) else "${dateShort(t.toLocalDate())} ${hm(t)}"
