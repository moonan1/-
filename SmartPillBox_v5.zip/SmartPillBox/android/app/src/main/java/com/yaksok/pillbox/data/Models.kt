package com.yaksok.pillbox.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

const val SLOT_COUNT = 6

/** 복용 약 */
data class Medication(
    val id: String,
    val name: String,
    val pillsPerDose: Int,
    val times: List<LocalTime>,
    val weekdays: Set<DayOfWeek>,
    val startDate: LocalDate,
    val endDate: LocalDate?,
    val slot: Int,
    val memo: String = "",
    val itemSeq: String? = null,      // 식약처 품목기준코드 (검색으로 등록한 약)
    val entpName: String = "",        // 제조/수입사
    val imageUrl: String? = null,
) {
    fun isActiveOn(date: LocalDate): Boolean =
        !date.isBefore(startDate) && (endDate == null || !date.isAfter(endDate)) && date.dayOfWeek in weekdays
}

/**
 * 복용 회차 1건. 상태(예정/지연/미복용 등)는 저장하지 않고 시각 정보로 계산한다(DoseStatus.kt).
 * - openedAt: 약통이 그 칸을 연 시각(약통 이벤트). 뚜껑 센서가 없으므로 '열림'은 복용이 아니다.
 * - confirmedAt: 사용자가 앱/알림에서 복용 완료를 확인한 시각(실제 복용 시각).
 */
data class DoseRecord(
    val key: String,
    val medId: String,
    val medName: String,
    val pills: Int,
    val slot: Int,
    val date: LocalDate,
    val time: LocalTime,
    val openedAt: LocalDateTime? = null,
    val confirmedAt: LocalDateTime? = null,
    val confirmSource: String? = null,
    val isTest: Boolean = false,
) {
    val scheduledAt: LocalDateTime get() = LocalDateTime.of(date, time)

    companion object {
        fun keyOf(medId: String, date: LocalDate, time: LocalTime) = "$medId|$date|${time}"
    }
}

/** 하루 시간대 — 분석과 시간대별 예비 알림에 사용 */
enum class Period(val label: String) {
    MORNING("아침"), LUNCH("점심"), EVENING("저녁"), NIGHT("밤");

    companion object {
        fun of(t: LocalTime): Period = when (t.hour) {
            in 4..10 -> MORNING
            in 11..15 -> LUNCH
            in 16..20 -> EVENING
            else -> NIGHT
        }
    }
}

/** 알림 설정. 복용 시각·용량·잠금 해제 시각과는 무관하다(사용자 승인 시에만 변경). */
data class NotificationSettings(
    val enabled: Boolean = true,
    val preAlertMin: Map<Period, Int> = Period.entries.associateWith { 0 },
    val reminderIntervalMin: Int = 10,
    val maxReminders: Int = 2,
) {
    fun preAlert(p: Period): Int = preAlertMin[p] ?: 0
    fun withPreAlert(p: Period, min: Int) = copy(preAlertMin = preAlertMin + (p to min))

    fun describe(): String {
        val pre = Period.entries.filter { preAlert(it) > 0 }
            .joinToString(", ") { "${it.label} ${preAlert(it)}분 전" }
        return buildString {
            append(if (enabled) "알림 켜짐" else "알림 꺼짐")
            append(" · 예비 알림: ")
            append(if (pre.isEmpty()) "없음" else pre)
            append(" · 재알림 ${reminderIntervalMin}분 간격 최대 ${maxReminders}회")
        }
    }
}

/** 알림 설정 변경 내역 (승인한 제안 / 직접 변경) */
data class SettingChange(
    val id: String,
    val at: LocalDateTime,
    val title: String,
    val detail: String,
    val source: String,          // "suggestion" | "manual" | "revert"
    val before: NotificationSettings,
    val after: NotificationSettings,
    val reverted: Boolean = false,
    val period: Period? = null,
)

data class DeviceLogEntry(val at: LocalDateTime, val text: String, val level: Int = 0) // level: 0 정보, 1 주의, 2 오류

/** 약통 동작 설정 (약통으로 전송) */
data class BoxSettings(
    val holdSec: Int = 60,      // 예약으로 연 칸을 열어두는 시간
    val graceMin: Int = 30,     // '다시 열기' 허용 시간
)

// ───────── 약 정보 (식약처 공개 의약품 정보) ─────────
data class DurItem(val type: String, val content: String, val partner: String = "")

data class DrugInfo(
    val itemSeq: String,
    val name: String,
    val entpName: String = "",
    val imageUrl: String? = null,
    val kind: String = "",            // 전문/일반의약품
    val chart: String = "",           // 성상(생김새)
    val ingredients: String = "",
    val efficacy: String = "",
    val useMethod: String = "",
    val warning: String = "",
    val caution: String = "",
    val interaction: String = "",
    val sideEffect: String = "",
    val storage: String = "",
    val dur: List<DurItem> = emptyList(),
    val fetchedAt: LocalDateTime? = null,
)

// ───────── 의료진 소통 · 원격 처방 ─────────
data class Doctor(val name: String, val hospital: String, val department: String)

enum class MsgKind { TEXT, REPORT, CONSULT, PRESCRIPTION, SYSTEM }

data class ChatMessage(
    val id: String,
    val at: LocalDateTime,
    val fromDoctor: Boolean,
    val text: String,
    val kind: MsgKind = MsgKind.TEXT,
    val refId: String? = null,     // 처방 id 등
)

/** 처방 항목. durationDays 동안 복용 */
data class RxItem(
    val name: String,
    val pillsPerDose: Int,
    val times: List<LocalTime>,
    val weekdays: Set<DayOfWeek>,
    val durationDays: Int,
    val note: String = "",
)

enum class RxStatus(val label: String) { NEW("확인 대기"), APPLIED("약 관리에 반영됨"), DECLINED("반영 안 함") }

data class Prescription(
    val id: String,
    val issuedAt: LocalDateTime,
    val doctor: Doctor,
    val items: List<RxItem>,
    val status: RxStatus = RxStatus.NEW,
    val handledAt: LocalDateTime? = null,
)

data class AppData(
    val meds: List<Medication> = emptyList(),
    val records: List<DoseRecord> = emptyList(),
    val notif: NotificationSettings = NotificationSettings(),
    val changes: List<SettingChange> = emptyList(),
    val dismissed: Map<String, LocalDate> = emptyMap(),
    val deviceLog: List<DeviceLogEntry> = emptyList(),
    val lastDeviceSeq: Map<String, Int> = emptyMap(),   // 기기 종류별 마지막 동기화 이벤트 번호
    val lastGenerated: LocalDate? = null,
    val box: BoxSettings = BoxSettings(),
    val chat: List<ChatMessage> = emptyList(),
    val prescriptions: List<Prescription> = emptyList(),
    val drugInfo: Map<String, DrugInfo> = emptyMap(),
)

enum class DataMode(val label: String) { REAL("실제 데이터"), DEMO("시연 데이터") }

enum class DeviceKind(val label: String, val short: String) {
    SIMULATION("시뮬레이션", "가상"), USB("USB 유선", "USB"), BLUETOOTH("블루투스", "블루투스"), LAPTOP("노트북 중계", "노트북")
}
