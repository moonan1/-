package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.domain.Analytics
import com.yaksok.pillbox.domain.DayStat
import com.yaksok.pillbox.domain.Summary
import com.yaksok.pillbox.domain.koreanDay
import com.yaksok.pillbox.domain.pct
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BarItem
import com.yaksok.pillbox.ui.components.BarSegment
import com.yaksok.pillbox.ui.components.EmptyState
import com.yaksok.pillbox.ui.components.Legend
import com.yaksok.pillbox.ui.components.Segmented
import com.yaksok.pillbox.ui.components.StackedBarChart
import com.yaksok.pillbox.ui.dateLong
import com.yaksok.pillbox.ui.dateShort
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen
import com.yaksok.pillbox.ui.theme.UnconfGray
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.roundToInt

private fun dayColor(s: DayStat): Color? = when {
    s.summary.total == 0 -> null
    s.summary.missed > 0 -> MissRed
    s.summary.unconfirmed > 0 -> UnconfGray
    s.summary.late > 0 -> LateAmber
    else -> OkGreen
}

private fun segments(s: Summary) = listOf(
    BarSegment(s.onTime.toFloat(), OkGreen),
    BarSegment(s.late.toFloat(), LateAmber),
    BarSegment(s.unconfirmed.toFloat(), UnconfGray),
    BarSegment(s.missed.toFloat(), MissRed),
)

@Composable
fun HistoryScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val today = now.toLocalDate()
    var range by remember { mutableStateOf(0) }
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var selected by remember { mutableStateOf(today) }
    var detail by remember { mutableStateOf<DoseRecord?>(null) }
    var timeChoice by remember { mutableStateOf<DoseRecord?>(null) }
    val a = remember(d.records, now) { Analytics(d.records, now) }

    val summary = if (range == 0) a.summaryLast(7) else a.summaryLast(30)
    val bars: List<BarItem> = if (range == 0) {
        val days = a.daily(today.minusDays(6), today)
        val max = days.maxOfOrNull { it.summary.total + it.pending }?.toFloat() ?: 0f
        days.map { ds ->
            BarItem(
                label = koreanDay(ds.date.dayOfWeek), segments = segments(ds.summary), max = max,
                caption = ds.summary.adherence?.let { pct(it) } ?: "", highlight = ds.date == today,
            )
        }
    } else {
        val weeks = (4 downTo 0).map { w ->
            val end = today.minusDays(w * 7L)
            val start = end.minusDays(6)
            Triple(start, end, a.summarize(a.range(start, end)))
        }
        val max = weeks.maxOfOrNull { it.third.total }?.toFloat() ?: 0f
        weeks.map { (s, _, sum) -> BarItem(dateShort(s) + "~", segments(sum), max, sum.adherence?.let { pct(it) } ?: "", highlight = false) }
    }
    val confirm: (DoseRecord) -> Unit = { r -> if (needsTimeChoice(r, now)) timeChoice = r else vm.confirm(r.key) }
    val dayRecords = d.records.filter { it.date == selected }.sortedBy { it.time }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { Text("복용 기록", style = MaterialTheme.typography.headlineLarge) }
        item { Segmented(listOf("주간 (7일)", "월간 (30일)"), range, { range = it }) }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("복약 이행률", style = MaterialTheme.typography.titleMedium, color = InkSoft)
                        Text(pct(summary.adherence), style = MaterialTheme.typography.headlineLarge, color = Mint)
                        Text("복용 확인 ${summary.taken} / 전체 ${summary.total}회", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("정시 복용", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        Text(pct(summary.onTimeRate), style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(4.dp))
                        Text("평균 지연", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        Text(summary.avgDelayMin?.let { "${it.roundToInt()}분" } ?: "-", style = MaterialTheme.typography.titleLarge)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CountBox("정상", summary.onTime, OkGreen, Modifier.weight(1f))
                    CountBox("지연", summary.late, LateAmber, Modifier.weight(1f))
                    CountBox("미복용", summary.missed, MissRed, Modifier.weight(1f))
                    CountBox("미확인", summary.unconfirmed, UnconfGray, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text("이행률은 복용 확인 기록만 셉니다. 약통이 열렸지만 확인이 없는 회차는 '미확인'으로 따로 표시해요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
            }
        }
        item {
            AppCard {
                Text(if (range == 0) "최근 7일 복용" else "최근 5주 복용 (주별)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                StackedBarChart(bars, chartHeight = 170.dp)
                Spacer(Modifier.height(10.dp))
                Legend(listOf("정상" to OkGreen, "지연" to LateAmber, "미확인" to UnconfGray, "미복용" to MissRed))
            }
        }
        item {
            CalendarCard(
                month = month, today = today, selected = selected, stats = a.daily(month.atDay(1), month.atEndOfMonth()).associateBy { it.date },
                onPrev = { month = month.minusMonths(1) },
                onNext = { if (month < YearMonth.from(today)) month = month.plusMonths(1) },
                onSelect = { selected = it },
            )
        }
        item { Text(dateLong(selected), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 4.dp)) }
        if (dayRecords.isEmpty()) item { AppCard { EmptyState(Icons.Filled.EventBusy, "기록이 없어요", "이 날은 복용 회차가 없었어요.") } }
        items(dayRecords, key = { it.key }) { r -> DoseRow(r, now, onConfirm = { confirm(r) }, onClick = { detail = r }) }
    }

    detail?.let { r0 ->
        val r = d.records.firstOrNull { it.key == r0.key } ?: r0
        DoseDetailDialog(r, now, onConfirm = { confirm(r) }, onUndo = { vm.undoConfirm(r.key) }, onDismiss = { detail = null })
    }
    timeChoice?.let { r -> ConfirmTimeDialog(r, now, onPick = { vm.confirm(r.key, it) }, onDismiss = { timeChoice = null }) }
}

@Composable
private fun CountBox(label: String, n: Int, color: Color, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.1f)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("$n", style = MaterialTheme.typography.titleLarge, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

@Composable
private fun CalendarCard(
    month: YearMonth, today: LocalDate, selected: LocalDate, stats: Map<LocalDate, DayStat>,
    onPrev: () -> Unit, onNext: () -> Unit, onSelect: (LocalDate) -> Unit,
) {
    AppCard(padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrev, modifier = Modifier.size(52.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "이전 달") }
            Text("${month.year}년 ${month.monthValue}월", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "다음 달") }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            listOf(DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY).forEach {
                Text(koreanDay(it), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium,
                    color = when (it) { DayOfWeek.SUNDAY -> MissRed; DayOfWeek.SATURDAY -> Color(0xFF3D7DD8); else -> InkSoft })
            }
        }
        val first = month.atDay(1)
        val lead = first.dayOfWeek.value % 7   // 일요일 시작
        val cells = lead + month.lengthOfMonth()
        val rows = (cells + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val idx = r * 7 + c - lead + 1
                    if (idx < 1 || idx > month.lengthOfMonth()) { Spacer(Modifier.weight(1f).aspectRatio(1f)); continue }
                    val date = month.atDay(idx)
                    val st = stats[date]
                    val dot = st?.let { dayColor(it) }
                    val sel = date == selected
                    val future = date.isAfter(today)
                    Column(
                        Modifier.weight(1f).aspectRatio(0.9f).padding(2.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (sel) MintSoft else Color.Transparent)
                            .then(if (date == today) Modifier.border(1.5.dp, Mint, RoundedCornerShape(12.dp)) else Modifier)
                            .clickable(enabled = !future) { onSelect(date) },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                    ) {
                        Text("$idx", style = MaterialTheme.typography.bodyLarge, color = if (future) Line else Ink, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.size(9.dp).clip(CircleShape).background(dot ?: Color.Transparent))
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Legend(listOf("모두 정상" to OkGreen, "지연" to LateAmber, "미확인" to UnconfGray, "미복용" to MissRed))
    }
}
