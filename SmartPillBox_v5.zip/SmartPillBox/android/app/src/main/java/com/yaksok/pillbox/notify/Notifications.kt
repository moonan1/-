package com.yaksok.pillbox.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.yaksok.pillbox.MainActivity
import com.yaksok.pillbox.PillApp
import com.yaksok.pillbox.R
import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.data.Period
import com.yaksok.pillbox.domain.DoseGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.ZoneId

enum class AlertKind { PRE, DUE, REMIND }

data class PlannedAlert(val at: LocalDateTime, val record: DoseRecord, val kind: AlertKind, val no: Int)

/** 알림 계획: 예비 알림(시간대별) → 복용 시각 알림 → 재알림(간격 × 횟수). 복용 확인되면 이후 알림 없음. */
object AlertPlanner {
    fun plan(d: AppData, from: LocalDateTime, to: LocalDateTime): List<PlannedAlert> {
        val n = d.notif
        if (!n.enabled) return emptyList()
        val out = ArrayList<PlannedAlert>()
        val byKey = d.records.associateBy { it.key }
        var date = from.toLocalDate().minusDays(1)
        while (!date.isAfter(to.toLocalDate())) {
            val day = date
            // 저장된 회차(테스트 포함) + 아직 생성 전인 미래 회차
            val occ = d.records.filter { it.date == day } +
                DoseGenerator.occurrences(d.meds, day).filter { it.key !in byKey }
            for (r in occ) {
                if (r.confirmedAt != null) continue
                val s = r.scheduledAt
                val pre = n.preAlert(Period.of(r.time))
                if (pre > 0) out += PlannedAlert(s.minusMinutes(pre.toLong()), r, AlertKind.PRE, 0)
                out += PlannedAlert(s, r, AlertKind.DUE, 0)
                for (k in 1..n.maxReminders) out += PlannedAlert(s.plusMinutes(k.toLong() * n.reminderIntervalMin), r, AlertKind.REMIND, k)
            }
            date = date.plusDays(1)
        }
        return out.filter { it.at.isAfter(from) && !it.at.isAfter(to) }.sortedBy { it.at }
    }
}

object Notifier {
    const val CH_DOSE = "dose_alert_v1"
    const val CH_PRE = "pre_alert_v1"
    const val ACTION_CONFIRM = "com.yaksok.pillbox.CONFIRM"
    const val EXTRA_KEY = "key"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_DOSE, "복용 알림", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "복용 시간과 재알림"
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_PRE, "예비 알림", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "복용 시간 전에 미리 알려주는 알림"
        })
    }

    fun id(key: String) = key.hashCode()

    fun canPost(ctx: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun show(ctx: Context, a: PlannedAlert, maxReminders: Int) {
        if (!canPost(ctx)) return
        val r = a.record
        val time = "%02d:%02d".format(r.time.hour, r.time.minute)
        val title = when (a.kind) {
            AlertKind.PRE -> "곧 복용 시간이에요 ($time)"
            AlertKind.DUE -> "복용 시간이에요"
            AlertKind.REMIND -> "아직 복용 확인이 없어요 (재알림 ${a.no}/$maxReminders)"
        }
        val text = "${r.medName} ${r.pills}정 · ${r.slot}번 칸" + if (r.isTest) " · 테스트" else ""
        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val confirm = PendingIntent.getBroadcast(
            ctx, id(r.key), Intent(ctx, ActionReceiver::class.java).setAction(ACTION_CONFIRM).putExtra(EXTRA_KEY, r.key),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = NotificationCompat.Builder(ctx, if (a.kind == AlertKind.PRE) CH_PRE else CH_DOSE)
            .setSmallIcon(R.drawable.ic_stat_pill)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\n예정 시각 $time"))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (a.kind == AlertKind.PRE) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(false)
            .setOnlyAlertOnce(false)
            .addAction(0, "복용 완료", confirm)
        try { NotificationManagerCompat.from(ctx).notify(id(r.key), b.build()) } catch (_: SecurityException) { }
    }

    fun cancel(ctx: Context, key: String) = NotificationManagerCompat.from(ctx).cancel(id(key))
}

/** 다음 알림 한 건만 AlarmManager에 예약하고, 울리면 그 시점의 알림을 보낸 뒤 다음 것을 다시 예약한다. */
object AlarmScheduler {
    private fun millis(t: LocalDateTime) = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    private fun fromMillis(ms: Long) = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(ms), ZoneId.systemDefault())

    private fun pending(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 100, Intent(ctx, AlarmReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun reschedule(ctx: Context, d: AppData, lastCheckMs: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val from = fromMillis(maxOf(lastCheckMs, System.currentTimeMillis()))
        val next = AlertPlanner.plan(d, from, from.plusDays(2)).firstOrNull()
        if (next == null) { am.cancel(pending(ctx)); return }
        val at = millis(next.at)
        if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
    }

    /** 알람 시점: 지난 확인 이후 ~ 지금+30초 사이의 알림을 보냄 (한 회차는 가장 최근 알림 1개만) */
    suspend fun deliverDue(ctx: Context) {
        val app = ctx.applicationContext as PillApp
        val repo = app.repo
        repo.ensureToday()
        val d = repo.data.value
        val nowMs = System.currentTimeMillis()
        val fromMs = maxOf(repo.lastAlarmCheck, nowMs - 30 * 60_000L)
        val toMs = nowMs + 30_000L
        val due = AlertPlanner.plan(d, fromMillis(fromMs), fromMillis(toMs))
        due.groupBy { it.record.key }.values.map { it.last() }.forEach { Notifier.show(ctx, it, d.notif.maxReminders) }
        repo.lastAlarmCheck = toMs
        reschedule(ctx, d, toMs)
    }
}

private val receiverScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = goAsync()
        receiverScope.launch {
            try { AlarmScheduler.deliverDue(context) } finally { p.finish() }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = goAsync()
        receiverScope.launch {
            try {
                val app = context.applicationContext as PillApp
                app.repo.ensureToday()
                AlarmScheduler.reschedule(context, app.repo.data.value, System.currentTimeMillis())
            } finally { p.finish() }
        }
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Notifier.ACTION_CONFIRM) return
        val key = intent.getStringExtra(Notifier.EXTRA_KEY) ?: return
        val p = goAsync()
        receiverScope.launch {
            try {
                val app = context.applicationContext as PillApp
                app.devices.confirmDose(key, LocalDateTime.now(), "notification")
            } finally { p.finish() }
        }
    }
}
