package com.yaksok.pillbox.device

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDateTime

/**
 * 하드웨어 없이 테스트하는 가상 약통. ver7 펌웨어와 같은 규칙으로 동작한다.
 *  - 예약 시각을 '통과하는 순간' 해당 칸만 연다. 다른 칸은 닫힘 유지.
 *  - 같은 회차는 한 번만 자동으로 열고, 다시 열기는 허용 시간 안에서 1번, 복용 확인 후 불가.
 *  - 칸은 한 번에 하나씩 움직인다. 통신이 끊겨도 예약은 계속 동작하며 이벤트는 기록에 쌓인다.
 * 가상 약통은 앱이 실행 중일 때만 동작한다.
 */
class SimulatedPillBox : PillBoxDevice {
    override val kindKey = "sim"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Any()

    private val _status = MutableStateFlow(DeviceStatus(message = "가상 약통 (연결 전)"))
    override val status: StateFlow<DeviceStatus> = _status.asStateFlow()
    private val _events = MutableSharedFlow<BoxEvent>(extraBufferCapacity = 128)
    override val events: SharedFlow<BoxEvent> = _events.asSharedFlow()

    private class Dose(var firedDay: Int = 0, var takenDay: Int = 0, var reopenDay: Int = 0)
    private enum class Kind { DOSE, REFILL }

    private var schedule = BoxSchedule(emptyList(), 60, 30)
    private var dose = ArrayList<Dose>()
    private val phase = Array(6) { SlotPhase.CLOSED }
    private val kind = Array(6) { Kind.DOSE }
    private val openAt = LongArray(6)
    private val reopenAfter = BooleanArray(6)
    private val queuedClose = BooleanArray(6)   // CLOSING 표시 중 아직 회전 시작 전(닫기 대기)
    private var active = -1
    private var motionAt = 0L
    private var recovery = false
    private var clockOk = true
    private var clockOffsetSec = 0L
    private var prevSec = -1L
    private val log = ArrayList<BoxEvent>()
    private var seq = 0
    private var connected = false
    private var linkDown = false

    private val motionMs = 700L
    private val refillHoldSec = 180

    // 모든 속성 초기화 뒤에 동작 루프 시작
    init {
        scope.launch {
            logEvent(BoxProtocol.EV_BOOT, 0)
            while (isActive) {
                synchronized(lock) { tick() }
                publish()
                delay(200)
            }
        }
    }

    private fun now(): LocalDateTime = LocalDateTime.now().plusSeconds(clockOffsetSec)
    private fun dayOf(t: LocalDateTime) = BoxProtocol.dayNumber(t.toLocalDate())
    private fun weekdayBit(t: LocalDateTime) = 1 shl (t.dayOfWeek.value - 1)

    private fun logEvent(type: Int, arg: Int) {
        val ev = BoxEvent(++seq, type, arg, if (clockOk) now() else null)
        synchronized(log) { log += ev; if (log.size > 200) log.removeAt(0) }
        if (connected && !linkDown) _events.tryEmit(ev)
    }

    private fun publish() {
        val st = synchronized(lock) {
            DeviceStatus(
                link = when { !connected -> LinkState.DISCONNECTED; linkDown -> LinkState.ERROR; else -> LinkState.CONNECTED },
                message = when { !connected -> "가상 약통 (연결 전)"; linkDown -> "통신 끊김 (시뮬레이션) · 약통은 계속 동작 중"; else -> "가상 약통 연결됨" },
                firmware = "sim-7",
                clockOk = clockOk,
                boxTime = if (clockOk) now() else null,
                mode = if (recovery) BoxMode.RECOVERY else if (clockOk) BoxMode.NORMAL else BoxMode.NEED_TIME,
                slots = phase.mapIndexed { i, p -> if (recovery) SlotPhase.UNKNOWN else if (p == SlotPhase.OPEN && kind[i] == Kind.REFILL) SlotPhase.REFILL else p },
                lastSeq = seq,
                scheduleChecksum = schedule.checksum,
                scheduleCount = schedule.entries.size,
                lastSeenMillis = System.currentTimeMillis(),
                simLinkDown = linkDown,
            )
        }
        // 통신이 끊긴 동안에는 앱이 약통 상태를 알 수 없다
        _status.value = if (connected && linkDown) st.copy(slots = List(6) { SlotPhase.UNKNOWN }, boxTime = null) else st
    }

    // ───────── 동작 (lock 안에서 호출) ─────────
    private fun tick() {
        val ms = System.currentTimeMillis()
        if (active >= 0 && ms - motionAt >= motionMs) {
            val i = active
            active = -1
            if (phase[i] == SlotPhase.OPENING) { phase[i] = SlotPhase.OPEN; openAt[i] = ms }
            else { phase[i] = if (reopenAfter[i]) SlotPhase.QUEUED else SlotPhase.CLOSED; reopenAfter[i] = false }
        }
        for (i in 0 until 6) {
            if (phase[i] != SlotPhase.OPEN) continue
            val hold = if (kind[i] == Kind.REFILL) refillHoldSec else schedule.holdSec
            if (ms - openAt[i] >= hold * 1000L) { phase[i] = SlotPhase.CLOSING; queuedClose[i] = true; logEvent(BoxProtocol.EV_AUTO_CLOSE, i + 1) }
        }
        if (!recovery && active < 0) {
            val c = (0 until 6).firstOrNull { queuedClose[it] }
            val o = (0 until 6).firstOrNull { phase[it] == SlotPhase.QUEUED }
            when {
                c != null -> { queuedClose[c] = false; phase[c] = SlotPhase.CLOSING; active = c; motionAt = ms }
                o != null -> { phase[o] = SlotPhase.OPENING; active = o; motionAt = ms }
            }
        }
        checkSchedule()
    }

    private fun checkSchedule() {
        if (!clockOk) return
        val t = now()
        val sec = BoxProtocol.toBoxSeconds(t)
        if (prevSec < 0) { prevSec = sec; return }
        if (sec == prevSec) return
        val prev = prevSec
        prevSec = sec
        if (sec < prev || sec - prev > 3) { logEvent(BoxProtocol.EV_CLOCK_GAP, 0); return }
        val today = dayOf(t)
        schedule.entries.forEachIndexed { idx, e ->
            if ((e.days and weekdayBit(t)) == 0 || today < e.startDay || today > e.endDay) return@forEachIndexed
            val target = today * 86400L + e.hour * 3600L + e.minute * 60L
            if (prev < target && target <= sec && dose[idx].firedDay != today) fire(idx, today)
        }
    }

    private fun fire(idx: Int, today: Int) {
        dose[idx].firedDay = today
        val s = schedule.entries[idx].slot - 1
        if (recovery) { logEvent(BoxProtocol.EV_DOSE_BLOCKED, s + 1); return }
        val already = phase[s].isOpenish && kind[s] == Kind.DOSE
        requestOpen(s, Kind.DOSE)
        if (!already) logEvent(BoxProtocol.EV_DOSE_OPEN, s + 1)
    }

    private fun requestOpen(i: Int, k: Kind) {
        kind[i] = k
        when (phase[i]) {
            SlotPhase.CLOSED -> phase[i] = SlotPhase.QUEUED
            SlotPhase.OPEN -> openAt[i] = System.currentTimeMillis()
            SlotPhase.CLOSING -> if (queuedClose[i]) { queuedClose[i] = false; phase[i] = SlotPhase.OPEN; openAt[i] = System.currentTimeMillis() } else reopenAfter[i] = true
            else -> Unit
        }
    }

    private fun requestClose(i: Int) {
        reopenAfter[i] = false
        when (phase[i]) {
            SlotPhase.OPEN -> { phase[i] = SlotPhase.CLOSING; queuedClose[i] = true }
            SlotPhase.QUEUED -> phase[i] = SlotPhase.CLOSED
            else -> Unit
        }
    }

    private fun latestFired(slot: Int, nowSec: Long): Pair<Int, Long>? {
        var best: Pair<Int, Long>? = null
        schedule.entries.forEachIndexed { i, e ->
            val d = dose[i]
            if (e.slot != slot || d.firedDay == 0) return@forEachIndexed
            val t = d.firedDay * 86400L + e.hour * 3600L + e.minute * 60L
            if (t > nowSec || nowSec - t > 86400) return@forEachIndexed
            if (best == null || t > best!!.second) best = i to t
        }
        return best
    }

    // ───────── PillBoxDevice ─────────
    override suspend fun connect(): Boolean {
        _status.value = _status.value.copy(link = LinkState.CONNECTING, message = "가상 약통 연결 중…")
        delay(600)
        synchronized(lock) { connected = true; linkDown = false }
        publish()
        return true
    }

    override suspend fun disconnect() {
        synchronized(lock) { connected = false }
        publish()
    }

    private inline fun cmd(block: () -> CmdResult): CmdResult {
        if (!connected || linkDown) return CmdResult.Err("ERR OFFLINE")
        val r = synchronized(lock) { block() }
        publish()
        return r
    }

    override suspend fun setTime(t: LocalDateTime): CmdResult = cmd {
        clockOffsetSec = Duration.between(LocalDateTime.now(), t).seconds
        clockOk = true
        prevSec = -1
        logEvent(BoxProtocol.EV_TIME_SET, 0)
        CmdResult.Ok()
    }

    override suspend fun pushSchedule(s: BoxSchedule): CmdResult = cmd {
        if (s.entries.size > 24) return@cmd CmdResult.Err("ERR FULL")
        val nd = ArrayList<Dose>()
        for (e in s.entries) {
            val j = schedule.entries.indexOfFirst { it.slot == e.slot && it.hour == e.hour && it.minute == e.minute }
            nd += if (j >= 0) dose[j].let { Dose(it.firedDay, it.takenDay, it.reopenDay) } else Dose()
        }
        schedule = s
        dose = nd
        prevSec = -1
        logEvent(BoxProtocol.EV_SCHED_SAVED, s.entries.size)
        CmdResult.Ok(s.checksum.toString())
    }

    override suspend fun fetchLog(fromSeq: Int): List<BoxEvent>? {
        if (!connected || linkDown) return null
        return synchronized(log) { log.filter { it.seq >= fromSeq } }
    }

    override suspend fun reopen(slot: Int): CmdResult = cmd {
        val s = slot - 1
        if (recovery) return@cmd CmdResult.Err("ERR STATE")
        val nowSec = BoxProtocol.toBoxSeconds(now())
        val (i, target) = latestFired(slot, nowSec) ?: return@cmd CmdResult.Err("ERR NODOSE")
        val d = dose[i]
        when {
            d.takenDay == d.firedDay -> CmdResult.Err("ERR TAKEN")
            nowSec - target > schedule.graceMin * 60L -> CmdResult.Err("ERR LATE")
            phase[s].isOpenish && kind[s] == Kind.DOSE -> CmdResult.Ok()
            d.reopenDay == d.firedDay -> CmdResult.Err("ERR USED")
            else -> { d.reopenDay = d.firedDay; requestOpen(s, Kind.DOSE); logEvent(BoxProtocol.EV_REOPEN, slot); CmdResult.Ok() }
        }
    }

    override suspend fun markTaken(slot: Int): CmdResult = cmd {
        val s = slot - 1
        val nowSec = BoxProtocol.toBoxSeconds(now())
        val (i, _) = latestFired(slot, nowSec) ?: return@cmd CmdResult.Err("ERR NODOSE")
        val d = dose[i]
        if (d.takenDay != d.firedDay) { d.takenDay = d.firedDay; logEvent(BoxProtocol.EV_TAKEN, slot) }
        if (kind[s] == Kind.DOSE && (phase[s] == SlotPhase.OPEN || phase[s] == SlotPhase.QUEUED)) requestClose(s)
        CmdResult.Ok()
    }

    override suspend fun refill(slot: Int): CmdResult = cmd {
        val s = slot - 1
        when {
            recovery -> CmdResult.Err("ERR STATE")
            phase[s] != SlotPhase.CLOSED -> CmdResult.Err("ERR BUSY")
            else -> { requestOpen(s, Kind.REFILL); logEvent(BoxProtocol.EV_REFILL_OPEN, slot); CmdResult.Ok() }
        }
    }

    override suspend fun close(slot: Int): CmdResult = cmd {
        val s = slot - 1
        if (phase[s] != SlotPhase.CLOSED) { requestClose(s); logEvent(BoxProtocol.EV_SLOT_CLOSE, slot) }
        CmdResult.Ok()
    }

    override suspend fun stop(): CmdResult = cmd {
        for (i in 0 until 6) { phase[i] = SlotPhase.CLOSED; queuedClose[i] = false; reopenAfter[i] = false }
        active = -1
        recovery = true
        logEvent(BoxProtocol.EV_STOP, 0)
        CmdResult.Ok()
    }

    override suspend fun recover(): CmdResult = cmd {
        if (!recovery) return@cmd CmdResult.Err("ERR STATE")
        recovery = false
        logEvent(BoxProtocol.EV_RECOVERED, 0)
        CmdResult.Ok()
    }

    // ───────── 시뮬레이션 전용 조작 ─────────
    fun setLinkDown(down: Boolean) {
        synchronized(lock) { linkDown = down }
        publish()
    }

    fun injectError() {
        synchronized(lock) { logEvent(BoxProtocol.EV_STORAGE_ERROR, 9) }
    }

    /** 전원이 꺼졌다 켜진 상황 (움직이는 중이었다면 위치 복구 필요) */
    fun simulatePowerCycle() {
        synchronized(lock) {
            val wasMoving = active >= 0
            active = -1
            for (i in 0 until 6) { if (phase[i] == SlotPhase.OPEN) { phase[i] = SlotPhase.CLOSING; queuedClose[i] = true } else if (phase[i] != SlotPhase.CLOSING) phase[i] = SlotPhase.CLOSED; reopenAfter[i] = false }
            if (wasMoving) recovery = true
            prevSec = -1
            logEvent(BoxProtocol.EV_BOOT, if (recovery) 1 else 0)
            if (wasMoving) logEvent(BoxProtocol.EV_RECOVERY_NEEDED, 0)
        }
        publish()
    }
}
