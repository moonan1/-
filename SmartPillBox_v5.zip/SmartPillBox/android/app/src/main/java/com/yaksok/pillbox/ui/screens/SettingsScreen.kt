package com.yaksok.pillbox.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.DataMode
import com.yaksok.pillbox.data.Period
import com.yaksok.pillbox.notify.AlarmScheduler
import com.yaksok.pillbox.notify.Notifier
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.ConfirmDialog
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.Segmented
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.OkGreen

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var draft by remember(d.notif) { mutableStateOf(d.notif) }
    var confirmReset by remember { mutableStateOf(false) }
    var permTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(now) { permTick++ }   // 화면 복귀 시 권한 상태 다시 확인

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(56.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "뒤로") }
            Text("설정", style = MaterialTheme.typography.headlineSmall)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionTitle("데이터")
            AppCard {
                Segmented(DataMode.entries.map { it.label }, DataMode.entries.indexOf(mode), { vm.switchMode(DataMode.entries[it]) })
                Spacer(Modifier.height(10.dp))
                Text(
                    if (mode == DataMode.DEMO) "발표용 시연 데이터(30일치)를 보고 있어요. 실제 복용 기록과 별도 파일에 저장되어 섞이지 않아요."
                    else "실제 복용 기록을 보고 있어요. 로그인 없이 이 휴대폰에만 저장돼요.",
                    style = MaterialTheme.typography.bodyMedium, color = InkSoft,
                )
                if (mode == DataMode.DEMO) {
                    Spacer(Modifier.height(10.dp))
                    SoftButton("시연 데이터 오늘 기준으로 다시 만들기", onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth(), color = LateAmber)
                }
            }

            SectionTitle("알림")
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("복용 알림 받기", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Switch(checked = draft.enabled, onCheckedChange = { draft = draft.copy(enabled = it) }, colors = SwitchDefaults.colors(checkedTrackColor = Mint))
                }
                Spacer(Modifier.height(12.dp))
                Text("시간대별 예비 알림", style = MaterialTheme.typography.titleSmall)
                Text("복용 시각은 그대로 두고, 그보다 먼저 알려줘요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                Period.entries.forEach { p ->
                    Text("${p.label}", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 10.dp))
                    Chips(listOf(0, 5, 10, 15, 20, 30), draft.preAlert(p), { if (it == 0) "없음" else "${it}분" }) { draft = draft.withPreAlert(p, it) }
                }
                Spacer(Modifier.height(14.dp))
                Text("재알림 간격", style = MaterialTheme.typography.titleSmall)
                Chips(listOf(5, 10, 15, 30), draft.reminderIntervalMin, { "${it}분" }) { draft = draft.copy(reminderIntervalMin = it) }
                Spacer(Modifier.height(10.dp))
                Text("재알림 최대 횟수", style = MaterialTheme.typography.titleSmall)
                Chips(listOf(0, 1, 2, 3, 4), draft.maxReminders, { if (it == 0) "안 함" else "${it}회" }) { draft = draft.copy(maxReminders = it) }
                Spacer(Modifier.height(14.dp))
                BigButton(
                    "알림 설정 저장", onClick = { vm.setNotif(draft, "알림 설정 직접 변경") }, enabled = draft != d.notif,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (draft != d.notif) TextButton(onClick = { draft = d.notif }) { Text("변경 취소") }
            }

            SectionTitle("알림이 제대로 오려면")
            AppCard {
                val pm = ctx.getSystemService(PowerManager::class.java)
                val notifOk = remember(permTick) { Notifier.canPost(ctx) }
                val exactOk = remember(permTick) { AlarmScheduler.canExact(ctx) }
                val batteryOk = remember(permTick) { pm.isIgnoringBatteryOptimizations(ctx.packageName) }
                PermRow("알림 허용", notifOk) {
                    ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                }
                PermRow("정확한 시각 알람", exactOk) {
                    if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
                }
                PermRow("배터리 사용 제한 없음", batteryOk) {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
                }
                Spacer(Modifier.height(6.dp))
                Text("갤럭시(One UI)는 설정 › 배터리 › 백그라운드 사용 제한에서 '약속'을 '사용 안 하는 앱'에 넣지 않아야 앱이 꺼져 있어도 알림이 와요.",
                    style = MaterialTheme.typography.bodySmall, color = InkSoft)
            }

            SectionTitle("앱 정보")
            AppCard {
                Text("약속 · 스마트 약통 연동 앱 1.0", style = MaterialTheme.typography.titleMedium)
                Text("복약 분석과 알림 제안은 규칙 기반으로 동작하며, 의학적 판단이나 복용량 변경을 권하지 않습니다. 복용 시각·용량 변경은 의사·약사와 상의하세요.",
                    style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
        }
    }
    if (confirmReset) ConfirmDialog(
        "시연 데이터 다시 만들기", "시연 데이터를 오늘 기준 30일치로 새로 만들어요. 실제 데이터에는 영향이 없어요.", "다시 만들기",
        onConfirm = { vm.resetDemo() }, onDismiss = { confirmReset = false },
    )
}

@Composable
private fun PermRow(label: String, ok: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline, null, tint = if (ok) OkGreen else MissRed)
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f).padding(start = 10.dp))
        if (!ok) TextButton(onClick = { runCatching { onFix() } }) { Text("설정하기") } else Text("완료", color = OkGreen)
    }
}

@Composable
private fun Chips(options: List<Int>, selected: Int, label: (Int) -> String, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o ->
            val sel = o == selected
            Box(
                Modifier.weight(1f).heightIn(min = 46.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (sel) Mint else Color.White).border(1.dp, if (sel) Mint else Line, RoundedCornerShape(12.dp))
                    .clickable { onSelect(o) },
                contentAlignment = Alignment.Center,
            ) { Text(label(o), color = if (sel) Color.White else Ink, style = MaterialTheme.typography.labelMedium, maxLines = 1) }
        }
    }
}
