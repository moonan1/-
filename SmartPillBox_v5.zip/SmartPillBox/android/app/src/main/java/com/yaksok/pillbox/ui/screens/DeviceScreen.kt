package com.yaksok.pillbox.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import com.yaksok.pillbox.device.BluetoothSppTransport
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.DeviceKind
import com.yaksok.pillbox.device.BoxMode
import com.yaksok.pillbox.device.DeviceManager
import com.yaksok.pillbox.device.LinkState
import com.yaksok.pillbox.device.SlotPhase
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.ConfirmDialog
import com.yaksok.pillbox.ui.components.InfoRow
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.Segmented
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.stamp
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen
import com.yaksok.pillbox.ui.theme.OpenTeal
import com.yaksok.pillbox.ui.theme.UnconfGray

@Composable
fun DeviceScreen(vm: AppViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val st by vm.deviceStatus.collectAsStateWithLifecycle()
    val kind by vm.deviceKind.collectAsStateWithLifecycle()
    val busy by vm.deviceBusy.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val connected = st.link == LinkState.CONNECTED
    val bySlot = d.meds.associateBy { it.slot }
    val schedule = remember(d) { DeviceManager.buildSchedule(d) }
    val inSync = connected && st.scheduleChecksum == schedule.checksum

    var refillSlot by remember { mutableStateOf<Int?>(null) }
    var confirmStop by remember { mutableStateOf(false) }
    var confirmRecover by remember { mutableStateOf(false) }
    var testMed by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(56.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "뒤로") }
            Text("스마트 약통", style = MaterialTheme.typography.headlineSmall)
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Text("연결 방식", style = MaterialTheme.typography.titleSmall, color = InkSoft, modifier = Modifier.padding(bottom = 6.dp))
                Segmented(DeviceKind.entries.map { it.short }, DeviceKind.entries.indexOf(kind), { vm.switchDevice(DeviceKind.entries[it]) })
                Spacer(Modifier.height(6.dp))
                Text(
                    when (kind) {
                        DeviceKind.SIMULATION -> "하드웨어 없이 앱 안의 가상 약통으로 테스트해요"
                        DeviceKind.USB -> "휴대폰 USB-C ↔ OTG ↔ 아두이노 USB 케이블"
                        DeviceKind.LAPTOP -> "우노는 노트북 USB에 꽂고, 노트북 중계 프로그램을 거쳐 연결해요"
                        else -> "아두이노에 HC-05/HC-06 모듈을 달고 펌웨어 USE_BT를 1로 올려야 해요"
                    },
                    style = MaterialTheme.typography.bodySmall, color = InkSoft,
                )
            }
            if (kind == DeviceKind.BLUETOOTH) item { BluetoothPicker(vm) }
            if (kind == DeviceKind.LAPTOP) item { LaptopSettings(vm, enabled = !connected) }
            // 연결 상태
            item {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MintSoft), contentAlignment = Alignment.Center) {
                            Icon(when (kind) { DeviceKind.USB -> Icons.Filled.Usb; DeviceKind.BLUETOOTH -> Icons.Filled.Bluetooth; DeviceKind.LAPTOP -> Icons.Filled.Laptop; else -> Icons.Filled.Science }, null, tint = MintDark, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            val c = when (st.link) { LinkState.CONNECTED -> OkGreen; LinkState.CONNECTING -> LateAmber; LinkState.ERROR -> MissRed; else -> UnconfGray }
                            Text(st.link.label, style = MaterialTheme.typography.titleLarge, color = c)
                            Text(st.message.ifBlank { when (kind) { DeviceKind.USB -> "OTG 케이블로 약통을 연결하세요"; DeviceKind.BLUETOOTH -> "모듈을 고른 뒤 연결하세요"; DeviceKind.LAPTOP -> "노트북 주소를 확인한 뒤 연결하세요"; else -> "가상 약통" } }, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        }
                        if (busy || st.link == LinkState.CONNECTING) CircularProgressIndicator(Modifier.size(28.dp), color = Mint, strokeWidth = 3.dp)
                    }
                    Spacer(Modifier.height(12.dp))
                    if (connected) {
                        InfoRow("약통 시간", st.boxTime?.let { hm(it) + ":%02d".format(it.second) } ?: "설정 필요", valueColor = if (st.clockOk) Ink else MissRed)
                        InfoRow("약통 상태", st.mode.label, valueColor = if (st.mode == BoxMode.NORMAL) OkGreen else MissRed)
                        InfoRow("펌웨어", st.firmware ?: "-")
                        InfoRow("저장된 일정", "${st.scheduleCount}건 · " + if (inSync) "앱과 일치" else "동기화 필요", valueColor = if (inSync) OkGreen else LateAmber)
                        Spacer(Modifier.height(10.dp))
                        SoftButton("연결 해제", onClick = { vm.devices.disconnect() }, icon = Icons.Filled.LinkOff, modifier = Modifier.fillMaxWidth(), color = InkSoft)
                    } else {
                        BigButton(
                            if (st.link == LinkState.ERROR) "다시 연결" else "약통 연결하기", onClick = { vm.devices.connect() },
                            icon = Icons.Filled.Link, enabled = !busy && st.link != LinkState.CONNECTING, modifier = Modifier.fillMaxWidth(),
                        )
                        if (kind == DeviceKind.USB) {
                            Spacer(Modifier.height(8.dp))
                            Text("휴대폰 USB-C ↔ OTG 젠더 ↔ 아두이노 USB 케이블로 연결하고, 노트북 시리얼 모니터는 닫아 주세요. 처음 연결할 때 USB 권한을 허용하세요.",
                                style = MaterialTheme.typography.bodySmall, color = InkSoft)
                        }
                    }
                }
            }
            if (connected && st.mode == BoxMode.RECOVERY) item {
                AppCard(color = MissRed.copy(alpha = 0.08f)) {
                    Text("위치 복구가 필요해요", style = MaterialTheme.typography.titleLarge, color = MissRed)
                    Text("모터가 움직이는 중에 멈추거나 전원이 끊겨 칸 위치를 알 수 없어요. 안전을 위해 약통은 칸을 열지 않아요. 약통 전원을 끄고 모든 칸을 손으로 닫힘 위치에 맞춘 뒤 아래 버튼을 눌러주세요.",
                        style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    BigButton("닫힘 위치 복구 확인", onClick = { confirmRecover = true }, icon = Icons.Filled.Build, color = MissRed, modifier = Modifier.fillMaxWidth())
                }
            }
            // 칸 상태
            item { SectionTitle("칸별 상태") }
            item {
                AppCard {
                    for (row in 0 until 2) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                            for (col in 0 until 3) {
                                val slot = row * 3 + col + 1
                                val p = if (connected) st.slots[slot - 1] else SlotPhase.UNKNOWN
                                val m = bySlot[slot]
                                val c = when { p == SlotPhase.UNKNOWN -> UnconfGray; p.isOpenish -> OpenTeal; p == SlotPhase.CLOSING -> LateAmber; else -> Mint }
                                Column(
                                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(c.copy(alpha = 0.1f))
                                        .border(1.dp, c.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                        .clickable(enabled = connected) { refillSlot = slot }
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Icon(if (p.isOpenish) Icons.Filled.LockOpen else Icons.Filled.Lock, null, tint = c, modifier = Modifier.size(26.dp))
                                    Text("${slot}번", style = MaterialTheme.typography.titleMedium, color = c)
                                    Text(p.label, style = MaterialTheme.typography.labelSmall, color = c)
                                    Text(m?.name ?: "비어 있음", style = MaterialTheme.typography.labelSmall, color = InkSoft, maxLines = 1)
                                }
                            }
                        }
                    }
                    Text("칸을 누르면 약 보충용으로 열거나 닫을 수 있어요. 예약 시각에는 해당 칸만 열리고 나머지는 잠금을 유지해요.",
                        style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
            }
            // 동작
            item { SectionTitle("약통 관리") }
            item {
                AppCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SoftButton("시간 맞추기", onClick = { vm.devices.syncTimeNow() }, icon = Icons.Filled.AccessTime, enabled = connected, modifier = Modifier.weight(1f))
                        SoftButton("동기화", onClick = { vm.devices.resync() }, icon = Icons.Filled.Sync, enabled = connected, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    SoftButton("모터 비상 정지", onClick = { confirmStop = true }, icon = Icons.Filled.StopCircle, enabled = connected, color = MissRed, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(14.dp))
                    Text("칸 열림 유지 시간", style = MaterialTheme.typography.titleSmall)
                    ChoiceRow(listOf(30, 60, 120, 300), d.box.holdSec, { if (it < 60) "${it}초" else "${it / 60}분" }) { vm.setBox(d.box.copy(holdSec = it)) }
                    Spacer(Modifier.height(10.dp))
                    Text("다시 열기 허용 시간 (복용 시각 이후)", style = MaterialTheme.typography.titleSmall)
                    ChoiceRow(listOf(10, 30, 60), d.box.graceMin, { "${it}분" }) { vm.setBox(d.box.copy(graceMin = it)) }
                    Spacer(Modifier.height(6.dp))
                    Text("약통은 같은 회차를 한 번만 자동으로 열어요. 다시 열기는 허용 시간 안에서 1번만 되고, 복용 완료를 누르면 더는 열리지 않아요.",
                        style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
            }
            // 테스트
            item { SectionTitle("시연 · 테스트") }
            item {
                AppCard {
                    Text("테스트 복용 만들기", style = MaterialTheme.typography.titleMedium)
                    Text("1~2분 뒤 회차를 만들어 '칸 열림 → 알림 → 복용 확인 → 기록' 과정을 실제 시간으로 시험해요. 테스트 기록은 통계에서 빠져요.",
                        style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    Spacer(Modifier.height(10.dp))
                    BigButton("테스트 복용 예약", onClick = { testMed = true }, icon = Icons.Filled.PlayArrow, enabled = d.meds.isNotEmpty(), modifier = Modifier.fillMaxWidth())
                    if (d.meds.isEmpty()) Text("먼저 약을 등록해 주세요.", style = MaterialTheme.typography.bodySmall, color = MissRed)
                    if (kind == DeviceKind.SIMULATION) {
                        Spacer(Modifier.height(16.dp))
                        Text("가상 약통 조작", style = MaterialTheme.typography.titleMedium)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text("통신 끊김 시뮬레이션", style = MaterialTheme.typography.bodyLarge)
                                Text("끊긴 동안 생긴 기록은 다시 연결되면 동기화돼요", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                            }
                            Switch(checked = st.simLinkDown, onCheckedChange = { vm.devices.sim.setLinkDown(it) }, colors = SwitchDefaults.colors(checkedTrackColor = MissRed))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SoftButton("기기 오류 발생", onClick = { vm.devices.sim.injectError() }, icon = Icons.Filled.BugReport, modifier = Modifier.weight(1f), color = LateAmber)
                            SoftButton("전원 재시작", onClick = { vm.devices.sim.simulatePowerCycle() }, icon = Icons.Filled.PowerSettingsNew, modifier = Modifier.weight(1f), color = InkSoft)
                        }
                    }
                }
            }
            // 기록
            item { SectionTitle("약통 동작 기록") }
            if (d.deviceLog.isEmpty()) item { AppCard { Text("아직 기록이 없어요", color = InkSoft) } }
            items(d.deviceLog.take(40)) { e ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(when (e.level) { 2 -> MissRed; 1 -> LateAmber; else -> Mint }))
                    Spacer(Modifier.width(10.dp))
                    Text(stamp(e.at, now.toLocalDate()), style = MaterialTheme.typography.bodySmall, color = InkSoft, modifier = Modifier.width(92.dp))
                    Text(e.text, style = MaterialTheme.typography.bodyMedium, color = if (e.level == 2) MissRed else Ink)
                }
            }
        }
    }

    refillSlot?.let { slot ->
        val p = st.slots.getOrNull(slot - 1)
        if (p != null && p.isOpenish) {
            ConfirmDialog("${slot}번 칸 닫기", "${slot}번 칸을 지금 닫을까요?", "닫기", onConfirm = { vm.devices.closeSlot(slot) }, onDismiss = { refillSlot = null })
        } else {
            ConfirmDialog(
                "${slot}번 칸 약 보충", "${slot}번 칸(${bySlot[slot]?.name ?: "비어 있음"})만 보충용으로 열어요. 3분 뒤 자동으로 닫히고, 다른 칸은 잠금을 유지해요.",
                "보충용으로 열기", onConfirm = { vm.devices.refill(slot) }, onDismiss = { refillSlot = null },
            )
        }
    }
    if (confirmStop) ConfirmDialog(
        "모터 비상 정지", "모든 모터 신호를 즉시 끊어요. 이후 칸 위치를 확인하고 '닫힘 위치 복구'를 해야 다시 동작해요.", "정지",
        onConfirm = { vm.devices.stopMotors() }, onDismiss = { confirmStop = false }, danger = true,
    )
    if (confirmRecover) ConfirmDialog(
        "닫힘 위치 복구", "모든 칸이 닫힘 위치에 있는 것을 눈으로 확인했나요? 모터축을 무리하게 돌리지 마세요.", "확인했어요",
        onConfirm = { vm.devices.recover() }, onDismiss = { confirmRecover = false },
    )
    if (testMed) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { testMed = false },
            containerColor = Color.White,
            title = { Text("어떤 약으로 시험할까요?", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    d.meds.sortedBy { it.slot }.forEach { m ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(14.dp)).background(MintSoft)
                                .clickable { vm.devices.createTestDose(m.id); testMed = false }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${m.slot}번", color = MintDark, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.width(12.dp))
                            Text(m.name, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { androidx.compose.material3.TextButton(onClick = { testMed = false }) { Text("취소") } },
        )
    }
}

/** 노트북 중계 주소 입력 */
@Composable
private fun LaptopSettings(vm: AppViewModel, enabled: Boolean) {
    var host by remember { mutableStateOf(vm.repo.laptopHost) }
    var port by remember { mutableStateOf(vm.repo.laptopPort.toString()) }
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Laptop, null, tint = Mint)
            Spacer(Modifier.width(8.dp))
            Text("노트북 중계 주소", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        Text("노트북에서 중계 프로그램을 실행하면 화면에 주소가 나와요. 그 주소를 그대로 입력하세요.",
            style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = host, onValueChange = { host = it.trim().take(40); vm.repo.laptopHost = host }, enabled = enabled,
                label = { Text("노트북 IP") }, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            )
            OutlinedTextField(
                value = port, onValueChange = { v -> port = v.filter { it.isDigit() }.take(5); port.toIntOrNull()?.let { vm.repo.laptopPort = it } },
                enabled = enabled, label = { Text("포트") }, singleLine = true, modifier = Modifier.width(110.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text("· 같은 Wi-Fi: 노트북 IP (예: 192.168.0.12)\n· USB 케이블 + adb reverse: 127.0.0.1",
            style = MaterialTheme.typography.bodySmall, color = InkSoft)
    }
}

/** 페어링된 HC-05/06 선택 */
@Composable
private fun BluetoothPicker(vm: AppViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf(vm.repo.btAddress) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val hasPerm = remember(tick) { BluetoothSppTransport.hasBtPermission(ctx) }
    val devices = remember(tick, hasPerm) { BluetoothSppTransport.bondedDevices(ctx) }
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Bluetooth, null, tint = Mint)
            Spacer(Modifier.width(8.dp))
            Text("약통 블루투스 모듈 선택", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { tick++ }) { Text("새로고침") }
        }
        if (!hasPerm && Build.VERSION.SDK_INT >= 31) {
            Text("'근처 기기' 권한이 있어야 페어링된 모듈을 볼 수 있어요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            Spacer(Modifier.height(8.dp))
            BigButton("권한 허용하기", onClick = { launcher.launch(Manifest.permission.BLUETOOTH_CONNECT) }, modifier = Modifier.fillMaxWidth())
            return@AppCard
        }
        if (devices.isEmpty()) Text("페어링된 기기가 없어요. 휴대폰 블루투스 설정에서 HC-05/HC-06을 먼저 페어링하세요 (PIN 1234 또는 0000).",
            style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        devices.forEach { (name, addr) ->
            val sel = selected == addr
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).heightIn(min = 56.dp).clip(RoundedCornerShape(14.dp))
                    .background(if (sel) MintSoft else Color.White).border(1.dp, if (sel) Mint else Line, RoundedCornerShape(14.dp))
                    .clickable { vm.repo.btAddress = addr; vm.repo.btName = name; selected = addr }.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleSmall)
                    Text(addr, style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
                if (sel) Text("선택됨", color = MintDark, style = MaterialTheme.typography.labelMedium)
            }
        }
        Spacer(Modifier.height(6.dp))
        SoftButton("휴대폰 블루투스 설정 열기", onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } },
            modifier = Modifier.fillMaxWidth(), color = InkSoft)
    }
}

@Composable
private fun <T> ChoiceRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            val sel = o == selected
            Box(
                Modifier.weight(1f).heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (sel) Mint else Color.White).border(1.dp, if (sel) Mint else Line, RoundedCornerShape(12.dp))
                    .clickable { onSelect(o) },
                contentAlignment = Alignment.Center,
            ) { Text(label(o), color = if (sel) Color.White else Ink, style = MaterialTheme.typography.labelLarge) }
        }
    }
}
