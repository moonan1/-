package com.yaksok.pillbox.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.DrugInfo
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.drug.DrugHit
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

// ───────── 네트워크 이미지 (외부 라이브러리 없이) ─────────
private val imageCache = LruCache<String, Bitmap>(24)

@Composable
fun NetImage(url: String?, modifier: Modifier = Modifier, size: Dp = 64.dp) {
    val bmp by produceState<Bitmap?>(initialValue = url?.let { imageCache.get(it) }, url) {
        if (url.isNullOrBlank() || value != null) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                val conn = (URL(url.replace("http://", "https://")).openConnection() as HttpURLConnection).apply { connectTimeout = 6000; readTimeout = 8000 }
                try { conn.inputStream.use { BitmapFactory.decodeStream(it) } } finally { conn.disconnect() }
            }.getOrNull()?.also { imageCache.put(url, it) }
        }
    }
    Box(modifier.size(size).clip(RoundedCornerShape(12.dp)).background(MintSoft), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.size(size))
        else Icon(Icons.Filled.Medication, null, tint = Mint, modifier = Modifier.size(size * 0.5f))
    }
}

// ───────── 약 등록 화면: 이름 검색 / 직접 등록 ─────────
@Composable
fun DrugNamePicker(
    vm: AppViewModel,
    name: String,
    itemSeq: String?,
    entpName: String,
    imageUrl: String?,
    onPick: (DrugHit) -> Unit,
    onManual: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var manual by remember { mutableStateOf(itemSeq == null && name.isNotBlank()) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<DrugHit>?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val canSearch = vm.drugSearchAvailable

    fun doSearch() {
        val q = query.trim()
        if (q.length < 2) { error = "두 글자 이상 입력해 주세요."; return }
        loading = true; error = null
        scope.launch {
            try { results = vm.searchDrugs(q) } catch (e: Exception) { error = e.message ?: "검색에 실패했어요."; results = null }
            loading = false
        }
    }

    Column {
        // 이미 고른 약 (검색으로 등록)
        if (!manual && itemSeq != null) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MintSoft).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NetImage(imageUrl, size = 56.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (entpName.isNotBlank()) Text(entpName, style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
                TextButton(onClick = { onManual(""); results = null; query = "" }) { Text("다시 찾기") }
            }
            return@Column
        }
        if (!manual) {
            Text("약 이름 검색", style = MaterialTheme.typography.titleSmall, color = InkSoft, modifier = Modifier.padding(bottom = 8.dp))
            if (!canSearch) {
                Text("지금은 약 검색을 사용할 수 없어요. 아래 '직접 등록하기'로 이름을 입력해 주세요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it.take(30); error = null },
                        placeholder = { Text("예: 타이레놀, 아모잘탄") }, singleLine = true, modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp), textStyle = MaterialTheme.typography.titleMedium,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Mint).clickable { doSearch() },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.5.dp)
                        else Icon(Icons.Filled.Search, "검색", tint = Color.White)
                    }
                }
                error?.let { Text(it, color = MissRed, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp)) }
                val r = results
                if (r != null) {
                    Spacer(Modifier.height(10.dp))
                    if (r.isEmpty()) Text("검색 결과가 없어요. 이름을 다르게 입력하거나 직접 등록해 주세요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        r.take(20).forEach { h ->
                            Row(
                                Modifier.fillMaxWidth().heightIn(min = 64.dp).clip(RoundedCornerShape(14.dp))
                                    .border(1.dp, Line, RoundedCornerShape(14.dp)).clickable { onPick(h); results = null }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                NetImage(h.imageUrl, size = 48.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(h.name, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(listOf(h.entpName, h.kind).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = InkSoft, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp))
                    .clickable { manual = true; onManual(query.trim()) }.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.EditNote, null, tint = InkSoft)
                Spacer(Modifier.width(8.dp))
                Text("찾는 약이 없나요? 직접 등록하기", style = MaterialTheme.typography.labelLarge, color = Ink)
            }
        } else {
            Text("약 이름 (직접 등록)", style = MaterialTheme.typography.titleSmall, color = InkSoft, modifier = Modifier.padding(bottom = 8.dp))
            OutlinedTextField(
                value = name, onValueChange = { onManual(it.take(20)) }, singleLine = true,
                placeholder = { Text("예: 혈압약") }, textStyle = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            )
            if (canSearch) TextButton(onClick = { manual = false; onManual("") }) {
                Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("이름으로 검색해서 찾기")
            }
        }
    }
}

// ───────── 칸 상세: 약 정보 ─────────
@Composable
fun DrugInfoSection(vm: AppViewModel, med: Medication) {
    val d by vm.data.collectAsStateWithLifecycle()
    val seq = med.itemSeq
    var error by remember(seq) { mutableStateOf<String?>(null) }
    LaunchedEffect(seq) { if (seq != null) vm.ensureDrugInfo(seq, med.name) { error = it } }
    val info = seq?.let { d.drugInfo[it] }

    Column(Modifier.fillMaxWidth()) {
        Text("약 정보", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        when {
            seq == null -> {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFF5F8F8)).padding(14.dp)) {
                    Text("직접 등록한 약이라 상세 정보가 없어요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    if (med.memo.isNotBlank()) Text("메모: ${med.memo}", style = MaterialTheme.typography.bodyLarge)
                    Text("약 정보 수정에서 '이름으로 검색해서 찾기'를 누르면 효능·부작용을 볼 수 있어요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
            }
            info == null -> {
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (error == null) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = Mint, strokeWidth = 2.5.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("약 정보를 불러오는 중이에요", color = InkSoft, style = MaterialTheme.typography.bodyLarge)
                    } else {
                        Text(error ?: "", color = InkSoft, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        TextButton(onClick = { error = null; vm.ensureDrugInfo(seq, med.name, force = true) { error = it } }) { Text("다시 시도") }
                    }
                }
            }
            else -> DrugInfoBody(info)
        }
    }
}

@Composable
private fun DrugInfoBody(info: DrugInfo) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // 생김새
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MintSoft.copy(alpha = 0.6f)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NetImage(info.imageUrl, size = 84.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(info.name, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Text(listOf(info.entpName, info.kind).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = InkSoft)
                if (info.chart.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("생김새: ${info.chart}", style = MaterialTheme.typography.bodyMedium, color = MintDark)
                }
            }
        }
        // 주의 표시 (DUR)
        if (info.dur.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(LateAmber.copy(alpha = 0.1f)).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.WarningAmber, null, tint = LateAmber, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("복용 시 주의", style = MaterialTheme.typography.titleSmall, color = Ink)
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 4.dp)) {
                    info.dur.map { it.type }.distinct().take(4).forEach { Pill(it, LateAmber) }
                }
                info.dur.take(6).forEach { x ->
                    val line = buildString {
                        append("· ").append(x.type)
                        if (x.content.isNotBlank()) append(": ").append(x.content)
                        if (x.partner.isNotBlank()) append(" (함께 먹으면 안 되는 약: ").append(x.partner).append(")")
                    }
                    Text(line, style = MaterialTheme.typography.bodyMedium, color = Ink, maxLines = 4, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        InfoFold("효능", info.efficacy, initiallyOpen = true)
        InfoFold("복용 방법", info.useMethod)
        InfoFold("부작용", info.sideEffect)
        InfoFold("먹기 전 꼭 알아야 할 내용", info.warning)
        InfoFold("주의사항", info.caution)
        InfoFold("함께 먹으면 주의할 약·음식", info.interaction)
        InfoFold("주성분", info.ingredients)
        InfoFold("보관 방법", info.storage)
        Text("식약처 공개 의약품 정보 기준이에요. 복용량이나 복용 여부는 꼭 의사·약사와 상의하세요.",
            style = MaterialTheme.typography.bodySmall, color = InkSoft, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun InfoFold(title: String, body: String, initiallyOpen: Boolean = false) {
    if (body.isBlank()) return
    var open by remember(title) { mutableStateOf(initiallyOpen) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp))
            .clickable { open = !open }.padding(horizontal = 14.dp, vertical = 10.dp).animateContentSize(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.heightIn(min = 32.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Icon(if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null, tint = InkSoft)
        }
        Text(body, style = MaterialTheme.typography.bodyLarge, color = Ink, maxLines = if (open) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis)
    }
}
