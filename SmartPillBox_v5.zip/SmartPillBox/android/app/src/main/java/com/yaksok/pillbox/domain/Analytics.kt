package com.yaksok.pillbox.domain

import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.data.Period
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime

/** 집계 결과 */
data class Summary(
    val total: Int = 0,        // 판정이 끝난 회차
    val onTime: Int = 0,
    val late: Int = 0,
    val missed: Int = 0,
    val unconfirmed: Int = 0,
    val avgDelayMin: Double? = null,   // 확인된 복용의 평균 지연(분)
) {
    val taken get() = onTime + late
    /** 복용 이행률 = 복용 확인 / 전체. '확인되지 않음'은 복용으로 세지 않고 따로 표시 */
    val adherence: Double? get() = if (total == 0) null else taken.toDouble() / total
    val onTimeRate: Double? get() = if (total == 0) null else onTime.toDouble() / total
    val missedLike get() = missed + unconfirmed
}

data class DayStat(val date: LocalDate, val summary: Summary, val pending: Int)

data class PeriodStat(val period: Period, val summary: Summary)

data class WeekdayStat(val day: DayOfWeek, val late: Int, val missed: Int, val total: Int)

/** 규칙 기반 복약 습관 분석 (AI·외부 API 사용 안 함) */
class Analytics(records: List<DoseRecord>, val now: LocalDateTime) {
    private val all = records.filter { !it.isTest && !it.scheduledAt.isAfter(now) }
    private val statusOf = all.associateWith { it.status(now) }
    private val final = all.filter { statusOf.getValue(it).isFinal }

    fun summarize(rs: List<DoseRecord>): Summary {
        var on = 0; var late = 0; var miss = 0; var unc = 0
        val delays = ArrayList<Long>()
        for (r in rs) {
            when (statusOf[r] ?: r.status(now)) {
                DoseStatus.TAKEN -> { on++; delays += r.delayMinutes() ?: 0L }
                DoseStatus.LATE -> { late++; delays += r.delayMinutes() ?: 0L }
                DoseStatus.MISSED -> miss++
                DoseStatus.UNCONFIRMED -> unc++
                else -> Unit
            }
        }
        return Summary(on + late + miss + unc, on, late, miss, unc, if (delays.isEmpty()) null else delays.average())
    }

    /** [from, to] 기간 (날짜 포함) */
    fun range(from: LocalDate, to: LocalDate): List<DoseRecord> =
        final.filter { !it.date.isBefore(from) && !it.date.isAfter(to) }

    fun lastDays(days: Long, endOffset: Long = 0): List<DoseRecord> {
        val to = now.toLocalDate().minusDays(endOffset)
        return range(to.minusDays(days - 1), to)
    }

    fun summaryLast(days: Long, endOffset: Long = 0) = summarize(lastDays(days, endOffset))

    fun daily(from: LocalDate, to: LocalDate): List<DayStat> {
        val byDate = all.groupBy { it.date }
        val out = ArrayList<DayStat>()
        var d = from
        while (!d.isAfter(to)) {
            val rs = byDate[d].orEmpty()
            val fin = rs.filter { statusOf.getValue(it).isFinal }
            out += DayStat(d, summarize(fin), rs.size - fin.size)
            d = d.plusDays(1)
        }
        return out
    }

    fun byPeriod(days: Long): List<PeriodStat> {
        val rs = lastDays(days)
        return Period.entries.map { p -> PeriodStat(p, summarize(rs.filter { Period.of(it.time) == p })) }
    }

    fun byWeekday(days: Long): List<WeekdayStat> {
        val rs = lastDays(days)
        return DayOfWeek.entries.map { d ->
            val s = summarize(rs.filter { it.date.dayOfWeek == d })
            WeekdayStat(d, s.late, s.missedLike, s.total)
        }
    }

    /** 가장 자주 놓치는(누락+지연) 시간대 */
    fun weakestPeriod(days: Long): PeriodStat? =
        byPeriod(days).filter { it.summary.total > 0 && (it.summary.missedLike + it.summary.late) > 0 }
            .maxByOrNull { it.summary.missedLike * 2 + it.summary.late }

    /** 특정 시점 전/후 시간대 평균 지연 비교 (설정 변경 효과 확인용) */
    fun periodDelayBetween(p: Period, from: LocalDateTime, to: LocalDateTime): Summary =
        summarize(final.filter { Period.of(it.time) == p && !it.scheduledAt.isBefore(from) && it.scheduledAt.isBefore(to) })
}

fun pct(v: Double?): String = if (v == null) "-" else "${Math.round(v * 100)}%"

fun koreanDay(d: DayOfWeek): String = when (d) {
    DayOfWeek.MONDAY -> "월"; DayOfWeek.TUESDAY -> "화"; DayOfWeek.WEDNESDAY -> "수"
    DayOfWeek.THURSDAY -> "목"; DayOfWeek.FRIDAY -> "금"; DayOfWeek.SATURDAY -> "토"; DayOfWeek.SUNDAY -> "일"
}
