package com.yaksok.pillbox.domain

import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.NotificationSettings
import com.yaksok.pillbox.data.Period
import java.time.LocalDateTime
import kotlin.math.roundToInt

/**
 * 맞춤 알림 제안. 바꾸는 것은 '알림 설정'뿐이다.
 * 복용 시각, 처방 용량, 약통 잠금 해제 시각은 절대 바꾸지 않으며, 사용자가 승인해야 적용된다.
 */
data class Suggestion(
    val key: String,
    val title: String,
    val message: String,
    val evidence: String,
    val changeSummary: String,
    val period: Period?,
    val proposed: NotificationSettings,
)

data class Insight(val title: String, val message: String, val positive: Boolean)

object SuggestionEngine {
    private const val DISMISS_DAYS = 7L

    fun suggestions(d: AppData, now: LocalDateTime): List<Suggestion> {
        val a = Analytics(d.records, now)
        val cur = d.notif
        val out = ArrayList<Suggestion>()
        val week = a.lastDays(7)

        // 규칙 1: 특정 시간대에 지연이 반복되면 예비 알림을 앞당긴다
        for (p in Period.entries) {
            val rs = week.filter { Period.of(it.time) == p }
            val s = a.summarize(rs)
            val lateDays = rs.filter { it.status(now) == DoseStatus.LATE }.map { it.date }.distinct().size
            val avg = s.avgDelayMin ?: continue
            if (lateDays >= 3 && avg >= 10) {
                val proposedMin = ((avg.toInt() / 5) * 5 - 5).coerceIn(5, 30)
                if (proposedMin > cur.preAlert(p)) {
                    val avgText = avg.roundToInt()
                    out += Suggestion(
                        key = "pre_${p.name}_$proposedMin",
                        title = "${p.label} 예비 알림 앞당기기",
                        message = "최근 일주일 동안 ${p.label} 복용이 평균 ${avgText}분 지연되었습니다. 예비 알림을 ${proposedMin}분 일찍 받아보시겠습니까?",
                        evidence = "최근 7일 중 ${lateDays}일 지연 · ${p.label} 평균 지연 ${avgText}분",
                        changeSummary = "${p.label} 예비 알림 ${cur.preAlert(p)}분 전 → ${proposedMin}분 전",
                        period = p,
                        proposed = cur.withPreAlert(p, proposedMin),
                    )
                }
            }
        }

        // 규칙 2: 누락이 반복되면 재알림 횟수/간격 조정
        val ws = a.summarize(week)
        if (ws.missedLike >= 2) {
            val weak = a.weakestPeriod(7)
            val where = weak?.let { " (특히 ${it.period.label})" } ?: ""
            if (cur.maxReminders < 4) {
                val next = cur.maxReminders + 1
                out += Suggestion(
                    key = "remind_max_$next",
                    title = "재알림 횟수 늘리기",
                    message = "최근 일주일 동안 복용 누락이 ${ws.missedLike}회 있었습니다$where. 재알림을 최대 ${next}회로 늘려볼까요?",
                    evidence = "미복용 ${ws.missed}회 · 확인되지 않음 ${ws.unconfirmed}회 (최근 7일)",
                    changeSummary = "재알림 최대 ${cur.maxReminders}회 → ${next}회",
                    period = null,
                    proposed = cur.copy(maxReminders = next),
                )
            } else if (cur.reminderIntervalMin > 5) {
                out += Suggestion(
                    key = "remind_int_5",
                    title = "재알림 간격 줄이기",
                    message = "재알림을 늘렸는데도 누락이 ${ws.missedLike}회 있었습니다. 재알림 간격을 5분으로 줄여볼까요?",
                    evidence = "최근 7일 누락 ${ws.missedLike}회 · 현재 재알림 ${cur.maxReminders}회",
                    changeSummary = "재알림 간격 ${cur.reminderIntervalMin}분 → 5분",
                    period = null,
                    proposed = cur.copy(reminderIntervalMin = 5),
                )
            }
        }

        // 규칙 3: 예비 알림이 있는데 2주 동안 모두 제시간에 복용했다면 알림을 줄이는 제안
        for (p in Period.entries) {
            if (cur.preAlert(p) == 0) continue
            val lastChange = d.changes.lastOrNull { !it.reverted && it.after.preAlert(p) != it.before.preAlert(p) }
            if (lastChange != null && lastChange.at.isAfter(now.minusDays(14))) continue
            val s = a.summarize(a.lastDays(14).filter { Period.of(it.time) == p })
            if (s.total >= 6 && s.onTime == s.total) {
                val next = (cur.preAlert(p) - 5).coerceAtLeast(0)
                out += Suggestion(
                    key = "pre_down_${p.name}_$next",
                    title = "${p.label} 알림 줄이기",
                    message = "최근 2주 동안 ${p.label} 약을 모두 제시간에 드셨어요. 예비 알림을 ${if (next == 0) "끄셔도" else "${next}분 전으로 줄이셔도"} 될 것 같아요.",
                    evidence = "최근 14일 ${p.label} ${s.total}회 모두 정시 복용",
                    changeSummary = "${p.label} 예비 알림 ${cur.preAlert(p)}분 전 → ${if (next == 0) "없음" else "${next}분 전"}",
                    period = p,
                    proposed = cur.withPreAlert(p, next),
                )
            }
        }

        val today = now.toLocalDate()
        return out.filter { s ->
            val dis = d.dismissed[s.key]
            dis == null || dis.plusDays(DISMISS_DAYS).isBefore(today) || dis.plusDays(DISMISS_DAYS) == today
        }
    }

    fun insights(d: AppData, now: LocalDateTime): List<Insight> {
        val a = Analytics(d.records, now)
        val out = ArrayList<Insight>()
        val cur = a.summaryLast(7)
        val prev = a.summaryLast(7, endOffset = 7)
        val c = cur.adherence
        val p = prev.adherence
        if (c != null && p != null && c - p >= 0.1) {
            out += Insight("복약 이행률이 좋아졌어요", "지난주 ${pct(p)} → 이번 주 ${pct(c)}로 ${Math.round((c - p) * 100)}%p 올랐습니다.", true)
        } else if (c != null && p != null && p - c >= 0.1) {
            out += Insight("이번 주 이행률이 낮아졌어요", "지난주 ${pct(p)} → 이번 주 ${pct(c)}. 놓친 시간대를 아래에서 확인해 보세요.", false)
        }
        // 승인한 알림 변경의 효과
        val change = d.changes.lastOrNull { it.source == "suggestion" && !it.reverted && it.period != null }
        if (change != null && change.at.isBefore(now.minusDays(3))) {
            val per = change.period!!
            val before = a.periodDelayBetween(per, change.at.minusDays(7), change.at)
            val after = a.periodDelayBetween(per, change.at, now)
            val b = before.avgDelayMin
            val af = after.avgDelayMin
            if (b != null && af != null && after.total >= 3) {
                if (af + 3 <= b) out += Insight(
                    "알림 조정 효과가 있었어요",
                    "${per.label} 예비 알림을 바꾼 뒤 평균 지연이 ${b.roundToInt()}분 → ${af.roundToInt()}분으로 줄었습니다.", true,
                ) else out += Insight(
                    "알림 조정 효과를 확인하는 중이에요",
                    "${per.label} 평균 지연: 변경 전 ${b.roundToInt()}분, 변경 후 ${af.roundToInt()}분.", false,
                )
            }
        }
        // 요일 패턴
        val wd = a.byWeekday(30)
        val totalBad = wd.sumOf { it.late + it.missed }
        val worst = wd.maxByOrNull { it.late + it.missed * 2 }
        if (worst != null && totalBad >= 4) {
            val bad = worst.late + worst.missed
            val others = (totalBad - bad).toDouble() / 6.0
            if (bad >= 3 && bad >= others * 2) {
                out += Insight(
                    "${koreanDay(worst.day)}요일에 자주 놓쳐요",
                    "최근 30일 ${koreanDay(worst.day)}요일 지연 ${worst.late}회 · 누락 ${worst.missed}회로 다른 요일보다 많습니다.", false,
                )
            }
        }
        if (out.isEmpty() && c != null && c >= 0.9) out += Insight("잘 지키고 계세요", "최근 7일 복약 이행률 ${pct(c)}입니다.", true)
        return out
    }
}
