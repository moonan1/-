package com.yaksok.pillbox.telehealth

import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.ChatMessage
import com.yaksok.pillbox.data.Doctor
import com.yaksok.pillbox.data.MsgKind
import com.yaksok.pillbox.data.Prescription
import com.yaksok.pillbox.data.RxItem
import com.yaksok.pillbox.domain.PrescriptionLogic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.UUID

/**
 * 의료진 소통 · 원격 처방 서비스.
 * 실제 서비스는 서버(의료진용 앱/웹, 인증, 암호화 저장)가 있어야 한다. 서버가 생기면 이 인터페이스를 구현해 교체한다.
 * 지금은 발표 시연용 가상 의료진(DemoTelehealth)이 정해진 문구로만 응답한다 — 의학적 조언을 생성하지 않는다.
 */
interface TelehealthService {
    val doctor: Doctor
    val isDemo: Boolean
    fun sendText(text: String)
    fun sendReport()
    fun requestConsult(symptom: String)
}

class DemoTelehealth(
    private val scope: CoroutineScope,
    private val current: () -> AppData,
    private val update: suspend ((AppData) -> AppData) -> Unit,
) : TelehealthService {
    override val doctor = Doctor("김하늘", "약속내과의원", "내과 (시연용 가상 의료진)")
    override val isDemo = true

    private fun msg(fromDoctor: Boolean, text: String, kind: MsgKind = MsgKind.TEXT, ref: String? = null) =
        ChatMessage(UUID.randomUUID().toString(), LocalDateTime.now(), fromDoctor, text, kind, ref)

    private fun post(m: ChatMessage) = scope.launch { update { it.copy(chat = it.chat + m) } }

    private fun replyLater(ms: Long, text: String) = scope.launch {
        delay(ms)
        update { it.copy(chat = it.chat + msg(true, text)) }
    }

    override fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        post(msg(false, t))
        val emergency = listOf("숨", "가슴", "의식", "쓰러", "호흡", "마비")
        val symptom = listOf("부작용", "어지", "두통", "메스", "구토", "발진", "아파", "아픈", "통증", "가려")
        val reply = when {
            emergency.any { t.contains(it) } ->
                "응급 증상이라면 지금 바로 119에 연락하거나 가까운 응급실로 가세요. 이 채팅은 응급 상황에 실시간으로 대응하지 못해요."
            symptom.any { t.contains(it) } ->
                "증상을 알려주셔서 감사해요. 진료 시간에 확인하고 답변드릴게요. 그전에 약을 임의로 끊거나 양을 바꾸지 마시고, 증상이 심해지면 바로 병원에 연락해 주세요."
            else -> "메시지 확인했어요. 진료 시간(평일 9시~18시)에 답변드릴게요."
        }
        replyLater(2500, reply)
    }

    override fun sendReport() {
        post(msg(false, PrescriptionLogic.buildReport(current(), LocalDateTime.now()), MsgKind.REPORT))
        replyLater(3000, "복약 리포트 잘 받았어요. 다음 진료 때 함께 살펴볼게요.")
    }

    override fun requestConsult(symptom: String) {
        post(msg(false, "비대면 진료 요청" + if (symptom.isNotBlank()) "\n증상·요청: ${symptom.trim()}" else "", MsgKind.CONSULT))
        scope.launch {
            delay(3000)
            update { it.copy(chat = it.chat + msg(true, "진료 요청 확인했어요. 복약 기록을 보고 처방을 보내드릴게요.")) }
            delay(4000)
            val rx = Prescription(UUID.randomUUID().toString(), LocalDateTime.now(), doctor, demoItems(current()))
            update { d ->
                d.copy(
                    prescriptions = d.prescriptions + rx,
                    chat = d.chat + msg(true, "처방전을 보냈어요 (${rx.items.size}종, ${rx.items.maxOf { it.durationDays }}일분). 약국에서 약을 받으신 뒤 앱에서 확인하고 약통 칸에 넣어 주세요.", MsgKind.PRESCRIPTION, rx.id),
                )
            }
        }
    }

    /** 시연용 처방: 복용 중인 약은 같은 용법으로 30일 연장, 약이 없으면 예시 처방 1종 */
    private fun demoItems(d: AppData): List<RxItem> {
        if (d.meds.isEmpty()) return listOf(
            RxItem("혈압약", 1, listOf(LocalTime.of(8, 0)), DayOfWeek.entries.toSet(), 30, "아침 식후"),
        )
        return d.meds.sortedBy { it.slot }.map { RxItem(it.name, it.pillsPerDose, it.times, it.weekdays, 30, it.memo) }
    }
}
