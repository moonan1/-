package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.domain.DoseStatus
import com.yaksok.pillbox.domain.canConfirm
import com.yaksok.pillbox.domain.delayMinutes
import com.yaksok.pillbox.domain.status
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.InfoRow
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SlotBadge
import com.yaksok.pillbox.ui.components.StatusChip
import com.yaksok.pillbox.ui.dateLong
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.statusColor
import java.time.Duration
import java.time.LocalDateTime

/** 복용 회차 한 줄 */
@Composable
fun DoseRow(r: DoseRecord, now: LocalDateTime, onConfirm: (() -> Unit)?, onClick: () -> Unit) {
    val s = r.status(now)
    AppCard(onClick = onClick, padding = 16.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(66.dp)) {
                Text(hm(r.time), style = MaterialTheme.typography.titleLarge, color = statusColor(s))
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.medName, style = MaterialTheme.typography.titleMedium)
                    if (r.isTest) { Spacer(Modifier.width(6.dp)); Pill("테스트", LateAmber) }
                }
                Text("${r.pills}정 · ${r.slot}번 칸", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                Spacer(Modifier.padding(top = 4.dp))
                StatusChip(s)
            }
            if (onConfirm != null && r.canConfirm(now)) {
                Button(
                    onClick = onConfirm,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.heightIn(min = 52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint),
                ) { Text("복용", style = MaterialTheme.typography.labelLarge) }
            } else {
                SlotBadge(r.slot, size = 46.dp, color = statusColor(s))
            }
        }
    }
}

/** 회차 상세 (예정/열림/확인 시각, 복용 취소) */
@Composable
fun DoseDetailDialog(r: DoseRecord, now: LocalDateTime, onConfirm: () -> Unit, onUndo: () -> Unit, onDismiss: () -> Unit) {
    val s = r.status(now)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Column {
                Text(r.medName, style = MaterialTheme.typography.headlineSmall)
                Text(dateLong(r.date), style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
        },
        text = {
            Column {
                StatusChip(s)
                Spacer(Modifier.padding(top = 8.dp))
                InfoRow("복용 예정", hm(r.time))
                InfoRow("약통 칸 / 수량", "${r.slot}번 칸 · ${r.pills}정")
                InfoRow("약통 개방", r.openedAt?.let { hm(it) } ?: "기록 없음")
                InfoRow("복용 확인", r.confirmedAt?.let { hm(it) + if (r.confirmSource == "notification") " (알림)" else "" } ?: "-")
                r.delayMinutes()?.let { InfoRow("지연", if (it == 0L) "정시" else "${it}분", valueColor = if (s == DoseStatus.LATE) LateAmber else Mint) }
                if (r.openedAt != null && r.confirmedAt == null) {
                    Spacer(Modifier.padding(top = 6.dp))
                    Text("약통이 열린 것만으로는 복용으로 기록하지 않아요. 드셨다면 복용 완료를 눌러주세요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                }
            }
        },
        confirmButton = {
            when {
                r.canConfirm(now) -> Button(onClick = { onConfirm(); onDismiss() }, colors = ButtonDefaults.buttonColors(containerColor = Mint), modifier = Modifier.heightIn(min = 48.dp)) { Text("복용 완료") }
                r.confirmedAt != null -> OutlinedButton(onClick = { onUndo(); onDismiss() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("복용 확인 취소") }
                else -> Unit
            }
        },
        dismissButton = { TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) { Text("닫기") } },
    )
}

/** 복용 완료 시각 선택: 약통이 열린 지 5분 넘었으면 '열렸을 때 복용'을 고를 수 있게 함 */
@Composable
fun ConfirmTimeDialog(r: DoseRecord, now: LocalDateTime, onPick: (LocalDateTime) -> Unit, onDismiss: () -> Unit) {
    val opened = r.openedAt ?: return
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("언제 드셨나요?", style = MaterialTheme.typography.titleLarge) },
        text = { Text("${r.slot}번 칸이 ${hm(opened)}에 열렸어요. 실제로 드신 시각으로 기록하면 분석이 정확해져요.", style = MaterialTheme.typography.bodyLarge) },
        confirmButton = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onPick(opened); onDismiss() }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                    Text("열렸을 때(${hm(opened)}) 먹었어요")
                }
                OutlinedButton(onClick = { onPick(now); onDismiss() }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                    Text("방금(${hm(now)}) 먹었어요")
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("취소") }
            }
        },
    )
}

fun needsTimeChoice(r: DoseRecord, now: LocalDateTime): Boolean =
    r.openedAt != null && Duration.between(r.openedAt, now).toMinutes() >= 5

@Composable
fun StrongText(text: String, color: Color = MaterialTheme.colorScheme.onSurface) =
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
