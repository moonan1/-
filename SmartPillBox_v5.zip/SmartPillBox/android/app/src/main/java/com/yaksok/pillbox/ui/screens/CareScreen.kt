package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.ChatMessage
import com.yaksok.pillbox.data.MsgKind
import com.yaksok.pillbox.data.Prescription
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.domain.PrescriptionLogic
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.IconCircle
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.stamp
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen

/** 홈에서 옆으로 넘기면 나오는 '의료진' 페이지: 메시지, 복약 리포트, 비대면 진료 요청, 처방 수신 */
@Composable
fun CarePage(vm: AppViewModel, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val tele = vm.telehealth
    var input by remember { mutableStateOf("") }
    var consult by remember { mutableStateOf(false) }
    var reviewing by remember { mutableStateOf<Prescription?>(null) }
    val list = rememberLazyListState()
    val newRx = d.prescriptions.filter { it.status == RxStatus.NEW }

    LaunchedEffect(d.chat.size) {
        val n = list.layoutInfo.totalItemsCount
        if (d.chat.isNotEmpty() && n > 0) list.animateScrollToItem(n - 1)
    }

    Column(modifier.fillMaxSize().imePadding()) {
        LazyColumn(
            Modifier.weight(1f), state = list,
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(58.dp).clip(CircleShape).background(MintSoft), contentAlignment = Alignment.Center) {
                            Text(tele.doctor.name.take(1), style = MaterialTheme.typography.headlineSmall, color = MintDark)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${tele.doctor.name} 선생님", style = MaterialTheme.typography.titleLarge)
                            Text("${tele.doctor.hospital} · ${tele.doctor.department}", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        }
                    }
                    if (tele.isDemo) {
                        Spacer(Modifier.height(10.dp))
                        Pill("시연용 가상 의료진 · 실제 진료가 아니에요", LateAmber)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SoftButton("복약 리포트 보내기", onClick = { tele.sendReport() }, icon = Icons.AutoMirrored.Filled.Assignment, modifier = Modifier.weight(1f))
                        BigButton("비대면 진료", onClick = { consult = true }, icon = Icons.Filled.VideoCall, modifier = Modifier.weight(1f))
                    }
                }
            }
            if (newRx.isNotEmpty()) item {
                AppCard(color = MintSoft.copy(alpha = 0.6f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.Description, Mint)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("새 처방 ${newRx.size}건", style = MaterialTheme.typography.titleMedium, color = MintDark)
                            Text("내용을 확인하고 약통 칸에 반영해 주세요", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    BigButton("처방 확인하기", onClick = { reviewing = newRx.first() }, modifier = Modifier.fillMaxWidth())
                }
            }
            if (d.chat.isEmpty()) item {
                Text("의료진에게 궁금한 점을 남기거나 복약 리포트를 보내 보세요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft,
                    modifier = Modifier.padding(vertical = 20.dp))
            }
            items(d.chat, key = { it.id }) { m -> Bubble(m, d.prescriptions, now.toLocalDate()) { rx -> reviewing = rx } }
        }
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it.take(300) }, modifier = Modifier.weight(1f),
                placeholder = { Text("의료진에게 메시지") }, shape = RoundedCornerShape(18.dp), maxLines = 4,
                textStyle = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = { tele.sendText(input); input = "" }, enabled = input.isNotBlank(),
                modifier = Modifier.size(56.dp).clip(CircleShape).background(if (input.isNotBlank()) Mint else Line),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "보내기", tint = Color.White) }
        }
    }

    if (consult) ConsultDialog(onDismiss = { consult = false }) { tele.requestConsult(it); consult = false }
    reviewing?.let { rx0 ->
        val rx = d.prescriptions.firstOrNull { it.id == rx0.id } ?: rx0
        PrescriptionDialog(rx, vm, onDismiss = { reviewing = null })
    }
}

@Composable
private fun Bubble(m: ChatMessage, rxs: List<Prescription>, today: java.time.LocalDate, onRx: (Prescription) -> Unit) {
    if (m.kind == MsgKind.SYSTEM) {
        Text(m.text, style = MaterialTheme.typography.bodySmall, color = InkSoft, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 2.dp))
        return
    }
    val mine = !m.fromDoctor
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            Column(
                Modifier.widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (mine) 20.dp else 6.dp, bottomEnd = if (mine) 6.dp else 20.dp))
                    .background(if (mine) Mint else Color.White)
                    .border(if (mine) 0.dp else 1.dp, Line, RoundedCornerShape(20.dp))
                    .padding(14.dp),
            ) {
                when (m.kind) {
                    MsgKind.REPORT -> Text("📋 복약 리포트", style = MaterialTheme.typography.labelLarge, color = if (mine) Color.White else MintDark)
                    MsgKind.CONSULT -> Text("🩺 진료 요청", style = MaterialTheme.typography.labelLarge, color = if (mine) Color.White else MintDark)
                    MsgKind.PRESCRIPTION -> Text("💊 처방전", style = MaterialTheme.typography.labelLarge, color = MintDark)
                    else -> Unit
                }
                Text(m.text, style = MaterialTheme.typography.bodyLarge, color = if (mine) Color.White else Ink)
                if (m.kind == MsgKind.PRESCRIPTION) {
                    val rx = rxs.firstOrNull { it.id == m.refId }
                    if (rx != null) {
                        Spacer(Modifier.height(8.dp))
                        Pill(rx.status.label, when (rx.status) { RxStatus.NEW -> LateAmber; RxStatus.APPLIED -> OkGreen; RxStatus.DECLINED -> InkSoft })
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { onRx(rx) }, modifier = Modifier.heightIn(min = 48.dp)) { Text(if (rx.status == RxStatus.NEW) "처방 확인하기" else "처방 보기") }
                    }
                }
            }
            Text(stamp(m.at, today), style = MaterialTheme.typography.labelSmall, color = InkSoft, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
        }
    }
}

@Composable
private fun ConsultDialog(onDismiss: () -> Unit, onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        icon = { Icon(Icons.Filled.MedicalServices, null, tint = Mint) },
        title = { Text("비대면 진료 요청", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                Text("증상이나 요청 사항을 적어 주세요. 최근 복약 기록도 함께 확인할 수 있어요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(text, { text = it.take(200) }, placeholder = { Text("예: 약이 거의 떨어져서 재처방 받고 싶어요") },
                    modifier = Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                Text("응급 상황이면 119에 연락하세요.", style = MaterialTheme.typography.bodySmall, color = MissRed)
            }
        },
        confirmButton = { Button(onClick = { onSend(text) }, colors = ButtonDefaults.buttonColors(containerColor = Mint), modifier = Modifier.heightIn(min = 48.dp)) { Text("요청하기") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } },
    )
}

/** 처방 확인 → 새 약은 빈 칸 지정 → 약 관리에 반영 (자동 적용하지 않음) */
@Composable
private fun PrescriptionDialog(rx: Prescription, vm: AppViewModel, onDismiss: () -> Unit) {
    val d by vm.data.collectAsStateWithLifecycle()
    val needs = remember(rx.id, d.meds) { PrescriptionLogic.itemsNeedingSlot(d, rx) }
    val free = PrescriptionLogic.freeSlots(d)
    val choice = remember(rx.id) { mutableStateMapOf<Int, Int>().apply { needs.forEachIndexed { k, idx -> free.getOrNull(k)?.let { put(idx, it) } } } }
    val editable = rx.status == RxStatus.NEW
    val ready = needs.all { choice[it] != null } && choice.values.toSet().size == choice.size
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Column {
                Text("처방 내용", style = MaterialTheme.typography.headlineSmall)
                Text("${rx.doctor.name} · ${rx.doctor.hospital} · ${rx.issuedAt.toLocalDate()} ${hm(rx.issuedAt)}", style = MaterialTheme.typography.bodySmall, color = InkSoft)
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                rx.items.forEachIndexed { i, item ->
                    val existing = PrescriptionLogic.matchExisting(d.meds, item)
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFF5F9F8)).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Pill(if (existing != null) "${existing.slot}번 칸 갱신" else "새 약", if (existing != null) Mint else LateAmber)
                        }
                        Text("1회 ${item.pillsPerDose}정 · ${weekdayText(item.weekdays)} · ${item.durationDays}일분", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        Text(PrescriptionLogic.periodsText(item), style = MaterialTheme.typography.bodyMedium, color = Ink)
                        if (item.note.isNotBlank()) Text("메모: ${item.note}", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                        if (editable && existing == null) {
                            Spacer(Modifier.height(8.dp))
                            Text("넣을 칸", style = MaterialTheme.typography.labelMedium, color = InkSoft)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                                if (free.isEmpty()) Text("빈 칸이 없어요. 약 관리에서 칸을 비워 주세요.", color = MissRed, style = MaterialTheme.typography.bodySmall)
                                free.forEach { s ->
                                    val sel = choice[i] == s
                                    val usedByOther = choice.any { (k, v) -> k != i && v == s }
                                    Box(
                                        Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                                            .background(if (sel) Mint else Color.White)
                                            .border(1.dp, if (sel) Mint else Line, RoundedCornerShape(12.dp))
                                            .clickable(enabled = !usedByOther) { choice[i] = s },
                                        contentAlignment = Alignment.Center,
                                    ) { Text("$s", color = if (sel) Color.White else if (usedByOther) Line else Ink, fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                    }
                }
                Text(
                    if (editable) "반영하면 복용 일정이 약 관리에 저장되고 약통에 자동 전송돼요. 약국에서 받은 약을 해당 칸에 넣어 주세요."
                    else "이 처방은 ${rx.status.label} 상태예요.",
                    style = MaterialTheme.typography.bodySmall, color = InkSoft,
                )
            }
        },
        confirmButton = {
            if (editable) Button(
                onClick = { vm.applyPrescription(rx, choice.toMap()); onDismiss() }, enabled = ready,
                colors = ButtonDefaults.buttonColors(containerColor = Mint), modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("약 관리에 반영") }
            else TextButton(onClick = onDismiss) { Text("닫기") }
        },
        dismissButton = {
            if (editable) TextButton(onClick = { vm.declinePrescription(rx); onDismiss() }) { Text("반영 안 함", color = InkSoft) }
        },
    )
}
