@file:OptIn(FlowPreview::class)

package com.yaksok.pillbox

import android.app.Application
import com.yaksok.pillbox.data.AppRepository
import com.yaksok.pillbox.device.DeviceManager
import com.yaksok.pillbox.notify.AlarmScheduler
import com.yaksok.pillbox.notify.Notifier
import com.yaksok.pillbox.telehealth.DemoTelehealth
import com.yaksok.pillbox.telehealth.TelehealthService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch

class PillApp : Application() {
    lateinit var repo: AppRepository
        private set
    lateinit var devices: DeviceManager
        private set
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    /** 의료진 소통 서비스 — 서버가 생기면 실제 구현으로 교체 */
    lateinit var telehealth: TelehealthService
        private set

    override fun onCreate() {
        super.onCreate()
        repo = AppRepository(this)
        repo.loadBlocking()
        Notifier.ensureChannels(this)
        devices = DeviceManager(this, repo, appScope)
        telehealth = DemoTelehealth(appScope, { repo.data.value }, { f -> repo.update(f) })

        // 데이터가 바뀌면 다음 알림 다시 예약
        appScope.launch {
            repo.data.debounce(500).collect { AlarmScheduler.reschedule(this@PillApp, it, repo.lastAlarmCheck) }
        }
        // 자정이 지나면 새 날짜의 복용 회차 생성
        appScope.launch {
            while (true) { delay(60_000); repo.ensureToday() }
        }
    }
}
