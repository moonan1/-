package com.yaksok.pillbox.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yaksok.pillbox.PillApp
import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.BoxSettings
import com.yaksok.pillbox.data.DataMode
import com.yaksok.pillbox.data.DeviceKind
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.data.NotificationSettings
import com.yaksok.pillbox.data.SettingChange
import com.yaksok.pillbox.domain.DoseGenerator
import com.yaksok.pillbox.domain.Suggestion
import com.yaksok.pillbox.domain.PrescriptionLogic
import com.yaksok.pillbox.data.Prescription
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as PillApp
    val repo = app.repo
    val devices = app.devices

    val data: StateFlow<AppData> = repo.data
    val mode: StateFlow<DataMode> = repo.mode
    val deviceKind: StateFlow<DeviceKind> = repo.deviceKind
    val deviceStatus = devices.status
    val deviceBusy = devices.busy
    val messages: SharedFlow<String> = devices.messages
    val telehealth = app.telehealth

    /** 화면의 '현재 시각' (상태 계산용, 15초마다 갱신) */
    private val _now = MutableStateFlow(LocalDateTime.now())
    val now: StateFlow<LocalDateTime> = _now.asStateFlow()

    init {
        viewModelScope.launch {
            while (isActive) {
                _now.value = LocalDateTime.now()
                repo.ensureToday()
                delay(15_000)
            }
        }
    }

    fun refreshNow() { _now.value = LocalDateTime.now() }

    // ───────── 약 ─────────
    fun newMedId(): String = UUID.randomUUID().toString()

    fun saveMed(m: Medication) = viewModelScope.launch {
        repo.update { d ->
            val meds = if (d.meds.any { it.id == m.id }) d.meds.map { if (it.id == m.id) m else it } else d.meds + m
            DoseGenerator.refreshToday(d.copy(meds = meds), LocalDateTime.now())
        }
        refreshNow()
    }

    fun deleteMed(id: String) = viewModelScope.launch {
        repo.update { d -> DoseGenerator.refreshToday(d.copy(meds = d.meds.filterNot { it.id == id }), LocalDateTime.now()) }
        refreshNow()
    }

    // ───────── 복용 확인 ─────────
    fun confirm(key: String, at: LocalDateTime = LocalDateTime.now()) = viewModelScope.launch {
        devices.confirmDose(key, at, "app"); refreshNow()
    }

    fun undoConfirm(key: String) = viewModelScope.launch { devices.undoConfirm(key); refreshNow() }

    // ───────── 맞춤 알림 ─────────
    fun accept(s: Suggestion) = viewModelScope.launch {
        repo.update { d ->
            val ch = SettingChange(
                id = UUID.randomUUID().toString(), at = LocalDateTime.now(), title = s.title, detail = s.changeSummary,
                source = "suggestion", before = d.notif, after = s.proposed, period = s.period,
            )
            d.copy(notif = s.proposed, changes = d.changes + ch)
        }
    }

    fun dismiss(s: Suggestion) = viewModelScope.launch {
        repo.update { d -> d.copy(dismissed = d.dismissed + (s.key to LocalDateTime.now().toLocalDate())) }
    }

    fun revert(change: SettingChange) = viewModelScope.launch {
        repo.update { d ->
            val back = SettingChange(
                id = UUID.randomUUID().toString(), at = LocalDateTime.now(), title = "되돌림: ${change.title}",
                detail = "이전 설정으로 복원", source = "revert", before = d.notif, after = change.before,
            )
            d.copy(
                notif = change.before,
                changes = d.changes.map { if (it.id == change.id) it.copy(reverted = true) else it } + back,
            )
        }
    }

    fun setNotif(n: NotificationSettings, title: String) = viewModelScope.launch {
        repo.update { d ->
            if (d.notif == n) d
            else d.copy(
                notif = n,
                changes = d.changes + SettingChange(UUID.randomUUID().toString(), LocalDateTime.now(), title, n.describe(), "manual", d.notif, n),
            )
        }
    }

    fun setBox(b: BoxSettings) = viewModelScope.launch { repo.update { it.copy(box = b) } }

    // ───────── 처방 ─────────
    fun applyPrescription(rx: Prescription, slotFor: Map<Int, Int>) = viewModelScope.launch {
        runCatching { repo.update { PrescriptionLogic.apply(it, rx, slotFor, LocalDateTime.now()) } }
        refreshNow()
    }

    fun declinePrescription(rx: Prescription) = viewModelScope.launch {
        repo.update { PrescriptionLogic.decline(it, rx, LocalDateTime.now()) }
    }

    // ───────── 모드 ─────────
    fun switchMode(m: DataMode) = viewModelScope.launch { repo.switchMode(m); refreshNow() }
    fun resetDemo() = viewModelScope.launch { repo.resetDemo(); refreshNow() }
    fun switchDevice(k: DeviceKind) = devices.switchKind(k)
}
