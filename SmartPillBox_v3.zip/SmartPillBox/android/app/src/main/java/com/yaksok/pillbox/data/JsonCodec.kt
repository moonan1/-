package com.yaksok.pillbox.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

/**
 * 로컬 저장 형식(JSON). 나중에 Room/클라우드로 바꿀 때는 AppRepository의 읽기/쓰기만 교체하면 된다.
 */
object JsonCodec {
    private fun JSONObject.optStr(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null

    private fun notifToJson(n: NotificationSettings) = JSONObject().apply {
        put("enabled", n.enabled)
        put("interval", n.reminderIntervalMin)
        put("max", n.maxReminders)
        put("pre", JSONObject().apply { Period.entries.forEach { put(it.name, n.preAlert(it)) } })
    }

    private fun notifFrom(o: JSONObject?): NotificationSettings {
        if (o == null) return NotificationSettings()
        val pre = o.optJSONObject("pre")
        return NotificationSettings(
            enabled = o.optBoolean("enabled", true),
            reminderIntervalMin = o.optInt("interval", 10),
            maxReminders = o.optInt("max", 2),
            preAlertMin = Period.entries.associateWith { pre?.optInt(it.name, 0) ?: 0 },
        )
    }

    private fun doctorToJson(d: Doctor) = JSONObject().apply { put("name", d.name); put("hospital", d.hospital); put("dept", d.department) }
    private fun doctorFrom(o: JSONObject?) = Doctor(o?.optString("name", "") ?: "", o?.optString("hospital", "") ?: "", o?.optString("dept", "") ?: "")

    private fun rxToJson(r: Prescription) = JSONObject().apply {
        put("id", r.id); put("at", r.issuedAt.toString()); put("doctor", doctorToJson(r.doctor))
        put("status", r.status.name); put("handled", r.handledAt?.toString() ?: JSONObject.NULL)
        put("items", JSONArray().apply {
            r.items.forEach { i ->
                put(JSONObject().apply {
                    put("name", i.name); put("pills", i.pillsPerDose); put("days", i.durationDays); put("note", i.note)
                    put("times", JSONArray(i.times.map { it.toString() }))
                    put("week", JSONArray(i.weekdays.map { it.value }))
                })
            }
        })
    }

    private fun rxFrom(o: JSONObject): Prescription {
        val items = o.getJSONArray("items")
        return Prescription(
            id = o.getString("id"),
            issuedAt = LocalDateTime.parse(o.getString("at")),
            doctor = doctorFrom(o.optJSONObject("doctor")),
            status = runCatching { RxStatus.valueOf(o.optString("status", "NEW")) }.getOrDefault(RxStatus.NEW),
            handledAt = o.optStr("handled")?.let { LocalDateTime.parse(it) },
            items = (0 until items.length()).map { k ->
                val i = items.getJSONObject(k)
                val t = i.getJSONArray("times")
                val w = i.getJSONArray("week")
                RxItem(
                    name = i.getString("name"), pillsPerDose = i.optInt("pills", 1), durationDays = i.optInt("days", 30),
                    note = i.optString("note", ""),
                    times = (0 until t.length()).map { LocalTime.parse(t.getString(it)) },
                    weekdays = (0 until w.length()).map { DayOfWeek.of(w.getInt(it)) }.toSet(),
                )
            },
        )
    }

    fun encode(d: AppData): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("meds", JSONArray().apply {
            d.meds.forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id); put("name", m.name); put("pills", m.pillsPerDose)
                    put("times", JSONArray(m.times.map { it.toString() }))
                    put("days", JSONArray(m.weekdays.map { it.value }))
                    put("start", m.startDate.toString())
                    put("end", m.endDate?.toString() ?: JSONObject.NULL)
                    put("slot", m.slot); put("memo", m.memo)
                })
            }
        })
        root.put("records", JSONArray().apply {
            d.records.forEach { r ->
                put(JSONObject().apply {
                    put("key", r.key); put("medId", r.medId); put("name", r.medName)
                    put("pills", r.pills); put("slot", r.slot)
                    put("date", r.date.toString()); put("time", r.time.toString())
                    put("opened", r.openedAt?.toString() ?: JSONObject.NULL)
                    put("confirmed", r.confirmedAt?.toString() ?: JSONObject.NULL)
                    put("src", r.confirmSource ?: JSONObject.NULL)
                    put("test", r.isTest)
                })
            }
        })
        root.put("notif", notifToJson(d.notif))
        root.put("changes", JSONArray().apply {
            d.changes.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id); put("at", c.at.toString()); put("title", c.title); put("detail", c.detail)
                    put("source", c.source); put("before", notifToJson(c.before)); put("after", notifToJson(c.after))
                    put("reverted", c.reverted); put("period", c.period?.name ?: JSONObject.NULL)
                })
            }
        })
        root.put("dismissed", JSONObject().apply { d.dismissed.forEach { (k, v) -> put(k, v.toString()) } })
        root.put("deviceLog", JSONArray().apply {
            d.deviceLog.forEach { e -> put(JSONObject().apply { put("at", e.at.toString()); put("text", e.text); put("level", e.level) }) }
        })
        root.put("lastSeq", JSONObject().apply { d.lastDeviceSeq.forEach { (k, v) -> put(k, v) } })
        root.put("lastGenerated", d.lastGenerated?.toString() ?: JSONObject.NULL)
        root.put("box", JSONObject().apply { put("hold", d.box.holdSec); put("grace", d.box.graceMin) })
        root.put("chat", JSONArray().apply {
            d.chat.forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id); put("at", m.at.toString()); put("doc", m.fromDoctor); put("text", m.text)
                    put("kind", m.kind.name); put("ref", m.refId ?: JSONObject.NULL)
                })
            }
        })
        root.put("rx", JSONArray().apply { d.prescriptions.forEach { put(rxToJson(it)) } })
        return root.toString()
    }

    fun decode(text: String): AppData {
        val root = JSONObject(text)
        val meds = root.optJSONArray("meds")?.let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val times = o.getJSONArray("times")
                val days = o.getJSONArray("days")
                Medication(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    pillsPerDose = o.optInt("pills", 1),
                    times = (0 until times.length()).map { LocalTime.parse(times.getString(it)) },
                    weekdays = (0 until days.length()).map { DayOfWeek.of(days.getInt(it)) }.toSet(),
                    startDate = LocalDate.parse(o.getString("start")),
                    endDate = o.optStr("end")?.let { LocalDate.parse(it) },
                    slot = o.getInt("slot"),
                    memo = o.optString("memo", ""),
                )
            }
        } ?: emptyList()
        val records = root.optJSONArray("records")?.let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                DoseRecord(
                    key = o.getString("key"),
                    medId = o.getString("medId"),
                    medName = o.getString("name"),
                    pills = o.optInt("pills", 1),
                    slot = o.getInt("slot"),
                    date = LocalDate.parse(o.getString("date")),
                    time = LocalTime.parse(o.getString("time")),
                    openedAt = o.optStr("opened")?.let { LocalDateTime.parse(it) },
                    confirmedAt = o.optStr("confirmed")?.let { LocalDateTime.parse(it) },
                    confirmSource = o.optStr("src"),
                    isTest = o.optBoolean("test", false),
                )
            }
        } ?: emptyList()
        val changes = root.optJSONArray("changes")?.let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                SettingChange(
                    id = o.getString("id"),
                    at = LocalDateTime.parse(o.getString("at")),
                    title = o.getString("title"),
                    detail = o.optString("detail", ""),
                    source = o.optString("source", "manual"),
                    before = notifFrom(o.optJSONObject("before")),
                    after = notifFrom(o.optJSONObject("after")),
                    reverted = o.optBoolean("reverted", false),
                    period = o.optStr("period")?.let { runCatching { Period.valueOf(it) }.getOrNull() },
                )
            }
        } ?: emptyList()
        val dismissed = root.optJSONObject("dismissed")?.let { o ->
            o.keys().asSequence().associateWith { LocalDate.parse(o.getString(it)) }
        } ?: emptyMap()
        val log = root.optJSONArray("deviceLog")?.let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                DeviceLogEntry(LocalDateTime.parse(o.getString("at")), o.getString("text"), o.optInt("level", 0))
            }
        } ?: emptyList()
        val lastSeq = root.optJSONObject("lastSeq")?.let { o ->
            o.keys().asSequence().associateWith { o.getInt(it) }
        } ?: emptyMap()
        val box = root.optJSONObject("box")
        val chat = root.optJSONArray("chat")?.let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                ChatMessage(
                    id = o.getString("id"), at = LocalDateTime.parse(o.getString("at")), fromDoctor = o.optBoolean("doc", false),
                    text = o.optString("text", ""), kind = runCatching { MsgKind.valueOf(o.optString("kind", "TEXT")) }.getOrDefault(MsgKind.TEXT),
                    refId = o.optStr("ref"),
                )
            }
        } ?: emptyList()
        val rx = root.optJSONArray("rx")?.let { a -> (0 until a.length()).map { rxFrom(a.getJSONObject(it)) } } ?: emptyList()
        return AppData(
            chat = chat,
            prescriptions = rx,
            meds = meds,
            records = records,
            notif = notifFrom(root.optJSONObject("notif")),
            changes = changes,
            dismissed = dismissed,
            deviceLog = log,
            lastDeviceSeq = lastSeq,
            lastGenerated = root.optStr("lastGenerated")?.let { LocalDate.parse(it) },
            box = BoxSettings(box?.optInt("hold", 60) ?: 60, box?.optInt("grace", 30) ?: 30),
        )
    }
}
