@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.Overlay
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.data.SLOT_COUNT
import com.yaksok.pillbox.domain.koreanDay
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.ConfirmDialog
import com.yaksok.pillbox.ui.components.EmptyState
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.SlotBadge
import com.yaksok.pillbox.ui.dateShort
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneOffset

fun weekdayText(days: Set<DayOfWeek>): String = when {
    days.size == 7 -> "매일"
    days == setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY) -> "평일"
    days == setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY) -> "주말"
    else -> DayOfWeek.entries.filter { it in days }.joinToString("·") { koreanDay(it) }
}

@Composable
fun MedsScreen(vm: AppViewModel, open: (Overlay) -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    var deleting by remember { mutableStateOf<Medication?>(null) }
    val bySlot = d.meds.associateBy { it.slot }

    Box(modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Text("약 관리", style = MaterialTheme.typography.headlineLarge)
                Text("칸마다 약 1가지를 넣어요. 칸을 누르면 약을 등록하거나 바꿀 수 있어요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
            item {
                AppCard {
                    Text("약통 칸 구성", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    for (row in 0 until 2) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                            for (col in 0 until 3) {
                                val slot = row * 3 + col + 1
                                val m = bySlot[slot]
                                Column(
                                    Modifier.weight(1f).heightIn(min = 96.dp).clip(RoundedCornerShape(16.dp))
                                        .background(if (m != null) MintSoft else Color.White)
                                        .border(1.dp, if (m != null) Mint.copy(alpha = 0.4f) else Line, RoundedCornerShape(16.dp))
                                        .clickable { open(Overlay.EditMed(m?.id, slot)) }
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                ) {
                                    Text("${slot}번", style = MaterialTheme.typography.labelLarge, color = if (m != null) MintDark else InkSoft)
                                    Spacer(Modifier.height(4.dp))
                                    Text(m?.name ?: "비어 있음", style = MaterialTheme.typography.bodyMedium, color = if (m != null) Ink else InkSoft,
                                        textAlign = TextAlign.Center, maxLines = 2, fontWeight = if (m != null) FontWeight.SemiBold else FontWeight.Normal)
                                    if (m != null) Text(m.times.sorted().joinToString(" ") { hm(it) }, style = MaterialTheme.typography.labelSmall, color = InkSoft, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
            item { SectionTitle("등록된 약", trailing = { Text("${d.meds.size}개", color = InkSoft, style = MaterialTheme.typography.bodyLarge) }) }
            if (d.meds.isEmpty()) item {
                AppCard { EmptyState(Icons.Filled.Medication, "등록된 약이 없어요", "아래 '약 추가' 버튼을 눌러 첫 약을 등록하세요.") }
            }
            items(d.meds.sortedBy { it.slot }, key = { it.id }) { m -> MedCard(m, onEdit = { open(Overlay.EditMed(m.id)) }, onDelete = { deleting = m }) }
        }
        ExtendedFloatingActionButton(
            onClick = { open(Overlay.EditMed(null)) },
            containerColor = Mint, contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp).heightIn(min = 60.dp),
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("약 추가", style = MaterialTheme.typography.labelLarge) },
        )
    }
    deleting?.let { m ->
        ConfirmDialog(
            "약 삭제", "'${m.name}'을(를) 삭제할까요? 지난 복용 기록은 남고, 오늘 남은 회차와 약통 일정에서 빠져요.", "삭제",
            onConfirm = { vm.deleteMed(m.id) }, onDismiss = { deleting = null }, danger = true,
        )
    }
}

@Composable
private fun MedCard(m: Medication, onEdit: () -> Unit, onDelete: () -> Unit) {
    AppCard(onClick = onEdit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SlotBadge(m.slot, size = 54.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(m.name, style = MaterialTheme.typography.titleLarge)
                Text("1회 ${m.pillsPerDose}정 · ${weekdayText(m.weekdays)}", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
            IconButton(onClick = onEdit, modifier = Modifier.size(52.dp)) { Icon(Icons.Filled.Edit, "수정", tint = InkSoft) }
            IconButton(onClick = onDelete, modifier = Modifier.size(52.dp)) { Icon(Icons.Filled.Delete, "삭제", tint = MissRed) }
        }
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            m.times.sorted().forEach { Pill(hm(it), Mint) }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "${dateShort(m.startDate)}부터 " + (m.endDate?.let { "${dateShort(it)}까지" } ?: "계속"),
            style = MaterialTheme.typography.bodySmall, color = InkSoft,
        )
    }
}

// ───────── 약 추가/수정 화면 ─────────
@Composable
fun MedEditScreen(vm: AppViewModel, medId: String?, presetSlot: Int?, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val existing = remember(medId) { d.meds.firstOrNull { it.id == medId } }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var pills by remember { mutableStateOf(existing?.pillsPerDose ?: 1) }
    val times = remember { mutableStateListOf<LocalTime>().apply { addAll(existing?.times ?: listOf(LocalTime.of(8, 0))) } }
    val days = remember { mutableStateListOf<DayOfWeek>().apply { addAll(existing?.weekdays ?: DayOfWeek.entries) } }
    var start by remember { mutableStateOf(existing?.startDate ?: LocalDate.now()) }
    var end by remember { mutableStateOf(existing?.endDate) }
    val usedSlots = d.meds.filter { it.id != medId }.associateBy { it.slot }
    var slot by remember { mutableStateOf(existing?.slot ?: presetSlot?.takeIf { it !in usedSlots } ?: (1..SLOT_COUNT).firstOrNull { it !in usedSlots } ?: 0) }

    var timeDialog by remember { mutableStateOf<Int?>(null) }   // -1 = 추가, 그 외 = 수정할 인덱스
    var dateDialog by remember { mutableStateOf<String?>(null) } // "start" | "end"
    var error by remember { mutableStateOf<String?>(null) }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(56.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "뒤로") }
            Text(if (existing == null) "약 추가" else "약 수정", style = MaterialTheme.typography.headlineSmall)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            AppCard {
                Label("약 이름")
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(20) }, singleLine = true,
                    placeholder = { Text("예: 혈압약") }, textStyle = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                )
                Spacer(Modifier.height(16.dp))
                Label("1회 복용 개수")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StepButton(Icons.Filled.Remove, enabled = pills > 1) { pills-- }
                    Text("${pills}정", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.width(96.dp), textAlign = TextAlign.Center)
                    StepButton(Icons.Filled.Add, enabled = pills < 10) { pills++ }
                }
            }
            AppCard {
                Label("복용 시간 (하루 여러 번 가능)")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    times.sorted().forEach { t ->
                        val idx = times.indexOf(t)
                        Row(
                            Modifier.clip(RoundedCornerShape(14.dp)).background(MintSoft).clickable { timeDialog = idx }.padding(start = 14.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(hm(t), style = MaterialTheme.typography.titleLarge, color = MintDark)
                            IconButton(onClick = { if (times.size > 1) times.remove(t) }, modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Filled.Close, "삭제", tint = InkSoft)
                            }
                        }
                    }
                    Row(
                        Modifier.clip(RoundedCornerShape(14.dp)).border(1.dp, Mint, RoundedCornerShape(14.dp)).clickable { timeDialog = -1 }
                            .heightIn(min = 44.dp).padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Add, null, tint = Mint)
                        Text("시간 추가", color = Mint, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
            AppCard {
                Label("복용 요일")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DayOfWeek.entries.forEach { day ->
                        val sel = day in days
                        Box(
                            Modifier.weight(1f).heightIn(min = 50.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (sel) Mint else Color.White).border(1.dp, if (sel) Mint else Line, RoundedCornerShape(12.dp))
                                .clickable { if (sel) days.remove(day) else days.add(day) },
                            contentAlignment = Alignment.Center,
                        ) { Text(koreanDay(day), color = if (sel) Color.White else Ink, style = MaterialTheme.typography.labelLarge) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickChip("매일") { days.clear(); days.addAll(DayOfWeek.entries) }
                    QuickChip("평일") { days.clear(); days.addAll(DayOfWeek.entries.take(5)) }
                    QuickChip("주말") { days.clear(); days.addAll(DayOfWeek.entries.takeLast(2)) }
                }
            }
            AppCard {
                Label("복용 기간")
                DateRow("시작일", "${start.year}년 ${start.monthValue}월 ${start.dayOfMonth}일") { dateDialog = "start" }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    Text("종료일 지정", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Switch(
                        checked = end != null, onCheckedChange = { end = if (it) start.plusDays(13) else null },
                        colors = SwitchDefaults.colors(checkedTrackColor = Mint),
                    )
                }
                end?.let { e -> DateRow("종료일", "${e.year}년 ${e.monthValue}월 ${e.dayOfMonth}일") { dateDialog = "end" } }
            }
            AppCard {
                Label("약통 칸 번호")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (s in 1..SLOT_COUNT) {
                        val taken = usedSlots[s]
                        val sel = slot == s
                        Column(
                            Modifier.weight(1f).heightIn(min = 64.dp).clip(RoundedCornerShape(14.dp))
                                .background(when { sel -> Mint; taken != null -> Color(0xFFF1F3F3); else -> Color.White })
                                .border(1.dp, if (sel) Mint else Line, RoundedCornerShape(14.dp))
                                .clickable(enabled = taken == null) { slot = s },
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                        ) {
                            Text("$s", style = MaterialTheme.typography.titleLarge, color = when { sel -> Color.White; taken != null -> InkSoft.copy(alpha = 0.5f); else -> Ink })
                            if (taken != null) Text("사용 중", style = MaterialTheme.typography.labelSmall, color = InkSoft.copy(alpha = 0.6f))
                        }
                    }
                }
                if (usedSlots.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text("사용 중인 칸: " + usedSlots.values.sortedBy { it.slot }.joinToString(", ") { "${it.slot}번 ${it.name}" }, style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
            }
            AppCard(color = MintSoft.copy(alpha = 0.5f)) {
                Text("저장하면 연결된 약통에 일정이 자동 전송돼요. 약통은 이 시간에 ${if (slot > 0) "${slot}번" else "해당"} 칸만 열고 다른 칸은 잠금을 유지해요.", style = MaterialTheme.typography.bodyMedium, color = MintDark)
            }
            error?.let { Text(it, color = MissRed, style = MaterialTheme.typography.bodyLarge) }
            Spacer(Modifier.height(4.dp))
        }
        BigButton(
            "저장하기", modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            onClick = {
                error = when {
                    name.isBlank() -> "약 이름을 입력해 주세요."
                    times.isEmpty() -> "복용 시간을 하나 이상 추가해 주세요."
                    days.isEmpty() -> "복용 요일을 하나 이상 선택해 주세요."
                    slot !in 1..SLOT_COUNT -> "비어 있는 약통 칸을 선택해 주세요."
                    end?.isBefore(start) == true -> "종료일이 시작일보다 빨라요."
                    else -> null
                }
                if (error == null) {
                    vm.saveMed(
                        Medication(
                            id = existing?.id ?: vm.newMedId(), name = name.trim(), pillsPerDose = pills,
                            times = times.distinct().sorted(), weekdays = days.toSet(), startDate = start, endDate = end,
                            slot = slot, memo = existing?.memo ?: "",
                        )
                    )
                    onBack()
                }
            },
        )
    }

    timeDialog?.let { idx ->
        val init = if (idx >= 0) times.getOrNull(idx) ?: LocalTime.of(8, 0) else LocalTime.of(12, 0)
        TimeDialog(init, onDismiss = { timeDialog = null }) { t ->
            if (idx >= 0 && idx < times.size) times[idx] = t else if (t !in times) times.add(t)
            timeDialog = null
        }
    }
    dateDialog?.let { which ->
        val init = if (which == "start") start else end ?: start
        DateDialog(init, onDismiss = { dateDialog = null }) { picked ->
            if (which == "start") { start = picked; if (end?.isBefore(picked) == true) end = picked } else end = picked
            dateDialog = null
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = InkSoft, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun StepButton(icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(if (enabled) MintSoft else Color(0xFFF1F3F3)).clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = if (enabled) MintDark else InkSoft.copy(alpha = 0.4f), modifier = Modifier.size(28.dp)) }
}

@Composable
private fun QuickChip(text: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(MintSoft).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(text, color = MintDark, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun DateRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MintSoft.copy(alpha = 0.5f)).clickable { onClick() }
            .heightIn(min = 56.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = InkSoft, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.titleMedium, color = MintDark)
    }
}

@Composable
fun TimeDialog(init: LocalTime, onDismiss: () -> Unit, onPick: (LocalTime) -> Unit) {
    val state = rememberTimePickerState(initialHour = init.hour, initialMinute = init.minute, is24Hour = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("복용 시간", style = MaterialTheme.typography.titleLarge) },
        text = { TimePicker(state = state) },
        confirmButton = { TextButton(onClick = { onPick(LocalTime.of(state.hour, state.minute)) }) { Text("확인", style = MaterialTheme.typography.labelLarge) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소", style = MaterialTheme.typography.labelLarge) } },
    )
}

@Composable
fun DateDialog(init: LocalDate, onDismiss: () -> Unit, onPick: (LocalDate) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = init.atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli())
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) } ?: onDismiss()
            }) { Text("확인") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } },
    ) { DatePicker(state = state) }
}
