@file:OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)

package com.yaksok.pillbox.device

import android.content.Context
import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.AppRepository
import com.yaksok.pillbox.data.BoxSettings
import com.yaksok.pillbox.data.DeviceKind
import com.yaksok.pillbox.data.DeviceLogEntry
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.notify.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.UUID
import kotlin.math.abs

/**
 * 앱 데이터 ↔ 약통 연결 관리.
 * - 연결되면: 시계 확인/설정 → 놓친 이벤트 기록 동기화 → 일정 비교 후 전송
 * - 약을 수정하면 연결된 약통에 일정을 자동 전송
 * - 약통 이벤트(칸 열림 등)를 복용 기록에 연결
 */
class DeviceManager(private val ctx: Context, private val repo: AppRepository, private val scope: CoroutineScope) {
    val sim = SimulatedPillBox()
    private val usb: PillBoxDevice by lazy { SerialPillBox(UsbSerialTransport(ctx), "usb") }
    private val bt: PillBoxDevice by lazy { SerialPillBox(BluetoothSppTransport(ctx) { repo.btAddress }, "bt") }

    private val _current = MutableStateFlow(pick(repo.deviceKind.value))
    val current: StateFlow<PillBoxDevice> = _current.asStateFlow()
    val status: StateFlow<DeviceStatus> = _current.flatMapLatest { it.status }
        .stateIn(scope, SharingStarted.Eagerly, DeviceStatus())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val syncMutex = Mutex()
    @Volatile private var syncing = false
    private val liveBuffer = ArrayList<BoxEvent>()

    private fun pick(k: DeviceKind): PillBoxDevice = when (k) {
        DeviceKind.USB -> usb
        DeviceKind.BLUETOOTH -> bt
        DeviceKind.SIMULATION -> sim
    }

    init {
        // 실시간 이벤트
        scope.launch {
            _current.collectLatest { dev -> dev.events.collect { ev -> onLiveEvent(dev, ev) } }
        }
        // 연결될 때마다 동기화
        scope.launch {
            _current.collectLatest { dev ->
                var prev = dev.status.value.link
                dev.status.collect { st ->
                    if (st.link == LinkState.CONNECTED && prev != LinkState.CONNECTED) scope.launch { syncAll(dev) }
                    if (st.link != LinkState.CONNECTED && prev == LinkState.CONNECTED) {
                        addLog("약통 연결이 끊겼어요: ${st.message}", 1)
                    }
                    prev = st.link
                }
            }
        }
        // 약/약통 설정이 바뀌면 일정 자동 전송
        scope.launch {
            repo.data.map { buildSchedule(it) }.distinctUntilChanged().debounce(800).collect { s ->
                val dev = _current.value
                val st = dev.status.value
                if (st.link == LinkState.CONNECTED && !syncing && st.scheduleChecksum != s.checksum) push(dev, s)
            }
        }
    }

    // ───────── 연결 ─────────
    fun switchKind(k: DeviceKind) {
        if (repo.deviceKind.value == k && _current.value === pick(k)) return
        val old = _current.value
        scope.launch { runCatching { old.disconnect() } }
        repo.setDeviceKind(k)
        _current.value = pick(k)
    }

    fun connect() = scope.launch {
        _busy.value = true
        try {
            val ok = _current.value.connect()
            if (!ok) _messages.tryEmit(_current.value.status.value.message.ifBlank { "연결에 실패했어요" })
        } finally { _busy.value = false }
    }

    fun disconnect() = scope.launch { _current.value.disconnect() }

    // ───────── 동기화 ─────────
    private suspend fun syncAll(dev: PillBoxDevice) = syncMutex.withLock {
        syncing = true
        try {
            val st = dev.status.value
            // 1) 시계: 휴대폰 시간과 5초 넘게 다르면 맞춤
            val now = LocalDateTime.now()
            val bt = st.boxTime
            if (!st.clockOk || bt == null || abs(Duration.between(bt, now).seconds) > 5) {
                val r = dev.setTime(LocalDateTime.now())
                addLog(if (r.isOk) "약통 시계를 휴대폰 시간에 맞췄어요" else "시계 설정 실패: ${r.errorText}", if (r.isOk) 0 else 2)
            }
            // 2) 연결이 끊긴 동안의 이벤트 기록 가져오기
            var last = repo.data.value.lastDeviceSeq[dev.kindKey] ?: 0
            if (dev.status.value.lastSeq < last) {
                last = 0
                repo.update { it.copy(lastDeviceSeq = it.lastDeviceSeq + (dev.kindKey to 0)) }
                addLog("약통 기록 번호가 초기화되어 처음부터 다시 받아요", 1)
            }
            val evs = dev.fetchLog(last + 1)
            if (evs == null) addLog("기록 동기화 실패", 2)
            else {
                if (evs.isNotEmpty() && evs.first().seq > last + 1 && last > 0) addLog("약통에 남아 있지 않은 오래된 기록 ${evs.first().seq - last - 1}건은 받지 못했어요", 1)
                applyEvents(dev, evs)
                if (evs.isNotEmpty()) addLog("재연결 후 약통 기록 ${evs.count { it.seq > last }}건을 동기화했어요")
            }
            // 3) 일정
            val s = buildSchedule(repo.data.value)
            if (dev.status.value.scheduleChecksum != s.checksum) push(dev, s)
        } finally {
            syncing = false
            val buffered = synchronized(liveBuffer) { liveBuffer.toList().also { liveBuffer.clear() } }
            if (buffered.isNotEmpty()) applyEvents(dev, buffered)
        }
    }

    private suspend fun push(dev: PillBoxDevice, s: BoxSchedule) {
        if (s.entries.size > 24) {
            addLog("일정이 24개를 넘어 약통에 보낼 수 없어요 (${s.entries.size}개)", 2)
            _messages.tryEmit("약통에는 복용 일정을 최대 24개까지 저장할 수 있어요.")
            return
        }
        val r = dev.pushSchedule(s)
        if (r.isOk) addLog("복용 일정 ${s.entries.size}건을 약통에 전송했어요")
        else { addLog("일정 전송 실패: ${r.errorText}", 2); _messages.tryEmit("일정 전송 실패: ${r.errorText}") }
    }

    fun resync() = scope.launch {
        val dev = _current.value
        if (dev.status.value.link != LinkState.CONNECTED) { _messages.tryEmit("약통이 연결되어 있지 않아요"); return@launch }
        syncAll(dev)
        _messages.tryEmit("동기화를 마쳤어요")
    }

    fun syncTimeNow() = scope.launch {
        val r = _current.value.setTime(LocalDateTime.now())
        _messages.tryEmit(if (r.isOk) "약통 시계를 맞췄어요" else r.errorText)
    }

    private fun onLiveEvent(dev: PillBoxDevice, ev: BoxEvent) {
        if (syncing) { synchronized(liveBuffer) { liveBuffer += ev }; return }
        val last = repo.data.value.lastDeviceSeq[dev.kindKey] ?: 0
        if (ev.seq > last + 1 && last > 0) { scope.launch { syncAll(dev) }; return }   // 중간 누락 → 기록 다시 받기
        scope.launch { applyEvents(dev, listOf(ev)) }
    }

    /** 이벤트를 순번으로 중복 제거하고 복용 기록에 반영 */
    private suspend fun applyEvents(dev: PillBoxDevice, evs: List<BoxEvent>) {
        val key = dev.kindKey
        repo.update { d ->
            var last = d.lastDeviceSeq[key] ?: 0
            var records = d.records
            val logs = ArrayList<DeviceLogEntry>()
            for (ev in evs.sortedBy { it.seq }) {
                if (ev.seq <= last) continue
                last = ev.seq
                val at = ev.at ?: LocalDateTime.now()
                logs += DeviceLogEntry(at, ev.text, BoxProtocol.level(ev))
                if (ev.type == BoxProtocol.EV_DOSE_OPEN || ev.type == BoxProtocol.EV_REOPEN) {
                    records = attachOpen(records, ev.arg, at, d.box)
                }
            }
            if (logs.isEmpty()) d
            else d.copy(
                records = records,
                deviceLog = (logs.reversed() + d.deviceLog).take(300),
                lastDeviceSeq = d.lastDeviceSeq + (key to last),
            )
        }
    }

    /** 칸 열림 이벤트를 가장 가까운 복용 회차에 연결 (열림 ≠ 복용) */
    private fun attachOpen(records: List<DoseRecord>, slot: Int, at: LocalDateTime, box: BoxSettings): List<DoseRecord> {
        val windowMin = maxOf(180L, box.graceMin.toLong() + 10)
        val target = records.filter {
            it.slot == slot && it.confirmedAt == null &&
                !it.scheduledAt.isAfter(at.plusMinutes(1)) && it.scheduledAt.isAfter(at.minusMinutes(windowMin))
        }.maxByOrNull { it.scheduledAt } ?: return records
        if (target.openedAt != null) return records
        return records.map { if (it.key == target.key) it.copy(openedAt = at) else it }
    }

    private fun addLog(text: String, level: Int = 0) {
        scope.launch {
            repo.update { it.copy(deviceLog = (listOf(DeviceLogEntry(LocalDateTime.now(), text, level)) + it.deviceLog).take(300)) }
        }
    }

    // ───────── 복용 관련 동작 ─────────
    /** 복용 완료 확인 (앱 화면/알림). 연결되어 있으면 약통에도 알려 같은 회차의 다시 열기를 막는다. */
    suspend fun confirmDose(key: String, at: LocalDateTime, source: String) {
        var slot = -1
        repo.update { d ->
            d.copy(records = d.records.map {
                if (it.key == key && it.confirmedAt == null) { slot = it.slot; it.copy(confirmedAt = at, confirmSource = source) } else it
            })
        }
        Notifier.cancel(ctx, key)
        val dev = _current.value
        if (slot > 0 && dev.status.value.link == LinkState.CONNECTED) {
            val r = dev.markTaken(slot)
            if (!r.isOk && (r as? CmdResult.Err)?.code?.contains("NODOSE") != true) addLog("약통에 복용 완료 전달 실패: ${r.errorText}", 1)
        }
    }

    suspend fun undoConfirm(key: String) {
        repo.update { d -> d.copy(records = d.records.map { if (it.key == key) it.copy(confirmedAt = null, confirmSource = null) else it }) }
    }

    fun reopen(slot: Int) = scope.launch {
        val r = _current.value.reopen(slot)
        _messages.tryEmit(if (r.isOk) "${slot}번 칸을 다시 열었어요" else r.errorText)
    }

    fun refill(slot: Int) = scope.launch {
        val r = _current.value.refill(slot)
        _messages.tryEmit(if (r.isOk) "${slot}번 칸을 보충용으로 열었어요. 3분 뒤 자동으로 닫혀요." else r.errorText)
    }

    fun closeSlot(slot: Int) = scope.launch {
        val r = _current.value.close(slot)
        _messages.tryEmit(if (r.isOk) "${slot}번 칸을 닫아요" else r.errorText)
    }

    fun stopMotors() = scope.launch {
        val r = _current.value.stop()
        _messages.tryEmit(if (r.isOk) "모터를 정지했어요. 기구를 닫힘 위치로 맞춘 뒤 복구를 눌러주세요." else r.errorText)
    }

    fun recover() = scope.launch {
        val r = _current.value.recover()
        _messages.tryEmit(if (r.isOk) "닫힘 위치 복구를 확인했어요" else r.errorText)
    }

    /** 테스트 복용: 1~2분 뒤 회차를 만들어 약통 개방 → 알림 → 복용 확인 흐름을 실제 시간으로 시험 */
    fun createTestDose(medId: String) = scope.launch {
        val d = repo.data.value
        val m = d.meds.firstOrNull { it.id == medId } ?: return@launch
        val now = LocalDateTime.now()
        var t = now.withSecond(0).withNano(0).plusMinutes(1)
        if (Duration.between(now, t).seconds < 40) t = t.plusMinutes(1)
        val rec = DoseRecord(
            key = "test|${UUID.randomUUID()}", medId = m.id, medName = m.name, pills = m.pillsPerDose,
            slot = m.slot, date = t.toLocalDate(), time = t.toLocalTime(), isTest = true,
        )
        repo.update { it.copy(records = it.records + rec) }
        _messages.tryEmit("${t.toLocalTime()}에 ${m.slot}번 칸 테스트 복용이 예약됐어요")
    }

    companion object {
        fun daysMask(days: Set<DayOfWeek>): Int = days.fold(0) { acc, d -> acc or (1 shl (d.value - 1)) }

        /** 앱 데이터 → 약통 일정 */
        fun buildSchedule(d: AppData): BoxSchedule {
            val today = LocalDate.now()
            val set = LinkedHashSet<BoxEntry>()
            for (m in d.meds) {
                val mask = daysMask(m.weekdays)
                if (mask == 0) continue
                for (t in m.times) set += BoxEntry(
                    m.slot, t.hour, t.minute, mask, BoxProtocol.dayNumber(m.startDate),
                    m.endDate?.let { BoxProtocol.dayNumber(it) } ?: 65535,
                )
            }
            for (r in d.records) if (r.isTest && r.date == today) {
                val day = BoxProtocol.dayNumber(today)
                set += BoxEntry(r.slot, r.time.hour, r.time.minute, 127, day, day)
            }
            val sorted = set.sortedWith(compareBy<BoxEntry>({ it.slot }, { it.hour }, { it.minute }, { it.startDay }, { it.endDay }, { it.days }))
            return BoxSchedule(sorted, d.box.holdSec, d.box.graceMin)
        }
    }
}
