package com.yaksok.pillbox.device

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import java.util.UUID
import kotlin.coroutines.resume

/**
 * USB 유선 연결 (휴대폰 USB-C ↔ OTG ↔ 아두이노 UNO USB-B).
 * 정품 UNO(ATmega16U2)와 CH340 호환 보드 모두 지원. 통신 속도 9600bps.
 */
class UsbSerialTransport(context: Context) : LineTransport {
    private val ctx = context.applicationContext
    override val name = "USB"
    override var onLine: ((String) -> Unit)? = null
    override var onClosed: ((Throwable?) -> Unit)? = null

    private var port: UsbSerialPort? = null
    private var io: SerialInputOutputManager? = null
    private val buffer = StringBuilder()
    @Volatile private var closing = false

    override suspend fun open() {
        withContext(Dispatchers.IO) {
            val manager = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
            val driver = UsbSerialProber.getDefaultProber().findAllDrivers(manager).firstOrNull()
                ?: throw IOException("USB로 연결된 약통을 찾지 못했어요. OTG 케이블 연결을 확인하세요.")
            if (!manager.hasPermission(driver.device)) {
                val granted = requestPermission(manager, driver.device)
                if (!granted) throw IOException("USB 사용 권한이 필요해요. 권한 창에서 '허용'을 눌러주세요.")
            }
            val connection = manager.openDevice(driver.device) ?: throw IOException("USB 장치를 열 수 없어요.")
            val p = driver.ports.first()
            p.open(connection)
            p.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            runCatching { p.setDTR(true); p.setRTS(true) }
            synchronized(buffer) { buffer.setLength(0) }
            closing = false
            port = p
            val listener = object : SerialInputOutputManager.Listener {
                override fun onNewData(data: ByteArray) = feed(data)
                override fun onRunError(e: Exception) { if (!closing) onClosed?.invoke(e) }
            }
            val manager2 = SerialInputOutputManager(p, listener)
            io = manager2
            manager2.start()
        }
    }

    private fun feed(data: ByteArray) {
        val lines = ArrayList<String>()
        synchronized(buffer) {
            for (b in data) {
                val c = (b.toInt() and 0xFF).toChar()
                when {
                    c == '\n' -> { lines += buffer.toString(); buffer.setLength(0) }
                    c == '\r' -> Unit
                    buffer.length < 512 -> buffer.append(c)
                    else -> buffer.setLength(0)
                }
            }
        }
        lines.forEach { onLine?.invoke(it) }
    }

    private suspend fun requestPermission(manager: UsbManager, device: UsbDevice): Boolean =
        withTimeoutOrNull(60_000) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val action = ctx.packageName + ".USB_PERMISSION"
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(c: Context, intent: Intent) {
                        if (intent.action != action) return
                        runCatching { ctx.unregisterReceiver(this) }
                        val ok = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                        if (cont.isActive) cont.resume(ok)
                    }
                }
                ContextCompat.registerReceiver(ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
                val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
                val pi = PendingIntent.getBroadcast(ctx, 0, Intent(action).setPackage(ctx.packageName), flags)
                manager.requestPermission(device, pi)
                cont.invokeOnCancellation { runCatching { ctx.unregisterReceiver(receiver) } }
            }
        } ?: false

    override suspend fun close() {
        withContext(Dispatchers.IO) {
            closing = true
            runCatching { io?.stop() }
            io = null
            runCatching { port?.close() }
            port = null
        }
    }

    override suspend fun writeLine(line: String) {
        withContext(Dispatchers.IO) {
            val p = port ?: throw IOException("포트가 열려 있지 않아요")
            p.write((line + "\n").toByteArray(Charsets.US_ASCII), 1000)
        }
    }
}

/**
 * 블루투스 클래식(SPP) 연결 — HC-05 / HC-06 모듈용.
 * 휴대폰 설정에서 모듈과 먼저 페어링(PIN 보통 1234 또는 0000)한 뒤 앱에서 기기를 고른다.
 * 명령 형식은 USB와 같다. (HM-10 같은 BLE 모듈이나 ESP32 BLE는 별도 LineTransport 구현 필요)
 */
@SuppressLint("MissingPermission")
class BluetoothSppTransport(context: Context, private val address: () -> String?) : LineTransport {
    private val ctx = context.applicationContext
    override val name = "블루투스"
    override var onLine: ((String) -> Unit)? = null
    override var onClosed: ((Throwable?) -> Unit)? = null

    private var socket: BluetoothSocket? = null
    private val buffer = StringBuilder()
    @Volatile private var closing = false

    override suspend fun open() {
        withContext(Dispatchers.IO) {
            val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
                ?: throw IOException("이 휴대폰은 블루투스를 지원하지 않아요.")
            if (!hasBtPermission(ctx)) throw IOException("블루투스 권한(근처 기기)을 허용해 주세요.")
            if (!adapter.isEnabled) throw IOException("휴대폰 블루투스를 켜 주세요.")
            val addr = address() ?: throw IOException("약통 블루투스 모듈을 먼저 선택해 주세요.")
            val device = adapter.getRemoteDevice(addr)
            runCatching { adapter.cancelDiscovery() }
            val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
            try { s.connect() } catch (e: IOException) {
                runCatching { s.close() }
                throw IOException("블루투스 연결 실패: 모듈 전원과 페어링을 확인하세요.")
            }
            closing = false
            synchronized(buffer) { buffer.setLength(0) }
            socket = s
            Thread {
                val input = s.inputStream
                val bytes = ByteArray(256)
                try {
                    while (true) {
                        val n = input.read(bytes)
                        if (n < 0) break
                        feed(bytes, n)
                    }
                    if (!closing) onClosed?.invoke(null)
                } catch (e: IOException) {
                    if (!closing) onClosed?.invoke(e)
                }
            }.apply { isDaemon = true; name = "bt-reader" }.start()
        }
    }

    private fun feed(data: ByteArray, n: Int) {
        val lines = ArrayList<String>()
        synchronized(buffer) {
            for (k in 0 until n) {
                val c = (data[k].toInt() and 0xFF).toChar()
                when {
                    c == '\n' -> { lines += buffer.toString(); buffer.setLength(0) }
                    c == '\r' -> Unit
                    buffer.length < 512 -> buffer.append(c)
                    else -> buffer.setLength(0)
                }
            }
        }
        lines.forEach { onLine?.invoke(it) }
    }

    override suspend fun close() {
        withContext(Dispatchers.IO) {
            closing = true
            runCatching { socket?.close() }
            socket = null
        }
    }

    override suspend fun writeLine(line: String) {
        withContext(Dispatchers.IO) {
            val s = socket ?: throw IOException("블루투스가 연결되어 있지 않아요")
            s.outputStream.write((line + "\n").toByteArray(Charsets.US_ASCII))
            s.outputStream.flush()
        }
    }

    companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        fun hasBtPermission(ctx: Context): Boolean =
            Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

        /** 페어링된 기기 목록 (이름, 주소) */
        fun bondedDevices(ctx: Context): List<Pair<String, String>> {
            if (!hasBtPermission(ctx)) return emptyList()
            val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
            return try {
                adapter.bondedDevices.orEmpty().map { (it.name ?: "이름 없음") to it.address }.sortedBy { it.first }
            } catch (e: SecurityException) { emptyList() }
        }
    }
}
