// Pillight ESP32 블루투스 브릿지
// 폰(블루투스 SPP)  <->  ESP32  <->  아두이노 우노(SoftwareSerial A0/A1, 9600)
// 보드: ESP32 Dev Module (ESP32-WROOM-32 / DevKit V1). ESP32-S3·C3는 블루투스 클래식이 없어 안 됩니다.
//
// 배선
//   ESP32 D25 (TX)  ->  우노 A0                      (저항 없이 바로)
//   우노 A1 -> 10kΩ -> [가운데 지점] -> ESP32 D26 (RX)
//                      [가운데 지점] -> 10kΩ -> 10kΩ -> GND   (5V 신호를 3.3V로 낮춤, 필수)
//   ESP32 VIN(5V) <- 우노 5V,   ESP32 GND <-> 우노 GND (반드시 공통 접지)

#include "BluetoothSerial.h"

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error "이 보드는 블루투스 클래식을 지원하지 않습니다. ESP32 Dev Module(WROOM-32)을 쓰세요."
#endif

const char *BT_NAME = "Pillight-Box";   // 폰 블루투스 목록에 보이는 이름
const int UNO_RX_PIN = 26;              // D26: 우노 A1(TX) 신호를 받는 핀 (분압 거친 뒤)
const int UNO_TX_PIN = 25;              // D25: 우노 A0(RX)로 보내는 핀
const int LED_PIN = 2;                  // 보드 파란 LED: 폰 연결되면 켜짐

BluetoothSerial SerialBT;

void setup() {
  Serial.begin(115200);                                        // 디버그용 (USB)
  Serial2.begin(9600, SERIAL_8N1, UNO_RX_PIN, UNO_TX_PIN);    // 우노와 통신
  SerialBT.begin(BT_NAME);                                     // 블루투스 시작
  pinMode(LED_PIN, OUTPUT);
  Serial.println("[Pillight] 블루투스 브릿지 시작: " + String(BT_NAME));
}

void loop() {
  // 폰 -> 우노
  while (SerialBT.available()) {
    int c = SerialBT.read();
    Serial2.write(c);
    Serial.write(c);
  }
  // 우노 -> 폰
  while (Serial2.available()) {
    int c = Serial2.read();
    if (SerialBT.hasClient()) SerialBT.write(c);
    Serial.write(c);
  }
  digitalWrite(LED_PIN, SerialBT.hasClient() ? HIGH : LOW);
}
