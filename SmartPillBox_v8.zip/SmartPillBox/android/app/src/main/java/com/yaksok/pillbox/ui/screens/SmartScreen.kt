package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.Overlay
import com.yaksok.pillbox.data.Period
import com.yaksok.pillbox.data.SettingChange
import com.yaksok.pillbox.domain.Analytics
import com.yaksok.pillbox.domain.Insight
import com.yaksok.pillbox.domain.Suggestion
import com.yaksok.pillbox.domain.SuggestionEngine
import com.yaksok.pillbox.domain.koreanDay
import com.yaksok.pillbox.domain.pct
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BarItem
import com.yaksok.pillbox.ui.components.BarSegment
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.ConfirmDialog
import com.yaksok.pillbox.ui.components.HBar
import com.yaksok.pillbox.ui.components.IconCircle
import com.yaksok.pillbox.ui.components.Legend
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.Segmented
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.components.StackedBarChart
import com.yaksok.pillbox.ui.stamp
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen
import com.yaksok.pillbox.ui.theme.UnconfGray
import kotlin.math.roundToInt

@Composable
fun SmartScreen(vm: AppViewModel, open: (Overlay) -> Unit, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    var span by remember { mutableStateOf(0) }   // 0 = 7일, 1 = 30일
    var reverting by remember { mutableStateOf<SettingChange?>(null) }
    var applying by remember { mutableStateOf<Suggestion?>(null) }

    val a = remember(d.records, now) { Analytics(d.records, now) }
    val suggestions = remember(d, now) { SuggestionEngine.suggestions(d, now) }
    val insights = remember(d, now) { SuggestionEngine.insights(d, now) }
    val days = if (span == 0) 7L else 30L
    val cur = a.summaryLast(7)
    val prev = a.summaryLast(7, endOffset = 7)
    val sum = a.summaryLast(days)
    val periods = a.byPeriod(days)
    val weak = a.weakestPeriod(days)
    val weekdays = a.byWeekday(30)
    val hasData = a.summaryLast(30).total > 0

    Column(modifier.fillMaxSize()) {
    com.yaksok.pillbox.ui.components.TopBar("자세한 분석", onBack)
    LazyColumn(
        Modifier.weight(1f),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text("약 드신 기록을 보고 나에게 맞는 알림을 제안해요", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
        }
        // 이번 주 요약
        item {
            AppCard(color = MintDark) {
                Text("이번 주 잘 드신 비율", style = MaterialTheme.typography.titleMedium, color = Color.White.copy(alpha = 0.85f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(pct(cur.adherence), style = MaterialTheme.typography.headlineLarge, color = Color.White)
                    Spacer(Modifier.width(12.dp))
                    val c = cur.adherence; val p = prev.adherence
                    if (c != null && p != null) {
                        val diff = ((c - p) * 100).roundToInt()
                        val icon = when { diff > 2 -> Icons.AutoMirrored.Filled.TrendingUp; diff < -2 -> Icons.AutoMirrored.Filled.TrendingDown; else -> Icons.AutoMirrored.Filled.TrendingFlat }
                        Icon(icon, null, tint = Color.White)
                        Spacer(Modifier.width(4.dp))
                        Text("지난주 대비 ${if (diff >= 0) "+" else ""}${diff}%p", color = Color.White, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "제때 ${pct(cur.onTimeRate)} · 평균 ${cur.avgDelayMin?.let { "${it.roundToInt()}분" } ?: "-"} 늦음 · 못 드심 ${cur.missedLike}번",
                    style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.9f),
                )
            }
        }
        // 맞춤 알림 제안
        item { SectionTitle("알림 제안", trailing = { if (suggestions.isNotEmpty()) Pill("${suggestions.size}건", Mint, filled = true) }) }
        if (suggestions.isEmpty()) item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle(Icons.Filled.AutoAwesome, Mint)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (hasData) "지금은 바꿀 알림 설정이 없어요. 복용 패턴이 바뀌면 여기서 알려드릴게요."
                        else "복용 기록이 쌓이면 지연·누락 패턴을 분석해 알림 조정을 제안해요.",
                        style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        items(suggestions, key = { it.key }) { s -> SuggestionCard(s, onAccept = { applying = s }, onDismiss = { vm.dismiss(s) }) }
        item {
            Text("※ 제안은 알림 시각·횟수만 바꿔요. 복용 시각, 처방 용량, 약통이 열리는 시각은 바뀌지 않으며 의학적 판단을 대신하지 않습니다.",
                style = MaterialTheme.typography.bodySmall, color = InkSoft)
        }
        // 인사이트
        if (insights.isNotEmpty()) {
            item { SectionTitle("달라진 점") }
            items(insights) { InsightCard(it) }
        }
        // 패턴 분석
        item { SectionTitle("습관 살펴보기") }
        item { Segmented(listOf("최근 7일", "최근 30일"), span, { span = it }) }
        item {
            AppCard {
                Row {
                    Metric("잘 드심", pct(sum.adherence), Modifier.weight(1f))
                    Metric("제때", pct(sum.onTimeRate), Modifier.weight(1f))
                    Metric("평균 늦음", sum.avgDelayMin?.let { "${it.roundToInt()}분" } ?: "-", Modifier.weight(1f))
                }
                if (weak != null) {
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.Lightbulb, LateAmber)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("자주 놓치는 때: ${weak.period.label}", style = MaterialTheme.typography.titleMedium)
                            Text("늦게 ${weak.summary.late}번 · 못 드심 ${weak.summary.missed}번 · 모름 ${weak.summary.unconfirmed}번", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        }
                    }
                }
            }
        }
        item {
            AppCard {
                Text("때별 평균 늦은 시간", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                val maxDelay = periods.maxOfOrNull { it.summary.avgDelayMin ?: 0.0 }?.toFloat()?.coerceAtLeast(10f) ?: 10f
                periods.filter { it.summary.total > 0 }.forEach { ps ->
                    val v = ps.summary.avgDelayMin?.toFloat() ?: 0f
                    HBar(ps.period.label, v, maxDelay, "${v.roundToInt()}분", if (v >= 10f) LateAmber else OkGreen)
                }
                if (periods.none { it.summary.total > 0 }) Text("아직 데이터가 없어요", color = InkSoft)
                Spacer(Modifier.height(12.dp))
                Text("때별 못 드신 횟수", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                val maxMiss = periods.maxOfOrNull { it.summary.missedLike }?.coerceAtLeast(1) ?: 1
                periods.filter { it.summary.total > 0 }.forEach { ps ->
                    HBar(ps.period.label, ps.summary.missedLike.toFloat(), maxMiss.toFloat(), "${ps.summary.missedLike}회 / ${ps.summary.total}", if (ps.summary.missedLike > 0) MissRed else OkGreen)
                }
            }
        }
        item {
            AppCard {
                Text("요일별 늦음·못 드심 (최근 30일)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                val maxW = weekdays.maxOfOrNull { it.late + it.missed }?.coerceAtLeast(1)?.toFloat() ?: 1f
                val worst = weekdays.maxByOrNull { it.late + it.missed * 2 }?.takeIf { it.late + it.missed > 0 }
                StackedBarChart(
                    weekdays.map { w ->
                        BarItem(koreanDay(w.day), listOf(BarSegment(w.late.toFloat(), LateAmber), BarSegment(w.missed.toFloat(), MissRed)), maxW,
                            caption = if (w.late + w.missed > 0) "${w.late + w.missed}" else "", highlight = w == worst)
                    },
                    chartHeight = 130.dp,
                )
                Spacer(Modifier.height(8.dp))
                Legend(listOf("늦게" to LateAmber, "못 드심" to MissRed))
            }
        }
        // 현재 알림 설정
        item { SectionTitle("현재 알림 설정") }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle(Icons.Filled.NotificationsActive, Mint)
                    Spacer(Modifier.width(12.dp))
                    Text(if (d.notif.enabled) "알림 켜짐" else "알림 꺼짐", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { open(Overlay.Settings) }) {
                        Icon(Icons.Filled.Tune, null); Spacer(Modifier.width(4.dp)); Text("직접 조정")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Period.entries.forEach { p ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Text("${p.label} 예비 알림", style = MaterialTheme.typography.bodyLarge, color = InkSoft, modifier = Modifier.weight(1f))
                        Text(if (d.notif.preAlert(p) > 0) "${d.notif.preAlert(p)}분 전" else "없음", style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text("재알림", style = MaterialTheme.typography.bodyLarge, color = InkSoft, modifier = Modifier.weight(1f))
                    Text("${d.notif.reminderIntervalMin}분 간격 · 최대 ${d.notif.maxReminders}회", style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
        // 변경 내역
        item { SectionTitle("알림 설정 변경 내역") }
        if (d.changes.isEmpty()) item { AppCard { Text("아직 변경 내역이 없어요.", color = InkSoft, style = MaterialTheme.typography.bodyLarge) } }
        val latestRevertable = d.changes.lastOrNull { !it.reverted && it.source != "revert" }
        items(d.changes.reversed().take(10), key = { it.id }) { c ->
            AppCard(padding = 16.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle(Icons.Filled.History, if (c.source == "suggestion") Mint else UnconfGray, size = 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.title, style = MaterialTheme.typography.titleSmall)
                        Text(c.detail, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        Text(
                            stamp(c.at, now.toLocalDate()) + " · " + when (c.source) { "suggestion" -> "제안 승인"; "revert" -> "되돌림"; else -> "직접 변경" } +
                                if (c.reverted) " · 취소됨" else "",
                            style = MaterialTheme.typography.bodySmall, color = InkSoft,
                        )
                    }
                    if (c.id == latestRevertable?.id) TextButton(onClick = { reverting = c }) { Text("되돌리기", color = MissRed) }
                }
            }
        }
    }
    }

    applying?.let { s ->
        ConfirmDialog(
            title = "알림 바꾸기", text = "${s.changeSummary}\n\n약 먹는 시각과 약통이 열리는 시각은 그대로예요.",
            confirmText = "바꿀게요", onConfirm = { vm.accept(s) }, onDismiss = { applying = null },
        )
    }
    reverting?.let { c ->
        ConfirmDialog(
            title = "변경 취소", text = "'${c.title}' 적용 이전 설정으로 되돌릴까요?", confirmText = "되돌리기",
            onConfirm = { vm.revert(c) }, onDismiss = { reverting = null }, danger = true,
        )
    }
}

@Composable
private fun SuggestionCard(s: Suggestion, onAccept: () -> Unit, onDismiss: () -> Unit) {
    AppCard(color = MintSoft.copy(alpha = 0.55f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconCircle(Icons.Filled.AutoAwesome, Mint, size = 40.dp)
            Spacer(Modifier.width(10.dp))
            Text(s.title, style = MaterialTheme.typography.titleMedium, color = MintDark)
        }
        Spacer(Modifier.height(10.dp))
        Text(s.message, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        Text("근거: ${s.evidence}", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        Text("변경: ${s.changeSummary}", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftButton("괜찮아요", onClick = onDismiss, modifier = Modifier.weight(1f), color = InkSoft)
            BigButton("바꿀게요", onClick = onAccept, modifier = Modifier.weight(1.4f))
        }
    }
}

@Composable
private fun InsightCard(i: Insight) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconCircle(if (i.positive) Icons.Filled.EmojiEvents else Icons.Filled.Lightbulb, if (i.positive) OkGreen else LateAmber)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(i.title, style = MaterialTheme.typography.titleMedium)
                Text(i.message, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = Mint)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
    }
}
