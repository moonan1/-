package com.yaksok.pillbox.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.FileProvider
import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.FEELINGS
import com.yaksok.pillbox.domain.Analytics
import com.yaksok.pillbox.domain.CheckLogic
import com.yaksok.pillbox.domain.pct
import com.yaksok.pillbox.ui.screens.weekdayText
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDateTime
import kotlin.math.roundToInt

/** 병원 갈 때 보여 줄 '진료 전 요약' 한 장 (최근 30일 복용 + 몸 상태 + 먹는 약) */
object ReportImage {
    private const val W = 1080
    private const val NAVY = 0xFF14213D.toInt()
    private const val AMBER = 0xFFF6B93B.toInt()
    private const val BG = 0xFFF7F5EF.toInt()
    private const val GRAY = 0xFF6B6F7B.toInt()
    private const val RED = 0xFFD64545.toInt()
    private const val LINE = 0xFFE8E4D8.toInt()

    fun build(d: AppData, name: String, now: LocalDateTime): Bitmap {
        val a = Analytics(d.records, now)
        val m = a.summaryLast(30)
        val w = a.summaryLast(7)
        val weak = a.weakestPeriod(30)
        val feel = CheckLogic.counts(d, now, 30)
        val troubles = CheckLogic.troubles(d, now, 30).take(5)
        val meds = d.meds.sortedBy { it.slot }
        val h = 1180 + meds.size * 70 + troubles.size * 56

        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(BG)
        fun paint(size: Float, color: Int, bold: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val card = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE; style = Paint.Style.STROKE; strokeWidth = 3f }
        fun box(top: Float, bottom: Float) {
            val r = RectF(48f, top, W - 48f, bottom)
            c.drawRoundRect(r, 36f, 36f, card); c.drawRoundRect(r, 36f, 36f, border)
        }

        // 머리
        c.drawRect(0f, 0f, W.toFloat(), 230f, Paint().apply { color = NAVY })
        c.drawCircle(96f, 92f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AMBER })
        c.drawText("Pillight 진료 전 요약", 136f, 108f, paint(46f, 0xFFFFFFFF.toInt(), true))
        c.drawText("$name · ${now.toLocalDate()} 기준 최근 30일", 64f, 180f, paint(34f, 0xFFDDE1EA.toInt()))

        // 복용
        var y = 280f
        box(y, y + 300f)
        c.drawText("약을 잘 드셨나요?", 88f, y + 66f, paint(34f, GRAY))
        c.drawText(pct(m.adherence), 88f, y + 176f, paint(110f, NAVY, true))
        c.drawText("30일 동안 잘 드셨어요", 88f + paint(110f, NAVY, true).measureText(pct(m.adherence)) + 24f, y + 168f, paint(38f, NAVY))
        c.drawText("최근 7일 ${pct(w.adherence)} · 늦게 ${m.late}번 · 못 드심 ${m.missedLike}번 · 평균 ${m.avgDelayMin?.roundToInt() ?: 0}분 늦음",
            88f, y + 240f, paint(32f, GRAY))
        if (weak != null) c.drawText("${weak.period.label} 약을 자주 놓치거나 늦게 드셨어요", 88f, y + 282f, paint(32f, RED))
        y += 340f

        // 몸 상태
        val feelH = 190f + troubles.size * 56f
        box(y, y + feelH)
        c.drawText("약 먹은 뒤 몸 상태", 88f, y + 66f, paint(34f, GRAY))
        if (feel.isEmpty()) c.drawText("기록이 없어요", 88f, y + 130f, paint(38f, NAVY))
        else c.drawText(FEELINGS.joinToString("   ") { "$it ${feel[it] ?: 0}번" }, 88f, y + 130f, paint(38f, NAVY, true))
        troubles.forEachIndexed { i, t ->
            c.drawText("· ${t.at.monthValue}/${t.at.dayOfMonth} ${hm(t.at)}  ${t.meds} 먹은 뒤 ${t.feeling}", 88f, y + 190f + i * 56f, paint(32f, RED))
        }
        y += feelH + 40f

        // 먹는 약
        val medH = 120f + meds.size * 70f
        box(y, y + medH)
        c.drawText("지금 먹는 약", 88f, y + 66f, paint(34f, GRAY))
        meds.forEachIndexed { i, med ->
            val ly = y + 130f + i * 70f
            c.drawText("${med.slot}번 칸  ${med.name} ${med.pillsPerDose}정", 88f, ly, paint(36f, NAVY, true))
            val right = med.times.sorted().joinToString(" ") { hm(it) } + " · " + weekdayText(med.weekdays) + if (med.afterMeal) " · 식후" else ""
            val p = paint(30f, GRAY)
            c.drawText(right, W - 88f - p.measureText(right), ly, p)
        }
        y += medH + 40f

        c.drawText("Pillight 스마트 약통 기록 · 의학적 판단은 의사·약사와 상의하세요", 64f, y + 20f, paint(28f, GRAY))
        return bmp
    }

    /** 이미지를 저장하고 공유 창(카카오톡 등)을 연다 */
    fun share(ctx: Context, bmp: Bitmap) {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "pillight_summary.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".share", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Pillight 진료 전 요약이에요.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "요약 보내기").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
