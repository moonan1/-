@file:OptIn(ExperimentalMaterial3Api::class)

package com.yaksok.pillbox.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.DeviceKind
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.device.BoxMode
import com.yaksok.pillbox.device.DeviceStatus
import com.yaksok.pillbox.device.LinkState
import com.yaksok.pillbox.device.SlotPhase
import com.yaksok.pillbox.domain.DoseStatus
import com.yaksok.pillbox.domain.status
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.components.StatusChip
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.untilText
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen
import com.yaksok.pillbox.ui.theme.OpenTeal
import com.yaksok.pillbox.ui.theme.UnconfGray
import com.yaksok.pillbox.ui.theme.statusColor
import java.time.LocalDateTime

/** 칸 하나의 화면 상태 */
data class SlotView(
    val slot: Int,
    val med: Medication?,
    val phase: SlotPhase,          // 약통이 알려준 실제 상태 (연결 안 되면 UNKNOWN)
    val current: DoseRecord?,      // 지금 먹어야 할 회차 (복용 시간 ~ 확인 전)
    val next: DoseRecord?,         // 오늘 다음 회차
    val today: List<DoseRecord>,
) {
    val physicallyOpen get() = phase.isOpenish
    val doneToday get() = today.isNotEmpty() && today.all { it.confirmedAt != null }
}

fun slotViews(d: AppData, st: DeviceStatus, now: LocalDateTime): List<SlotView> {
    val today = now.toLocalDate()
    val connected = st.link == LinkState.CONNECTED
    return (1..6).map { s ->
        val recs = d.records.filter { it.slot == s && it.date == today }.sortedBy { it.time }
        SlotView(
            slot = s,
            med = d.meds.firstOrNull { it.slot == s },
            phase = if (connected) st.slots.getOrElse(s - 1) { SlotPhase.UNKNOWN } else SlotPhase.UNKNOWN,
            current = recs.filter { it.confirmedAt == null && it.status(now).let { x -> x == DoseStatus.DUE || x == DoseStatus.OPENED } }.maxByOrNull { it.scheduledAt },
            next = recs.firstOrNull { it.confirmedAt == null && it.status(now) == DoseStatus.SCHEDULED },
            today = recs,
        )
    }
}

/** 실물 약통처럼 보이는 6칸 */
@Composable
fun PillboxCard(views: List<SlotView>, st: DeviceStatus, kind: DeviceKind, now: LocalDateTime, onSlot: (SlotView) -> Unit, onManage: () -> Unit) {
    val linkColor = when (st.link) { LinkState.CONNECTED -> OkGreen; LinkState.CONNECTING -> LateAmber; LinkState.ERROR -> MissRed; else -> UnconfGray }
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFF8E8), Color(0xFFFBEFD2))))
            .border(1.dp, Color(0xFFF1DFAE), shape)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("내 약통", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Color.White).clickable { onManage() }.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Link, null, tint = linkColor, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (st.link == LinkState.CONNECTED) "연결됨" else "연결하기", color = linkColor, style = MaterialTheme.typography.labelMedium)
                Text("  ›", color = InkSoft, style = MaterialTheme.typography.labelMedium)
            }
        }
        if (st.mode == BoxMode.RECOVERY) {
            Spacer(Modifier.height(8.dp))
            Pill("약통 점검이 필요해요 · 위 연결 상태를 눌러 주세요", MissRed)
        }
        Spacer(Modifier.height(12.dp))
        // 약통 본체
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color.White).padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (row in 0 until 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (col in 0 until 3) {
                        val v = views[row * 3 + col]
                        Compartment(v, now, Modifier.weight(1f)) { onSlot(v) }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            when {
                views.any { it.physicallyOpen } -> "열린 칸을 눌러 지금 드실 약을 확인하세요"
                views.any { it.current != null } -> "반짝이는 칸의 약을 지금 드세요"
                st.link == LinkState.CONNECTED -> "모든 칸이 닫혀 있어요 · 약 먹을 시간에 그 칸만 열려요"
                else -> "칸을 누르면 그 칸의 약과 먹을 시간을 볼 수 있어요"
            },
            style = MaterialTheme.typography.bodyMedium, color = MintDark,
        )
    }
}

@Composable
private fun Compartment(v: SlotView, now: LocalDateTime, modifier: Modifier, onClick: () -> Unit) {
    val active = v.physicallyOpen || v.current != null
    val pulse = if (active) {
        val t = rememberInfiniteTransition(label = "pulse")
        val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
        a
    } else 1f
    val (bg, fg, label) = when {
        v.med == null -> Triple(Color(0xFFF4F6F6), UnconfGray, "비어 있음")
        v.physicallyOpen -> Triple(OpenTeal.copy(alpha = 0.16f), OpenTeal, if (v.phase == SlotPhase.REFILL) "보충 열림" else "열림")
        v.current != null -> Triple(MintSoft, MintDark, "지금 드세요")
        v.doneToday -> Triple(OkGreen.copy(alpha = 0.1f), OkGreen, "오늘 완료")
        v.next != null -> Triple(Color(0xFFF7FAFA), Ink, "다음 ${hm(v.next.time)}")
        else -> Triple(Color(0xFFF7FAFA), InkSoft, "오늘 없음")
    }
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.aspectRatio(0.92f).clip(shape).background(bg)
            .border(if (active) 3.dp else 1.dp, if (active) fg.copy(alpha = pulse) else Line, shape)
            .clickable { onClick() }.padding(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${v.slot}", style = MaterialTheme.typography.headlineSmall, color = fg, modifier = Modifier.weight(1f))
            Icon(if (v.physicallyOpen) Icons.Filled.LockOpen else if (v.doneToday) Icons.Filled.CheckCircle else Icons.Filled.Lock, null,
                tint = fg.copy(alpha = if (v.phase == SlotPhase.UNKNOWN && !v.doneToday) 0.45f else 1f), modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.weight(1f))
        Text(v.med?.name ?: "—", style = MaterialTheme.typography.titleSmall, color = if (v.med == null) UnconfGray else Ink,
            maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
    }
}

/** 칸을 눌렀을 때: 지금 먹어야 할 약 / 다음 복용 / 오늘 일정 */
@Composable
fun CompartmentSheet(
    vm: com.yaksok.pillbox.ui.AppViewModel,
    v: SlotView,
    now: LocalDateTime,
    connected: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (DoseRecord) -> Unit,
    onReopen: (Int) -> Unit,
    onEditMed: (Medication?) -> Unit,
    onPhotoCheck: ((Medication) -> Unit)? = null,
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = Color.White) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(if (v.physicallyOpen) OpenTeal.copy(alpha = 0.15f) else MintSoft), contentAlignment = Alignment.Center) {
                    Text("${v.slot}", style = MaterialTheme.typography.headlineMedium, color = if (v.physicallyOpen) OpenTeal else MintDark)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("${v.slot}번 칸", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    Text(v.med?.name ?: "비어 있는 칸", style = MaterialTheme.typography.headlineSmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (v.physicallyOpen) Icons.Filled.LockOpen else Icons.Filled.Lock, null, tint = if (v.physicallyOpen) OpenTeal else InkSoft)
                    Text(if (!connected) " 연결 안 됨" else if (v.physicallyOpen) " 열림" else " 닫힘", color = if (v.physicallyOpen) OpenTeal else InkSoft, style = MaterialTheme.typography.labelLarge)
                }
            }
            Spacer(Modifier.height(18.dp))
            val med = v.med
            if (med == null) {
                Text("이 칸에는 등록된 약이 없어요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                Spacer(Modifier.height(14.dp))
                BigButton("이 칸에 약 등록하기", onClick = { onEditMed(null) }, icon = Icons.Filled.Edit, modifier = Modifier.fillMaxWidth())
                return@Column
            }
            val cur = v.current
            if (cur != null) {
                val s = cur.status(now)
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MintSoft).padding(18.dp)) {
                    Text("지금 드실 약", style = MaterialTheme.typography.titleMedium, color = MintDark)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(med.name, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                        Text("${cur.pills}정", style = MaterialTheme.typography.headlineMedium, color = MintDark)
                    }
                    Text("먹을 시각 ${hm(cur.time)}" + (cur.openedAt?.let { " · 칸 열림 ${hm(it)}" } ?: "") + if (cur.mealAt != null) " · 밥 먹고 30분 뒤" else "", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    if (med.memo.isNotBlank()) Text("메모: ${med.memo}", style = MaterialTheme.typography.bodyLarge, color = Ink)
                    Spacer(Modifier.height(8.dp))
                    StatusChip(s)
                }
                Spacer(Modifier.height(14.dp))
                BigButton("${cur.pills}정 먹었어요", onClick = { onConfirm(cur); onDismiss() }, icon = Icons.Filled.CheckCircle, modifier = Modifier.fillMaxWidth())
                if (connected && cur.openedAt != null && !v.physicallyOpen) {
                    Spacer(Modifier.height(8.dp))
                    SoftButton("칸이 닫혔어요 · 다시 열기", onClick = { onReopen(v.slot) }, icon = Icons.Filled.Refresh, modifier = Modifier.fillMaxWidth())
                }
            } else {
                val nx = v.next
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFFF5F8F8)).padding(18.dp)) {
                    Text(if (v.doneToday) "오늘 이 칸의 약을 모두 드셨어요" else if (nx != null) "다음 약" else "오늘은 이 칸 약이 없어요",
                        style = MaterialTheme.typography.titleMedium, color = if (v.doneToday) OkGreen else InkSoft)
                    if (nx != null) {
                        Text("${hm(nx.time)} · ${untilText(now, nx.scheduledAt)}", style = MaterialTheme.typography.headlineMedium, color = Ink)
                        Text("${med.name} ${nx.pills}정" + if (med.afterMeal) " · 식후 30분 약" else "", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("이 칸은 약 먹을 시간에만 열려요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("오늘 이 칸", style = MaterialTheme.typography.titleSmall, color = InkSoft)
            Spacer(Modifier.height(6.dp))
            if (v.today.isEmpty()) Text("없음", color = InkSoft, style = MaterialTheme.typography.bodyLarge)
            v.today.forEach { r ->
                val s = r.status(now)
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(hm(r.time), style = MaterialTheme.typography.titleMedium, color = statusColor(s), modifier = Modifier.width(70.dp))
                    Text("${r.pills}정", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    StatusChip(s)
                }
            }
            if (onPhotoCheck != null) {
                Spacer(Modifier.height(16.dp))
                if (med.itemSeq != null) {
                    SoftButton("넣은 약이 맞는지 사진으로 확인", onClick = { onPhotoCheck(med) }, icon = Icons.Filled.CameraAlt, modifier = Modifier.fillMaxWidth())
                    Text("어두운 바탕 위에 약 한 알을 놓고 찍어 주세요.", style = MaterialTheme.typography.bodySmall, color = InkSoft, modifier = Modifier.padding(top = 4.dp))
                } else {
                    Text("사진 확인은 이름으로 검색해서 등록한 약만 할 수 있어요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                }
            }
            Spacer(Modifier.height(18.dp))
            DrugInfoSection(vm, med)
            Spacer(Modifier.height(14.dp))
            SoftButton("약 정보 수정", onClick = { onEditMed(med) }, icon = Icons.Filled.Edit, modifier = Modifier.fillMaxWidth(), color = InkSoft)
            Text("약 먹는 시각과 양은 처방대로 정해 주세요.", style = MaterialTheme.typography.bodySmall, color = InkSoft, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
    }
}
