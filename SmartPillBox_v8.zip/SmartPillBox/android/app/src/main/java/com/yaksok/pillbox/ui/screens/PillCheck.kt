package com.yaksok.pillbox.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.drug.PillLook
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppSheet
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.InfoRow
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.theme.AmberSoft
import com.yaksok.pillbox.ui.theme.Bg
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Navy

/** "넣은 약이 맞나요?" — 찍은 사진과 등록한 약의 색·모양·글자를 나란히 보여 줌 */
@Composable
fun PillCheckSheet(vm: AppViewModel, med: Medication, photo: Bitmap, onRetake: () -> Unit, onDismiss: () -> Unit) {
    val d by vm.data.collectAsStateWithLifecycle()
    val seq = med.itemSeq
    LaunchedEffect(seq) { if (seq != null) vm.ensureDrugInfo(seq, med.name) }
    val info = seq?.let { d.drugInfo[it] }
    val expectColor = info?.let { it.color.ifBlank { PillLook.colorOf(it.chart) } }.orEmpty()
    val expectShape = info?.let { it.shape.ifBlank { PillLook.shapeOf(it.chart) } }.orEmpty()
    val seen = remember(photo) { PillLook.colorOfPhoto(photo) }
    val match = PillLook.similar(expectColor, seen)
    val prints = listOfNotNull(info?.printFront?.ifBlank { null }, info?.printBack?.ifBlank { null }).joinToString(" / ")

    val verdict = when {
        info == null -> null
        seen.isBlank() -> "약을 잘 못 찾았어요. 어두운 바탕 위에 약 한 알을 놓고 가까이 찍어 주세요."
        expectColor.isBlank() -> "등록한 약의 색 정보가 없어요. 아래 사진과 직접 비교해 주세요."
        !match -> "등록한 ${med.name}과(와) 색이 달라 보여요. 다른 약이 섞였을 수 있어요. 약 봉투를 다시 보거나 약사에게 물어보세요."
        else -> "색은 비슷해요." + (if (expectShape.isNotBlank()) " 모양($expectShape)" else "") + (if (prints.isNotBlank()) "과 글자($prints)" else "") + "도 같은지 한 번 더 봐 주세요."
    }
    LaunchedEffect(verdict) { if (verdict != null) vm.speak(verdict) }

    AppSheet(onDismiss) {
        Text("넣은 약이 맞나요?", style = MaterialTheme.typography.headlineSmall)
        Text("${med.slot}번 칸 · ${med.name}", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(photo.asImageBitmap(), null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp)))
                Text("찍은 사진", style = MaterialTheme.typography.labelLarge, color = InkSoft, modifier = Modifier.padding(top = 6.dp))
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Column(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp)).background(Bg), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center) { NetImage(info?.imageUrl ?: med.imageUrl, size = 130.dp) }
                Text("등록한 약", style = MaterialTheme.typography.labelLarge, color = InkSoft, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        if (info == null) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 12.dp)) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Navy, strokeWidth = 2.5.dp)
                Spacer(Modifier.width(10.dp))
                Text("등록한 약 정보를 불러오는 중이에요", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
            }
        } else {
            InfoRow("색", "등록 ${expectColor.ifBlank { "-" }} · 사진 ${seen.ifBlank { "?" }}", valueColor = if (match) Navy else MissRed)
            if (expectShape.isNotBlank()) InfoRow("모양", expectShape)
            if (prints.isNotBlank()) InfoRow("새겨진 글자", prints)
        }
        if (verdict != null) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (match && seen.isNotBlank()) AmberSoft else MissRed.copy(alpha = 0.08f)).padding(14.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Icon(if (match && seen.isNotBlank()) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber, null,
                    tint = if (match && seen.isNotBlank()) Navy else MissRed, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(10.dp))
                Text(verdict, style = MaterialTheme.typography.bodyLarge, color = if (match) Navy else MissRed)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("사진 색은 조명에 따라 달라질 수 있어 참고용이에요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftButton("다시 찍기", onClick = onRetake, icon = Icons.Filled.CameraAlt, modifier = Modifier.weight(1f))
            BigButton("확인했어요", onClick = onDismiss, modifier = Modifier.weight(1f))
        }
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("닫기", color = InkSoft) }
    }
}
