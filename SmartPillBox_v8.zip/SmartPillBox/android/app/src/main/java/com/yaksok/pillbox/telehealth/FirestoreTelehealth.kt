package com.yaksok.pillbox.telehealth

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.util.Log
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.ChatMessage
import com.yaksok.pillbox.data.Doctor
import com.yaksok.pillbox.data.MsgKind
import com.yaksok.pillbox.data.Prescription
import com.yaksok.pillbox.data.RxItem
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.domain.PrescriptionLogic
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Pillight 의료진 웹페이지와 Firestore로 실시간 연결 (로그인 없음, 시연용).
 *
 * 데이터 구조 (웹페이지와 공통 — 바꾸면 웹페이지와 안 맞음)
 *  patients/{환자ID}                 { name, lastText, updatedAt }
 *  patients/{환자ID}/messages/{자동ID} { from: "patient"|"doctor", kind: "text"|"report"|"request"|"prescription",
 *                                      text, payload(map|null), createdAt, status("sent"|"applied"|"declined", 처방만) }
 */
class FirestoreTelehealth(
    context: Context,
    private val data: StateFlow<AppData>,
    private val patientId: () -> String,
    private val patientName: () -> String,
    private val onDoctorMessage: (ChatMessage) -> Unit,
) : TelehealthService {
    private val ctx = context.applicationContext
    override val doctor = Doctor("Pillight 의료진", "실시간 연결", "")
    override val isDemo = false

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    override val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    private val _prescriptions = MutableStateFlow<List<Prescription>>(emptyList())
    override val prescriptions: StateFlow<List<Prescription>> = _prescriptions.asStateFlow()
    private val _status = MutableStateFlow(CareStatus(CareConn.CONNECTING, "의료진 서버에 연결 중…"))
    override val status: StateFlow<CareStatus> = _status.asStateFlow()

    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private var reg: ListenerRegistration? = null
    private var currentId: String? = null
    private var loadedOnce = false
    private val seen = HashSet<String>()
    @Volatile private var online = true
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    private val offlineText = "의료진 서버에 연결할 수 없어요. 인터넷 연결을 확인해 주세요."

    private fun watchNetwork() {
        if (netCallback != null) return
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return
        online = cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { online = true; if (_status.value.conn == CareConn.OFFLINE) _status.value = CareStatus(CareConn.CONNECTING, "다시 연결하는 중…") }
            override fun onLost(network: Network) { online = false; _status.value = CareStatus(CareConn.OFFLINE, offlineText) }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb); netCallback = cb }
        if (!online) _status.value = CareStatus(CareConn.OFFLINE, offlineText)
    }

    override fun start() {
        watchNetwork()
        val id = patientId()
        if (reg != null && id == currentId) return
        stop()
        currentId = id
        if (online) _status.value = CareStatus(CareConn.CONNECTING, "의료진 서버에 연결 중…")
        reg = try {
            db.collection("patients").document(id).collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                    if (err != null) {
                        Log.w("Care", "listen failed", err)
                        _status.value = CareStatus(CareConn.ERROR, offlineText)
                        return@addSnapshotListener
                    }
                    if (snap == null) return@addSnapshotListener
                    val msgs = ArrayList<ChatMessage>()
                    val rxs = ArrayList<Prescription>()
                    for (doc in snap.documents) {
                        val (m, rx) = parse(doc)
                        msgs += m
                        if (rx != null) rxs += rx
                    }
                    if (loadedOnce) msgs.filter { it.fromDoctor && it.id !in seen }.forEach(onDoctorMessage)
                    msgs.forEach { seen += it.id }
                    loadedOnce = true
                    _messages.value = msgs
                    _prescriptions.value = rxs
                    _status.value = when {
                        !online -> CareStatus(CareConn.OFFLINE, offlineText)
                        snap.metadata.isFromCache -> CareStatus(CareConn.CONNECTING, "의료진 서버에 연결 중…")
                        else -> CareStatus(CareConn.ONLINE, "실시간 연결됨")
                    }
                }
        } catch (e: Exception) {
            Log.e("Care", "Firestore 초기화 실패", e)
            _status.value = CareStatus(CareConn.ERROR, offlineText)
            null
        }
    }

    override fun stop() {
        reg?.remove()
        reg = null
        loadedOnce = false
        seen.clear()
        _messages.value = emptyList()
        _prescriptions.value = emptyList()
    }

    // ───────── 보내기 ─────────
    private fun send(kind: String, text: String, payload: Map<String, Any?>?, preview: String) {
        val id = patientId()
        if (!online) _status.value = CareStatus(CareConn.OFFLINE, "$offlineText 연결되면 자동으로 보내져요.")
        try {
            val msg = hashMapOf<String, Any?>(
                "from" to "patient", "kind" to kind, "text" to text, "payload" to payload,
                "createdAt" to FieldValue.serverTimestamp(),
            )
            val patient = db.collection("patients").document(id)
            patient.collection("messages").add(msg)
                .addOnFailureListener { e -> Log.w("Care", "send failed", e); _status.value = CareStatus(CareConn.ERROR, offlineText) }
            patient.set(
                hashMapOf("name" to patientName(), "lastText" to preview, "updatedAt" to FieldValue.serverTimestamp()),
                SetOptions.merge(),
            )
        } catch (e: Exception) {
            Log.e("Care", "send error", e)
            _status.value = CareStatus(CareConn.ERROR, offlineText)
        }
    }

    override fun sendText(text: String) {
        val t = text.trim()
        if (t.isNotEmpty()) send("text", t, null, t.take(60))
    }

    override fun sendReport() {
        val now = LocalDateTime.now()
        send("report", PrescriptionLogic.bodyText(data.value, now), PrescriptionLogic.reportPayload(data.value, now), "복약 리포트")
    }

    override fun requestConsult(symptoms: List<String>, note: String) {
        send("request", "", mapOf("symptoms" to symptoms, "note" to note.trim()), "진료 요청")
    }

    override fun setPrescriptionStatus(rx: Prescription, status: RxStatus) {
        val id = currentId ?: patientId()
        val v = when (status) { RxStatus.APPLIED -> "applied"; RxStatus.DECLINED -> "declined"; RxStatus.NEW -> "sent" }
        runCatching {
            db.collection("patients").document(id).collection("messages").document(rx.id).update("status", v)
                .addOnFailureListener { e -> Log.w("Care", "status update failed", e); _status.value = CareStatus(CareConn.ERROR, offlineText) }
        }
    }

    // ───────── 읽기 ─────────
    private fun parse(doc: DocumentSnapshot): Pair<ChatMessage, Prescription?> {
        val fromDoctor = doc.getString("from") == "doctor"
        val kind = doc.getString("kind") ?: "text"
        val text = doc.getString("text") ?: ""
        val payload = doc.get("payload") as? Map<*, *>
        val ts = doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        val at = ts?.toDate()?.toInstant()?.atZone(ZoneId.systemDefault())?.toLocalDateTime() ?: LocalDateTime.now()
        return when (kind) {
            "report" -> ChatMessage(doc.id, at, fromDoctor, joinText(reportText(payload), text), MsgKind.REPORT) to null
            "request" -> {
                val sym = (payload?.get("symptoms") as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
                val note = payload?.get("note")?.toString().orEmpty()
                ChatMessage(doc.id, at, fromDoctor, joinText(DemoTelehealth.consultText(sym, note).removePrefix("비대면 진료 요청").trim(), text), MsgKind.CONSULT) to null
            }
            "prescription" -> {
                val rx = Prescription(
                    id = doc.id, issuedAt = at, doctor = doctor,
                    items = parseItems(payload?.get("items") as? List<*>),
                    status = when (doc.getString("status")) { "applied" -> RxStatus.APPLIED; "declined" -> RxStatus.DECLINED; else -> RxStatus.NEW },
                )
                ChatMessage(doc.id, at, fromDoctor, text.ifBlank { "처방전을 보냈어요." }, MsgKind.PRESCRIPTION, doc.id) to rx
            }
            else -> ChatMessage(doc.id, at, fromDoctor, text, MsgKind.TEXT) to null
        }
    }

    private fun joinText(a: String, b: String) = listOf(a, b).filter { it.isNotBlank() }.joinToString("\n")

    companion object {
        private fun num(v: Any?): Int? = (v as? Number)?.toInt() ?: v?.toString()?.toIntOrNull()

        fun reportText(p: Map<*, *>?): String {
            if (p == null) return ""
            val lines = ArrayList<String>()
            num(p["adherence7"])?.let { lines += "최근 7일 이행률 $it%" }
            num(p["adherence30"])?.let { lines += "최근 30일 이행률 $it%" }
            num(p["avgDelayMin"])?.let { lines += "평균 복용 지연 ${it}분" }
            num(p["missed"])?.let { lines += "누락 ${it}회" }
            p["weakSlot"]?.toString()?.takeIf { it.isNotBlank() && it != "null" }?.let { lines += "자주 놓치는 시간대: $it" }
            (p["meds"] as? List<*>)?.mapNotNull { it as? Map<*, *> }?.takeIf { it.isNotEmpty() }?.let { meds ->
                lines += "복용 중인 약: " + meds.joinToString(", ") { m ->
                    "${m["name"]} (${num(m["slot"]) ?: "?"}번 칸 ${(m["times"] as? List<*>)?.joinToString(" ").orEmpty()})"
                }
            }
            return lines.joinToString("\n")
        }

        fun parseItems(list: List<*>?): List<RxItem> = list.orEmpty().mapNotNull { it as? Map<*, *> }.mapNotNull { m ->
            val name = m["name"]?.toString()?.trim().orEmpty()
            if (name.isEmpty()) return@mapNotNull null
            val times = (m["times"] as? List<*>).orEmpty().mapNotNull { t -> runCatching { LocalTime.parse(t.toString().trim()) }.getOrNull() }
            val days = (m["days"] as? List<*>).orEmpty().mapNotNull { num(it) }.filter { it in 1..7 }.map { DayOfWeek.of(it) }.toSet()
            RxItem(
                name = name,
                pillsPerDose = (num(m["doseCount"]) ?: 1).coerceIn(1, 10),
                times = times.ifEmpty { listOf(LocalTime.of(8, 0)) },
                weekdays = days.ifEmpty { DayOfWeek.entries.toSet() },
                durationDays = 0,
                note = m["memo"]?.toString()?.takeIf { it != "null" }.orEmpty(),
                slot = num(m["slot"])?.takeIf { it in 1..6 },
                startDate = m["startDate"]?.toString()?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                endDate = m["endDate"]?.toString()?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
            )
        }
    }
}
