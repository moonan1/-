package com.yaksok.pillbox.domain

import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.BodyCheck
import com.yaksok.pillbox.data.DoseRecord
import java.time.LocalDateTime
import java.util.UUID

/** 식후 30분: '밥 먹었어요'를 누르면 식후 약 회차를 30분 뒤로 옮긴다 (약통 일정도 따라감) */
object MealLogic {
    const val AFTER_MEAL_MIN = 30L
    /** 정해진 시각 기준으로 이 범위 안의 회차만 옮김 (2시간 전 ~ 3시간 후) */
    private const val BEFORE_MIN = 120L
    private const val AFTER_MIN = 180L

    fun targets(d: AppData, now: LocalDateTime): List<DoseRecord> {
        val meal = d.meds.filter { it.afterMeal }.mapTo(HashSet()) { it.id }
        if (meal.isEmpty()) return emptyList()
        return d.records.filter {
            !it.isTest && it.medId in meal && it.date == now.toLocalDate() &&
                it.confirmedAt == null && it.openedAt == null && it.mealAt == null &&
                it.scheduledAt.isAfter(now.minusMinutes(BEFORE_MIN)) && it.scheduledAt.isBefore(now.plusMinutes(AFTER_MIN))
        }.sortedBy { it.time }
    }

    fun apply(d: AppData, now: LocalDateTime): AppData {
        val keys = targets(d, now).mapTo(HashSet()) { it.key }
        if (keys.isEmpty()) return d
        val at = now.withSecond(0).withNano(0).plusMinutes(AFTER_MEAL_MIN)
        if (at.toLocalDate() != now.toLocalDate()) return d   // 자정을 넘기면 옮기지 않음
        return d.copy(records = d.records.map { if (it.key in keys) it.copy(time = at.toLocalTime(), mealAt = now) else it })
    }
}

/** 약 먹고 1시간 뒤 '몸은 괜찮으세요?' */
object CheckLogic {
    const val CHECK_AFTER_MIN = 60L
    /** 테스트 복용은 시연용으로 1분 뒤에 물어봄 */
    const val TEST_CHECK_AFTER_MIN = 1L
    private const val ASK_WITHIN_HOURS = 6L

    fun askAt(r: DoseRecord): LocalDateTime? =
        r.confirmedAt?.plusMinutes(if (r.isTest) TEST_CHECK_AFTER_MIN else CHECK_AFTER_MIN)

    /** 지금 물어볼 회차 (먹은 지 1시간 지났고, 아직 답이 없는 것) */
    fun pending(d: AppData, now: LocalDateTime): List<DoseRecord> {
        val answered = d.checks.flatMapTo(HashSet()) { it.doseKeys }
        return d.records.filter { r ->
            val ask = askAt(r) ?: return@filter false
            r.key !in answered && !ask.isAfter(now) && ask.isAfter(now.minusHours(ASK_WITHIN_HOURS))
        }.sortedBy { it.confirmedAt }
    }

    fun answer(d: AppData, keys: List<String>, feeling: String, now: LocalDateTime): AppData {
        val recs = d.records.filter { it.key in keys }
        if (recs.isEmpty()) return d
        val c = BodyCheck(UUID.randomUUID().toString(), now, recs.map { it.key }, recs.joinToString(", ") { it.medName }, feeling)
        return d.copy(checks = (d.checks + c).takeLast(300))
    }

    /** 최근 n일 답 개수 (괜찮아요 / 어지러워요 / 속이 불편해요) */
    fun counts(d: AppData, now: LocalDateTime, days: Long): Map<String, Int> =
        d.checks.filter { it.at.isAfter(now.minusDays(days)) }.groupingBy { it.feeling }.eachCount()

    /** 불편했던 기록만 (최근 것부터) */
    fun troubles(d: AppData, now: LocalDateTime, days: Long): List<BodyCheck> =
        d.checks.filter { it.at.isAfter(now.minusDays(days)) && it.feeling != "괜찮아요" }.sortedByDescending { it.at }
}
