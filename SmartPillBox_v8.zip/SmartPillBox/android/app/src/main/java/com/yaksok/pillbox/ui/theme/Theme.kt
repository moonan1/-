package com.yaksok.pillbox.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yaksok.pillbox.domain.DoseStatus

// Pillight 브랜드: 남색 + 호박색(빛)
val Navy = Color(0xFF14213D)
val NavyDeep = Color(0xFF0C1528)
val Amber = Color(0xFFF6B93B)
val AmberSoft = Color(0xFFFDF1D6)

// 기존 화면 코드가 쓰는 이름을 브랜드 색에 연결
val Mint = Navy                      // 주요 버튼·강조
val MintDark = Navy                  // 밝은 배경 위 강조 글자
val MintSoft = Color(0xFFECEEF4)     // 남색 계열 옅은 배경
val MintFaint = Color(0xFFFBFAF6)
val Bg = Color(0xFFF7F5EF)
val Ink = Color(0xFF14213D)
val InkSoft = Color(0xFF6B6F7B)
val Line = Color(0xFFE8E4D8)

// 색은 3가지만: 남색(기본) · 앰버(강조) · 빨강(경고). 나머지는 회색 계열.
val OkGreen = Navy                  // '먹었어요'도 기본색(남색)으로
val LateAmber = Color(0xFFD9901A)   // 강조 (글자용으로 조금 진한 앰버)
val MissRed = Color(0xFFD64545)
val UnconfGray = Color(0xFF8B90A6)
val PlanBlue = Color(0xFF6B6F7B)
val OpenTeal = Color(0xFFD9901A)   // 열린 칸 = 빛(호박색)

fun statusColor(s: DoseStatus): Color = when (s) {
    DoseStatus.SCHEDULED -> PlanBlue
    DoseStatus.DUE -> Mint
    DoseStatus.OPENED -> OpenTeal
    DoseStatus.TAKEN -> OkGreen
    DoseStatus.LATE -> LateAmber
    DoseStatus.MISSED -> MissRed
    DoseStatus.UNCONFIRMED -> UnconfGray
}

private val colors = lightColorScheme(
    primary = Mint,
    onPrimary = Color.White,
    primaryContainer = MintSoft,
    onPrimaryContainer = MintDark,
    secondary = Amber,
    onSecondary = Navy,
    secondaryContainer = AmberSoft,
    onSecondaryContainer = Navy,
    background = Bg,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = MintFaint,
    onSurfaceVariant = InkSoft,
    outline = Line,
    outlineVariant = Line,
    error = MissRed,
    surfaceContainer = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainerHigh = Color.White,
    surfaceContainerHighest = MintFaint,
)

// 고령자도 읽기 쉽게 기본보다 큰 글자
private val type = Typography(
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, lineHeight = 40.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 35.sp, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.Bold, lineHeight = 31.sp),
    titleLarge = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp),
    titleMedium = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.SemiBold, lineHeight = 26.sp),
    titleSmall = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontSize = 18.sp, lineHeight = 27.sp),
    bodyMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodySmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
)

private val shapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun YaksokTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = type, shapes = shapes, content = content)
}
