package com.yaksok.pillbox.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** 소리로 읽어 주기 (휴대폰에 깔린 한국어 음성 사용) */
class Speaker(context: Context) {
    private var ready = false
    private var pending: String? = null
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.KOREAN
                tts.setSpeechRate(0.9f)
                ready = true
                pending?.let { say(it) }
                pending = null
            }
        }
    }

    fun say(text: String) {
        if (!ready) { pending = text; return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pillight")
    }

    fun shutdown() = runCatching { tts.stop(); tts.shutdown() }
}
