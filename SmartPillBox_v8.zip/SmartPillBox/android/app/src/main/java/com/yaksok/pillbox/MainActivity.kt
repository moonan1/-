@file:OptIn(ExperimentalMaterial3Api::class)

package com.yaksok.pillbox

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.screens.AllScreen
import com.yaksok.pillbox.ui.screens.CareTab
import com.yaksok.pillbox.ui.screens.DemoModeScreen
import com.yaksok.pillbox.ui.screens.DeviceScreen
import com.yaksok.pillbox.ui.screens.MedEditScreen
import com.yaksok.pillbox.ui.screens.MedsScreen
import com.yaksok.pillbox.ui.screens.RecordScreen
import com.yaksok.pillbox.ui.screens.SettingsScreen
import com.yaksok.pillbox.ui.screens.SmartScreen
import com.yaksok.pillbox.ui.screens.TodayScreen
import com.yaksok.pillbox.ui.theme.Amber
import com.yaksok.pillbox.ui.theme.AmberSoft
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Navy
import com.yaksok.pillbox.ui.theme.YaksokTheme

/** 하단 탭 위에 겹쳐 열리는 화면 */
sealed class Overlay {
    data object Device : Overlay()
    data object Settings : Overlay()
    data object Meds : Overlay()
    data object Analysis : Overlay()
    data object Demo : Overlay()
    data class EditMed(val medId: String?, val slot: Int? = null) : Overlay()
}

/** 하단 탭: 오늘 / 기록 / 의료진 / 전체 */
object Tabs { const val TODAY = 0; const val RECORD = 1; const val CARE = 2; const val ALL = 3 }

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    /** 알림에서 '의료진 메시지'를 눌러 들어오면 의료진 탭을 연다 */
    private val openCare = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (intent?.getBooleanExtra("openCare", false) == true) openCare.intValue++
        setContent {
            val big by vm.bigText.collectAsStateWithLifecycle()
            val base = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(base.density, base.fontScale * if (big) 1.18f else 1f)) {
                YaksokTheme { AppRoot(vm, openCare.intValue) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("openCare", false)) openCare.intValue++
    }

    override fun onResume() {
        super.onResume()
        vm.refreshNow()
    }
}

@Composable
fun AppRoot(vm: AppViewModel, openCareSignal: Int = 0) {
    var tab by rememberSaveable { mutableStateOf(Tabs.TODAY) }
    val overlays = remember { mutableStateListOf<Overlay>() }
    val snackbar = remember { SnackbarHostState() }
    val open: (Overlay) -> Unit = { overlays.add(it) }
    val close: () -> Unit = { if (overlays.isNotEmpty()) overlays.removeAt(overlays.lastIndex) }
    val goTab: (Int) -> Unit = { overlays.clear(); tab = it }
    val tele by vm.care.collectAsStateWithLifecycle()
    val rxList by tele.prescriptions.collectAsStateWithLifecycle()
    val newRx = rxList.count { it.status == RxStatus.NEW }

    // 알림 권한 (Android 13+)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    LaunchedEffect(openCareSignal) { if (openCareSignal > 0) goTab(Tabs.CARE) }

    BackHandler(enabled = overlays.isNotEmpty() || tab != Tabs.TODAY) {
        if (overlays.isNotEmpty()) close() else tab = Tabs.TODAY
    }

    val top = overlays.lastOrNull()
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (top == null) {
                NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                    val items = listOf(
                        Triple("오늘", Icons.Filled.WbSunny, Tabs.TODAY),
                        Triple("기록", Icons.Filled.CalendarMonth, Tabs.RECORD),
                        Triple("의료진", Icons.Filled.MedicalServices, Tabs.CARE),
                        Triple("전체", Icons.Filled.Menu, Tabs.ALL),
                    )
                    items.forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {
                                if (i == Tabs.CARE && newRx > 0) {
                                    BadgedBox(badge = { Badge(containerColor = MissRed) { Text("$newRx") } }) {
                                        Icon(icon, null, modifier = Modifier.size(28.dp))
                                    }
                                } else Icon(icon, null, modifier = Modifier.size(28.dp))
                            },
                            label = { Text(label, style = MaterialTheme.typography.labelLarge) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Navy, selectedTextColor = Navy, indicatorColor = AmberSoft,
                                unselectedIconColor = InkSoft, unselectedTextColor = InkSoft,
                            ),
                        )
                    }
                }
            }
        },
    ) { inner ->
        val mod = Modifier.padding(inner)
        when (val o = top) {
            is Overlay.Device -> DeviceScreen(vm, onBack = close, modifier = mod)
            is Overlay.Settings -> SettingsScreen(vm, onBack = close, modifier = mod)
            is Overlay.Meds -> MedsScreen(vm, open, onBack = close, modifier = mod)
            is Overlay.Analysis -> SmartScreen(vm, open, onBack = close, modifier = mod)
            is Overlay.Demo -> DemoModeScreen(vm, open, onBack = close, modifier = mod)
            is Overlay.EditMed -> MedEditScreen(vm, o.medId, o.slot, onBack = close, modifier = mod)
            null -> when (tab) {
                Tabs.TODAY -> TodayScreen(vm, open, goTab, mod)
                Tabs.RECORD -> RecordScreen(vm, open, mod)
                Tabs.CARE -> CareTab(vm, mod)
                else -> AllScreen(vm, open, mod)
            }
        }
    }
}
