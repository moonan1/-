package com.yaksok.pillbox.drug

import android.graphics.Bitmap
import android.graphics.Color

/**
 * 약 생김새 비교 (참고용).
 * - 등록한 약의 색·모양은 식약처 낱알식별 정보(없으면 성상 글)에서 가져온다.
 * - 사진의 색은 가운데 부분에서 '약처럼 보이는' 픽셀만 골라 대표 색을 정한다.
 * 정확한 판별이 아니라 "다시 확인해 보세요"를 알려 주는 용도다.
 */
object PillLook {
    /** 식약처 색 이름 그룹 (COLOR_CLASS1 값과 같은 말) */
    val COLORS = listOf("하양", "노랑", "주황", "분홍", "빨강", "갈색", "연두", "초록", "청록", "파랑", "남색", "자주", "보라", "회색", "검정", "투명")

    private val colorWords = listOf(
        "하양" to listOf("흰색", "백색", "하양", "흰"),
        "노랑" to listOf("노란", "노랑", "황색", "담황", "미황"),
        "주황" to listOf("주황", "등색", "오렌지"),
        "분홍" to listOf("분홍", "담홍", "연분홍", "핑크"),
        "빨강" to listOf("빨간", "빨강", "적색", "붉은"),
        "갈색" to listOf("갈색", "황갈", "적갈", "다갈"),
        "연두" to listOf("연두", "황록"),
        "초록" to listOf("초록", "녹색", "청록색"),
        "파랑" to listOf("파란", "파랑", "청색", "하늘"),
        "남색" to listOf("남색"),
        "보라" to listOf("보라", "자색", "자주"),
        "회색" to listOf("회색"),
        "검정" to listOf("검정", "흑색", "검은"),
        "투명" to listOf("투명"),
    )

    /** 성상 글("흰색의 원형 필름코팅정")에서 색 이름 */
    fun colorOf(chart: String): String {
        if (chart.isBlank()) return ""
        // 가장 먼저 나오는 색 단어
        return colorWords.mapNotNull { (name, ws) -> ws.mapNotNull { w -> chart.indexOf(w).takeIf { it >= 0 } }.minOrNull()?.let { name to it } }
            .minByOrNull { it.second }?.first ?: ""
    }

    fun shapeOf(chart: String): String = listOf("장방형", "타원형", "원형", "삼각형", "사각형", "마름모형", "오각형", "육각형", "팔각형", "캡슐", "반원형")
        .firstOrNull { chart.contains(it) }?.let { if (it == "캡슐") "캡슐형" else it } ?: ""

    /** 비슷한 색끼리 묶음 (사진은 조명에 따라 조금씩 달라 보임) */
    private val near = mapOf(
        "하양" to setOf("하양", "회색", "투명", "노랑"),
        "노랑" to setOf("노랑", "주황", "하양", "연두"),
        "주황" to setOf("주황", "노랑", "빨강", "갈색", "분홍"),
        "분홍" to setOf("분홍", "빨강", "주황", "보라", "자주", "하양"),
        "빨강" to setOf("빨강", "분홍", "주황", "갈색", "자주"),
        "갈색" to setOf("갈색", "주황", "빨강", "검정"),
        "연두" to setOf("연두", "초록", "노랑"),
        "초록" to setOf("초록", "연두", "청록"),
        "청록" to setOf("청록", "초록", "파랑"),
        "파랑" to setOf("파랑", "청록", "남색", "보라"),
        "남색" to setOf("남색", "파랑", "보라", "검정"),
        "자주" to setOf("자주", "보라", "분홍", "빨강"),
        "보라" to setOf("보라", "자주", "남색", "분홍", "파랑"),
        "회색" to setOf("회색", "하양", "검정"),
        "검정" to setOf("검정", "회색", "남색", "갈색"),
        "투명" to COLORS.toSet(),
    )

    fun similar(expected: String, seen: String): Boolean {
        if (expected.isBlank() || seen.isBlank()) return true
        val e = COLORS.firstOrNull { expected.contains(it) } ?: return true
        return seen in (near[e] ?: setOf(e))
    }

    /** HSV → 색 이름 */
    fun nameOf(h: Float, s: Float, v: Float): String = when {
        v < 0.18f -> "검정"
        s < 0.12f && v > 0.75f -> "하양"
        s < 0.15f -> "회색"
        (h < 20f || h >= 345f) && v < 0.55f -> "갈색"
        h in 20f..45f && v < 0.6f -> "갈색"
        (h < 12f || h >= 345f) && s < 0.45f -> "분홍"
        h < 12f || h >= 345f -> "빨강"
        h < 40f -> "주황"
        h < 68f -> "노랑"
        h < 95f -> "연두"
        h < 160f -> "초록"
        h < 195f -> "청록"
        h < 235f -> if (v < 0.45f) "남색" else "파랑"
        h < 290f -> "보라"
        else -> if (s < 0.5f) "분홍" else "자주"
    }

    /**
     * 사진 대표 색. 가운데 60% 영역에서 바깥 테두리 색(배경)과 많이 다른 픽셀만 모아 평균을 낸다.
     * 약이 흰색이고 배경도 밝으면 구분이 어려우니, 어두운 바탕 위에 놓고 찍도록 안내한다.
     */
    fun colorOfPhoto(bmp: Bitmap): String {
        val w = bmp.width; val h = bmp.height
        if (w < 8 || h < 8) return ""
        fun px(x: Int, y: Int) = bmp.getPixel(x.coerceIn(0, w - 1), y.coerceIn(0, h - 1))
        // 배경: 테두리 평균
        var br = 0L; var bg = 0L; var bb = 0L; var bn = 0
        for (i in 0 until 40) {
            val t = i / 40f
            listOf(px((w * t).toInt(), 2), px((w * t).toInt(), h - 3), px(2, (h * t).toInt()), px(w - 3, (h * t).toInt())).forEach {
                br += Color.red(it); bg += Color.green(it); bb += Color.blue(it); bn++
            }
        }
        val back = Triple(br / bn, bg / bn, bb / bn)
        var r = 0L; var g = 0L; var b = 0L; var n = 0
        val step = maxOf(1, minOf(w, h) / 80)
        var y = (h * 0.2f).toInt()
        while (y < h * 0.8f) {
            var x = (w * 0.2f).toInt()
            while (x < w * 0.8f) {
                val c = bmp.getPixel(x, y)
                val d = Math.abs(Color.red(c) - back.first) + Math.abs(Color.green(c) - back.second) + Math.abs(Color.blue(c) - back.third)
                if (d > 90) { r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++ }
                x += step
            }
            y += step
        }
        if (n < 20) return ""   // 약을 못 찾음
        val hsv = FloatArray(3)
        Color.RGBToHSV((r / n).toInt(), (g / n).toInt(), (b / n).toInt(), hsv)
        return nameOf(hsv[0], hsv[1], hsv[2])
    }
}
