package com.yaksok.pillbox.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Restaurant
import com.yaksok.pillbox.data.FEELINGS
import com.yaksok.pillbox.data.Medication
import com.yaksok.pillbox.domain.CheckLogic
import com.yaksok.pillbox.domain.MealLogic
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.Overlay
import com.yaksok.pillbox.Tabs
import com.yaksok.pillbox.data.DataMode
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.device.LinkState
import com.yaksok.pillbox.device.SlotPhase
import com.yaksok.pillbox.domain.DoseStatus
import com.yaksok.pillbox.domain.status
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.EmptyState
import com.yaksok.pillbox.ui.components.IconCircle
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.PillightLogo
import com.yaksok.pillbox.ui.components.ProgressBar
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.SlotBadge
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.dateLong
import com.yaksok.pillbox.ui.hourText
import com.yaksok.pillbox.ui.theme.Amber
import com.yaksok.pillbox.ui.theme.AmberSoft
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Navy
import com.yaksok.pillbox.ui.untilText
import java.time.LocalDateTime

/** 오늘 탭: 지금 먹을 약 → 오늘 진행 → 내 약통 → 오늘 드실 약 */
@Composable
fun TodayScreen(vm: AppViewModel, open: (Overlay) -> Unit, goTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val st by vm.deviceStatus.collectAsStateWithLifecycle()
    val kind by vm.deviceKind.collectAsStateWithLifecycle()
    val tele by vm.care.collectAsStateWithLifecycle()
    val rxList by tele.prescriptions.collectAsStateWithLifecycle()
    val newRx = rxList.count { it.status == RxStatus.NEW }

    val today = now.toLocalDate()
    val todays = d.records.filter { it.date == today }.sortedBy { it.time }
    val due = todays.filter { it.confirmedAt == null && it.status(now).let { s -> s == DoseStatus.DUE || s == DoseStatus.OPENED } }
    val next = todays.firstOrNull { it.confirmedAt == null && it.status(now) == DoseStatus.SCHEDULED }
    val done = todays.count { it.confirmedAt != null }
    val missed = todays.count { it.status(now) == DoseStatus.MISSED || it.status(now) == DoseStatus.UNCONFIRMED }
    val views = slotViews(d, st, now)

    var detail by remember { mutableStateOf<DoseRecord?>(null) }
    var timeChoice by remember { mutableStateOf<DoseRecord?>(null) }
    var sheetSlot by remember { mutableStateOf<Int?>(null) }
    // 사진으로 약 확인
    var photoMed by remember { mutableStateOf<Medication?>(null) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) photo = bmp else if (photo == null) photoMed = null
    }
    val takePhoto: (Medication) -> Unit = { m -> photoMed = m; photo = null; runCatching { camera.launch(null) }.onFailure { photoMed = null } }
    val mealTargets = MealLogic.targets(d, now)
    val checks = CheckLogic.pending(d, now)
    val confirm: (DoseRecord) -> Unit = { r -> if (needsTimeChoice(r, now)) timeChoice = r else vm.confirm(r.key) }

    // 약 먹을 시간이 되면 한 번 소리로 알려 줌
    val dueKeys = due.map { it.key }.toSet()
    LaunchedEffect(dueKeys) {
        if (due.isNotEmpty() && dueKeys != vm.spokenDue) { vm.spokenDue = dueKeys; vm.speak(dueSpeech(due)) }
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    PillightLogo(markSize = 24.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(dateLong(today), style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    Text("${vm.patientName}님, 안녕하세요", style = MaterialTheme.typography.headlineMedium)
                }
                if (mode == DataMode.DEMO) Pill("시연 모드", LateAmber, filled = true, modifier = Modifier.clickable { open(Overlay.Demo) })
            }
        }
        if (newRx > 0) item {
            AppCard(color = AmberSoft, onClick = { goTab(Tabs.CARE) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle(Icons.Filled.Description, Navy)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("의료진이 새 처방을 보냈어요", style = MaterialTheme.typography.titleMedium)
                        Text("눌러서 확인해 주세요", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    }
                }
            }
        }
        if (checks.isNotEmpty()) item {
            CheckCard(checks, onAnswer = { f -> vm.answerCheck(checks.map { it.key }, f) }, onOther = { goTab(Tabs.CARE) })
        }
        item {
            NowCard(
                due = due, next = next, now = now,
                hasAny = todays.isNotEmpty(),
                canReopen = { r -> st.link == LinkState.CONNECTED && r.openedAt != null && st.slots.getOrNull(r.slot - 1) == SlotPhase.CLOSED },
                onTaken = { list -> if (list.size == 1) confirm(list.first()) else list.forEach { vm.confirm(it.key) } },
                onReopen = { vm.devices.reopen(it.slot) },
                onSpeak = { vm.speak(if (due.isNotEmpty()) dueSpeech(due) else nextSpeech(next, now)) },
                onAdd = { open(Overlay.EditMed(null)) },
            )
        }
        if (mealTargets.isNotEmpty() && due.isEmpty()) item {
            AppCard(color = AmberSoft, padding = 22.dp) {
                Text("밥 드셨어요?", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(6.dp))
                Text(mealTargets.joinToString(", ") { "${it.slot}번 칸 ${it.medName}" } + "은(는) 식후 30분 약이에요. 밥 다 드시고 누르면 30분 뒤에 칸이 열려요.",
                    style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(14.dp))
                BigButton("밥 먹었어요", onClick = { vm.mealDone() }, icon = Icons.Filled.Restaurant, modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp))
            }
        }
        if (todays.isNotEmpty()) item {
            AppCard {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("오늘 ${todays.size}번 중 ", style = MaterialTheme.typography.titleMedium)
                    Text("${done}번", style = MaterialTheme.typography.headlineSmall, color = Navy)
                    Text(" 드셨어요", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(12.dp))
                ProgressBar(if (todays.isEmpty()) 0f else done.toFloat() / todays.size, height = 16.dp, color = Navy)
                if (missed > 0) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.WarningAmber, null, tint = MissRed, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("오늘 못 드신 약이 ${missed}번 있어요", style = MaterialTheme.typography.bodyLarge, color = MissRed)
                    }
                }
            }
        }
        item { PillboxCard(views, st, kind, now, onSlot = { sheetSlot = it.slot }, onManage = { open(Overlay.Device) }) }
        item { SectionTitle("오늘 드실 약") }
        if (todays.isEmpty()) item {
            AppCard { EmptyState(Icons.Filled.Medication, "오늘 드실 약이 없어요", "약을 등록하면 여기에 나와요.") }
        }
        items(todays, key = { it.key }) { r -> DoseRow(r, now, onConfirm = { confirm(r) }, onClick = { detail = r }) }
    }

    detail?.let { r0 ->
        val r = d.records.firstOrNull { it.key == r0.key } ?: r0
        DoseDetailDialog(r, now, onConfirm = { confirm(r) }, onUndo = { vm.undoConfirm(r.key) }, onDismiss = { detail = null })
    }
    timeChoice?.let { r -> ConfirmTimeDialog(r, now, onPick = { vm.confirm(r.key, it) }, onDismiss = { timeChoice = null }) }
    sheetSlot?.let { s ->
        CompartmentSheet(
            vm, views[s - 1], now, connected = st.link == LinkState.CONNECTED, onDismiss = { sheetSlot = null },
            onConfirm = { confirm(it) },
            onReopen = { vm.devices.reopen(it) },
            onEditMed = { m -> sheetSlot = null; open(Overlay.EditMed(m?.id, s)) },
            onPhotoCheck = { m -> sheetSlot = null; takePhoto(m) },
        )
    }
    val pm = photoMed; val ph = photo
    if (pm != null && ph != null) PillCheckSheet(vm, pm, ph, onRetake = { takePhoto(pm) }, onDismiss = { photoMed = null; photo = null })
}

/** 먹고 1시간 뒤: 몸은 괜찮으세요? */
@Composable
private fun CheckCard(recs: List<DoseRecord>, onAnswer: (String) -> Unit, onOther: () -> Unit) {
    AppCard(padding = 22.dp) {
        Text("몸은 괜찮으세요?", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text(recs.map { it.medName }.distinct().joinToString(", ") + "을(를) 드신 지 조금 지났어요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
        Spacer(Modifier.height(14.dp))
        BigButton(FEELINGS[0], onClick = { onAnswer(FEELINGS[0]) }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FEELINGS.drop(1).forEach { f -> SoftButton(f, onClick = { onAnswer(f) }, color = MissRed, modifier = Modifier.weight(1f)) }
        }
        TextButton(onClick = onOther, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
            Text("다른 곳이 불편해요 · 의료진에게 말하기", style = MaterialTheme.typography.labelLarge, color = InkSoft)
        }
    }
}

private fun dueSpeech(due: List<DoseRecord>): String =
    "약 드실 시간이에요. " + due.joinToString(". ") { "${it.slot}번 칸, ${it.medName} ${it.pills}정" } + ". 드신 뒤 먹었어요 버튼을 눌러 주세요."

private fun nextSpeech(next: DoseRecord?, now: LocalDateTime): String =
    if (next == null) "오늘 남은 약이 없어요."
    else "다음 약은 ${hourText(next.time)}, ${next.slot}번 칸 ${next.medName} ${next.pills}정이에요. ${untilText(now, next.scheduledAt)}에 알려 드릴게요."

/** 맨 위 큰 카드: 지금 먹을 약 + [먹었어요] / 없으면 "다음 약은 ○시예요" */
@Composable
private fun NowCard(
    due: List<DoseRecord>,
    next: DoseRecord?,
    now: LocalDateTime,
    hasAny: Boolean,
    canReopen: (DoseRecord) -> Boolean,
    onTaken: (List<DoseRecord>) -> Unit,
    onReopen: (DoseRecord) -> Unit,
    onSpeak: () -> Unit,
    onAdd: () -> Unit,
) {
    if (due.isNotEmpty()) {
        AppCard(color = Navy, padding = 22.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("지금 드실 약", style = MaterialTheme.typography.titleLarge, color = Amber, modifier = Modifier.weight(1f))
                SpeakButton(onSpeak, onDark = true)
            }
            Spacer(Modifier.height(10.dp))
            due.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    SlotBadge(r.slot, size = 64.dp, color = Amber)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.medName, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("${r.pills}정 · ${hourText(r.time)}" + if (r.openedAt != null) " · 칸이 열렸어요" else "",
                            style = MaterialTheme.typography.bodyLarge, color = Color.White.copy(alpha = 0.85f))
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            BigButton(
                if (due.size == 1) "먹었어요" else "모두 먹었어요", onClick = { onTaken(due) }, icon = Icons.Filled.CheckCircle,
                color = Amber, contentColor = Navy, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp),
            )
            due.filter(canReopen).forEach { r ->
                Spacer(Modifier.height(8.dp))
                SoftButton("${r.slot}번 칸 다시 열기", onClick = { onReopen(r) }, icon = Icons.Filled.Refresh, color = Color.White, modifier = Modifier.fillMaxWidth())
            }
        }
        return
    }
    AppCard(padding = 22.dp) {
        when {
            next != null -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(untilText(now, next.scheduledAt), style = MaterialTheme.typography.titleMedium, color = InkSoft, modifier = Modifier.weight(1f))
                    SpeakButton(onSpeak)
                }
                Text("다음 약은 ${hourText(next.time)}예요", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(AmberSoft).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SlotBadge(next.slot, size = 56.dp, color = Navy)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(next.medName, style = MaterialTheme.typography.titleLarge)
                        Text("${next.pills}정 · " + if (next.mealAt != null) "밥 드신 뒤 30분이에요" else "그때 약통 칸이 열려요", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    }
                }
            }
            hasAny -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle(Icons.Filled.CheckCircle, Navy, size = 56.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("오늘 약은 다 끝났어요", style = MaterialTheme.typography.headlineSmall)
                        Text("수고하셨어요. 내일도 시간 맞춰 알려 드릴게요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    }
                }
            }
            else -> {
                Text("오늘 드실 약이 없어요", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(4.dp))
                Text("약을 등록하면 시간에 맞춰 알려 드리고 약통 칸을 열어 드려요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                Spacer(Modifier.height(14.dp))
                BigButton("약 등록하기", onClick = onAdd, icon = Icons.Filled.Add, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun SpeakButton(onClick: () -> Unit, onDark: Boolean = false) {
    TextButton(onClick = onClick, modifier = Modifier.heightIn(min = 48.dp)) {
        Icon(Icons.AutoMirrored.Filled.VolumeUp, null, tint = if (onDark) Color.White else Navy, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(4.dp))
        Text("소리로 듣기", style = MaterialTheme.typography.labelLarge, color = if (onDark) Color.White else Navy)
    }
}
