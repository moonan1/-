package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.CheckCircle
import com.yaksok.pillbox.device.LinkState
import com.yaksok.pillbox.ui.components.AppSheet
import com.yaksok.pillbox.ui.components.SlotBadge
import com.yaksok.pillbox.ui.theme.AmberSoft
import com.yaksok.pillbox.ui.theme.Bg

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateListOf
import com.yaksok.pillbox.telehealth.CareConn
import com.yaksok.pillbox.telehealth.SYMPTOMS
import com.yaksok.pillbox.ui.components.PillightMark
import com.yaksok.pillbox.ui.theme.Amber
import com.yaksok.pillbox.ui.theme.Navy
import com.yaksok.pillbox.ui.theme.UnconfGray
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.ChatMessage
import com.yaksok.pillbox.data.MsgKind
import com.yaksok.pillbox.data.Prescription
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.domain.PrescriptionLogic
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.IconCircle
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.stamp
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintDark
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen

/** 의료진 탭: 메시지(빠른 답장), 복약 기록 보내기, 진료 요청, 처방 받기 */
@Composable
fun CareTab(vm: AppViewModel, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val tele by vm.care.collectAsStateWithLifecycle()
    val chat by tele.messages.collectAsStateWithLifecycle()
    val rxList by tele.prescriptions.collectAsStateWithLifecycle()
    val careStatus by tele.status.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var consult by remember { mutableStateOf(false) }
    var reviewing by remember { mutableStateOf<Prescription?>(null) }
    var putIn by remember { mutableStateOf<List<Pair<String, Int>>?>(null) }
    val st by vm.deviceStatus.collectAsStateWithLifecycle()
    val list = rememberLazyListState()
    val newRx = rxList.filter { it.status == RxStatus.NEW }
    LaunchedEffect(tele) { tele.start() }

    LaunchedEffect(chat.size) {
        val n = list.layoutInfo.totalItemsCount
        if (chat.isNotEmpty() && n > 0) list.animateScrollToItem(n - 1)
    }

    Column(modifier.fillMaxSize().imePadding()) {
        Text("의료진", style = MaterialTheme.typography.headlineLarge, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp))
        LazyColumn(
            Modifier.weight(1f), state = list,
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PillightMark(size = 52.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tele.doctor.name, style = MaterialTheme.typography.titleLarge)
                            val c = when (careStatus.conn) { CareConn.ONLINE -> OkGreen; CareConn.CONNECTING -> LateAmber; else -> MissRed }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(c))
                                Spacer(Modifier.width(6.dp))
                                Text(if (tele.isDemo) "시연용 가상 의료진" else careStatus.text, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Pill("시연용 · 실제 진료가 아니에요", LateAmber)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SoftButton("내 기록 보내기", onClick = { tele.sendReport() }, icon = Icons.AutoMirrored.Filled.Assignment, modifier = Modifier.weight(1f))
                        BigButton("진료 요청", onClick = { consult = true }, icon = Icons.Filled.VideoCall, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("'내 기록 보내기'를 누르면 최근 약 드신 기록을 의료진에게 보내요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
            }
            if (newRx.isNotEmpty()) item {
                AppCard(color = AmberSoft) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.Description, Mint)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("새 처방이 ${newRx.size}개 왔어요", style = MaterialTheme.typography.titleMedium, color = MintDark)
                            Text("확인하고 내 약통에 넣어 주세요", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    BigButton("처방 확인하기", onClick = { reviewing = newRx.first() }, modifier = Modifier.fillMaxWidth())
                }
            }
            if (!tele.isDemo && (careStatus.conn == CareConn.OFFLINE || careStatus.conn == CareConn.ERROR)) item {
                AppCard(color = MissRed.copy(alpha = 0.07f)) {
                    Text("의료진 서버에 연결할 수 없어요", style = MaterialTheme.typography.titleMedium, color = MissRed)
                    Text("인터넷 연결을 확인해 주세요. 시연 현장에서 인터넷이 안 되면 전체 › 시연 모드에서 '시연용 가상 의료진'으로 바꿀 수 있어요.",
                        style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                }
            }
            if (chat.isEmpty()) item {
                Text("궁금한 점을 남기거나 아래 빠른 답장을 눌러 보세요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft,
                    modifier = Modifier.padding(vertical = 20.dp))
            }
            items(chat, key = { it.id }) { m -> Bubble(m, rxList, now.toLocalDate()) { rx -> reviewing = rx } }
        }
        // 빠른 답장
        Row(
            Modifier.fillMaxWidth().background(Color.White).horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            QuickReply("네, 알겠어요") { tele.sendText("네, 알겠어요") }
            QuickReply("약 잘 먹고 있어요") { tele.sendText("약 잘 먹고 있어요") }
            QuickReply("약이 떨어져 가요") { tele.requestConsult(emptyList(), "약이 거의 떨어져서 다시 처방 받고 싶어요") }
            QuickReply("몸이 불편해요") { consult = true }
        }
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it.take(300) }, modifier = Modifier.weight(1f),
                placeholder = { Text("의료진에게 메시지") }, shape = RoundedCornerShape(18.dp), maxLines = 4,
                textStyle = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = { tele.sendText(input); input = "" }, enabled = input.isNotBlank(),
                modifier = Modifier.size(56.dp).clip(CircleShape).background(if (input.isNotBlank()) Mint else Line),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "보내기", tint = Color.White) }
        }
    }

    if (consult) ConsultDialog(onDismiss = { consult = false }) { sym, note -> tele.requestConsult(sym, note); consult = false }
    reviewing?.let { rx0 ->
        val rx = rxList.firstOrNull { it.id == rx0.id } ?: rx0
        PrescriptionDialog(rx, vm, onDismiss = { reviewing = null }, onApplied = { putIn = it })
    }
    putIn?.let { list -> PutInSheet(list, connected = st.link == LinkState.CONNECTED, onOpen = { vm.devices.refill(it) }, onDismiss = { putIn = null }) }
}

@Composable
private fun QuickReply(text: String, onClick: () -> Unit) {
    Box(
        Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50)).background(AmberSoft)
            .clickable { onClick() }.padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = MaterialTheme.typography.labelLarge, color = Navy) }
}

/** 처방을 넣은 뒤: "○번 칸에 넣어 주세요 → [넣었어요]" */
@Composable
private fun PutInSheet(items: List<Pair<String, Int>>, connected: Boolean, onOpen: (Int) -> Unit, onDismiss: () -> Unit) {
    val done = remember { mutableStateListOf<Int>() }
    AppSheet(onDismiss) {
        Text("약을 칸에 넣어 주세요", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text("약국에서 받은 약을 아래 칸에 넣고 '넣었어요'를 눌러 주세요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
        Spacer(Modifier.height(16.dp))
        items.forEachIndexed { i, (name, slot) ->
            val ok = i in done
            Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(18.dp)).background(if (ok) MintSoft else AmberSoft).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SlotBadge(slot, size = 56.dp, color = Navy)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${slot}번 칸에 넣어 주세요", style = MaterialTheme.typography.titleMedium)
                        Text(name, style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                    }
                    if (ok) Icon(Icons.Filled.CheckCircle, null, tint = Navy, modifier = Modifier.size(32.dp))
                }
                if (!ok) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (connected) SoftButton("칸 열기", onClick = { onOpen(slot) }, modifier = Modifier.weight(1f))
                        BigButton("넣었어요", onClick = { done.add(i) }, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        BigButton(if (done.size == items.size) "다 넣었어요" else "나중에 할게요", onClick = onDismiss,
            color = if (done.size == items.size) Navy else Color.White, contentColor = if (done.size == items.size) Color.White else InkSoft,
            modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun Bubble(m: ChatMessage, rxs: List<Prescription>, today: java.time.LocalDate, onRx: (Prescription) -> Unit) {
    if (m.kind == MsgKind.SYSTEM) {
        Text(m.text, style = MaterialTheme.typography.bodySmall, color = InkSoft, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 2.dp))
        return
    }
    val mine = !m.fromDoctor
    val fg = if (mine) Ink else Color.White
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            Column(
                Modifier.widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (mine) 20.dp else 6.dp, bottomEnd = if (mine) 6.dp else 20.dp))
                    .background(if (mine) Color.White else Navy)
                    .then(if (mine) Modifier.border(1.dp, Line, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 6.dp)) else Modifier)
                    .padding(14.dp),
            ) {
                val tag = when (m.kind) { MsgKind.REPORT -> "내 복약 기록"; MsgKind.CONSULT -> "진료 요청"; MsgKind.PRESCRIPTION -> "처방"; else -> null }
                if (tag != null) {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Amber).padding(horizontal = 12.dp, vertical = 4.dp)) {
                        Text(tag, style = MaterialTheme.typography.labelMedium, color = Navy)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                if (m.text.isNotBlank()) Text(m.text, style = MaterialTheme.typography.bodyLarge, color = fg)
                if (m.kind == MsgKind.PRESCRIPTION) {
                    val rx = rxs.firstOrNull { it.id == m.refId }
                    if (rx != null) {
                        rx.items.forEach { it2 ->
                            Text("• ${it2.name} ${it2.slot?.let { s -> "· ${s}번 칸" } ?: ""} · ${it2.times.sorted().joinToString(", ") { t -> hm(t) }}",
                                style = MaterialTheme.typography.bodyMedium, color = fg)
                        }
                        Spacer(Modifier.height(8.dp))
                        Pill(rx.status.label, when (rx.status) { RxStatus.NEW -> Amber; RxStatus.APPLIED -> OkGreen; RxStatus.DECLINED -> UnconfGray }, filled = true)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { onRx(rx) }, modifier = Modifier.heightIn(min = 48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Navy),
                        ) { Text(if (rx.status == RxStatus.NEW) "처방 확인하기" else "처방 보기", style = MaterialTheme.typography.labelLarge) }
                    }
                }
            }
            Text(stamp(m.at, today), style = MaterialTheme.typography.labelSmall, color = InkSoft, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
        }
    }
}

@Composable
private fun ConsultDialog(onDismiss: () -> Unit, onSend: (List<String>, String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<String>() }
    AppSheet(onDismiss) {
        Text("진료 요청", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text("불편한 곳을 눌러 고르고, 하고 싶은 말을 적어 주세요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
        Spacer(Modifier.height(14.dp))
        SYMPTOMS.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                row.forEach { sym ->
                    val sel = sym in picked
                    Box(
                        Modifier.weight(1f).heightIn(min = 52.dp).clip(RoundedCornerShape(50))
                            .background(if (sel) Navy else Color.White).border(1.dp, if (sel) Navy else Line, RoundedCornerShape(50))
                            .clickable { if (sel) picked.remove(sym) else picked.add(sym) },
                        contentAlignment = Alignment.Center,
                    ) { Text(sym, color = if (sel) Color.White else Ink, style = MaterialTheme.typography.labelLarge) }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(text, { text = it.take(200) }, placeholder = { Text("예: 약이 거의 떨어졌어요") },
            modifier = Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(14.dp), textStyle = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        Text("급하면 119에 전화하세요.", style = MaterialTheme.typography.bodyLarge, color = MissRed)
        Spacer(Modifier.height(14.dp))
        BigButton("요청 보내기", onClick = { onSend(picked.toList(), text) }, enabled = picked.isNotEmpty() || text.isNotBlank(), modifier = Modifier.fillMaxWidth())
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("취소", color = InkSoft, style = MaterialTheme.typography.labelLarge) }
    }
}

/** 처방 확인 → 새 약은 빈 칸 지정 → "내 약통에 넣기" (자동 적용하지 않음) */
@Composable
private fun PrescriptionDialog(rx: Prescription, vm: AppViewModel, onDismiss: () -> Unit, onApplied: (List<Pair<String, Int>>) -> Unit) {
    val d by vm.data.collectAsStateWithLifecycle()
    val needs = remember(rx.id, d.meds) { PrescriptionLogic.itemsNeedingSlot(d, rx) }
    val free = PrescriptionLogic.freeSlots(d)
    val choice = remember(rx.id) {
        mutableStateMapOf<Int, Int>().apply {
            // 의료진이 지정한 칸이 비어 있으면 그 칸, 아니면 남은 빈 칸 순서대로
            needs.forEach { idx -> rx.items[idx].slot?.takeIf { it in free && it !in values }?.let { put(idx, it) } }
            needs.filter { it !in keys }.forEach { idx -> free.firstOrNull { it !in values }?.let { put(idx, it) } }
        }
    }
    val editable = rx.status == RxStatus.NEW
    val ready = needs.all { choice[it] != null } && choice.values.toSet().size == choice.size
    AppSheet(onDismiss) {
        Text("처방 내용", style = MaterialTheme.typography.headlineSmall)
        Text("${rx.doctor.name} · ${rx.issuedAt.toLocalDate()} ${hm(rx.issuedAt)}", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rx.items.forEachIndexed { i, item ->
                val existing = PrescriptionLogic.matchExisting(d.meds, item)
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Bg).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        Pill(if (existing != null) "${existing.slot}번 칸 약 바뀜" else "새 약", if (existing != null) Mint else LateAmber)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("한 번에 ${item.pillsPerDose}정 · ${weekdayText(item.weekdays)}", style = MaterialTheme.typography.bodyLarge)
                    Text(PrescriptionLogic.periodsText(item), style = MaterialTheme.typography.bodyLarge)
                    Text(when {
                        item.startDate != null -> "${item.startDate}부터" + (item.endDate?.let { " ${it}까지" } ?: "")
                        item.durationDays > 0 -> "${item.durationDays}일 동안"
                        else -> "계속"
                    }, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    if (item.note.isNotBlank()) Text("의료진 메모: ${item.note}", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                    if (editable && existing == null) {
                        Spacer(Modifier.height(10.dp))
                        val asked = item.slot
                        if (asked != null && asked !in free) Text("의료진이 고른 ${asked}번 칸에는 이미 다른 약이 있어요. 빈 칸을 골라 주세요.",
                            style = MaterialTheme.typography.bodyMedium, color = MissRed)
                        Text(if (asked != null && asked in free) "넣을 칸 (의료진이 고른 칸: ${asked}번)" else "넣을 칸을 골라 주세요", style = MaterialTheme.typography.labelLarge, color = InkSoft)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                            if (free.isEmpty()) Text("빈 칸이 없어요. 전체 › 내 약 관리에서 칸을 비워 주세요.", color = MissRed, style = MaterialTheme.typography.bodyMedium)
                            free.forEach { s ->
                                val sel = choice[i] == s
                                val usedByOther = choice.any { (k, v) -> k != i && v == s }
                                Box(
                                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))
                                        .background(if (sel) Mint else Color.White)
                                        .border(1.dp, if (sel) Mint else Line, RoundedCornerShape(14.dp))
                                        .clickable(enabled = !usedByOther) { choice[i] = s },
                                    contentAlignment = Alignment.Center,
                                ) { Text("$s", color = if (sel) Color.White else if (usedByOther) Line else Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        if (editable) {
            Text("넣으면 약 먹는 시간이 저장되고 약통에도 알려 줘요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            Spacer(Modifier.height(12.dp))
            BigButton(
                "내 약통에 넣기", enabled = ready, modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val slots = rx.items.mapIndexedNotNull { i, item ->
                        val slot = PrescriptionLogic.matchExisting(d.meds, item)?.slot ?: choice[i]
                        slot?.let { item.name to it }
                    }
                    vm.applyPrescription(rx, choice.toMap()); onDismiss(); onApplied(slots)
                },
            )
            TextButton(onClick = { vm.declinePrescription(rx); onDismiss() }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                Text("넣지 않을게요", color = InkSoft, style = MaterialTheme.typography.labelLarge)
            }
        } else {
            Text("이 처방은 '${rx.status.label}' 상태예요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("닫기", style = MaterialTheme.typography.labelLarge) }
        }
    }
}
