package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import com.yaksok.pillbox.ui.components.AppSheet
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.SoftButton
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.domain.DoseStatus
import com.yaksok.pillbox.domain.canConfirm
import com.yaksok.pillbox.domain.delayMinutes
import com.yaksok.pillbox.domain.status
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.InfoRow
import com.yaksok.pillbox.ui.components.Pill
import com.yaksok.pillbox.ui.components.SlotBadge
import com.yaksok.pillbox.ui.components.StatusChip
import com.yaksok.pillbox.ui.dateLong
import com.yaksok.pillbox.ui.hm
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.statusColor
import java.time.Duration
import java.time.LocalDateTime

/** 복용 회차 한 줄 */
@Composable
fun DoseRow(r: DoseRecord, now: LocalDateTime, onConfirm: (() -> Unit)?, onClick: () -> Unit) {
    val s = r.status(now)
    AppCard(onClick = onClick, padding = 16.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(66.dp)) {
                Text(hm(r.time), style = MaterialTheme.typography.titleLarge, color = statusColor(s))
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.medName, style = MaterialTheme.typography.titleMedium)
                    if (r.isTest) { Spacer(Modifier.width(6.dp)); Pill("테스트", LateAmber) }
                }
                Text("${r.slot}번 칸 · ${r.pills}정", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                Spacer(Modifier.padding(top = 4.dp))
                StatusChip(s)
            }
            if (onConfirm != null && r.canConfirm(now)) {
                Button(
                    onClick = onConfirm,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.heightIn(min = 56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint),
                ) { Text("먹었어요", style = MaterialTheme.typography.labelLarge) }
            } else {
                SlotBadge(r.slot, size = 46.dp, color = statusColor(s))
            }
        }
    }
}

/** 회차 상세 (바텀시트) */
@Composable
fun DoseDetailDialog(r: DoseRecord, now: LocalDateTime, onConfirm: () -> Unit, onUndo: () -> Unit, onDismiss: () -> Unit) {
    val s = r.status(now)
    AppSheet(onDismiss) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SlotBadge(r.slot, size = 60.dp, color = statusColor(s))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(r.medName, style = MaterialTheme.typography.headlineSmall)
                Text(dateLong(r.date), style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
        }
        Spacer(Modifier.height(12.dp))
        StatusChip(s)
        Spacer(Modifier.height(8.dp))
        InfoRow("먹을 시각", hm(r.time))
        InfoRow("칸 · 개수", "${r.slot}번 칸 · ${r.pills}정")
        InfoRow("칸이 열린 시각", r.openedAt?.let { hm(it) } ?: "없음")
        InfoRow("먹었어요 누른 시각", r.confirmedAt?.let { hm(it) + if (r.confirmSource == "notification") " (알림에서)" else "" } ?: "-")
        r.delayMinutes()?.let { InfoRow("늦은 시간", if (it == 0L) "제때 드셨어요" else "${it}분", valueColor = if (s == DoseStatus.LATE) LateAmber else Mint) }
        if (r.openedAt != null && r.confirmedAt == null) {
            Spacer(Modifier.height(6.dp))
            Text("칸이 열린 것만으로는 드신 걸로 치지 않아요. 드셨다면 '먹었어요'를 눌러 주세요.", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
        }
        Spacer(Modifier.height(18.dp))
        when {
            r.canConfirm(now) -> BigButton("먹었어요", onClick = { onConfirm(); onDismiss() }, icon = Icons.Filled.CheckCircle, modifier = Modifier.fillMaxWidth())
            r.confirmedAt != null -> SoftButton("잘못 눌렀어요 (먹었어요 취소)", onClick = { onUndo(); onDismiss() }, color = InkSoft, modifier = Modifier.fillMaxWidth())
            else -> Unit
        }
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("닫기", color = InkSoft, style = MaterialTheme.typography.labelLarge) }
    }
}

/** 언제 먹었는지 고르기: 약통이 열린 지 5분 넘었으면 '열렸을 때 먹었어요'를 고를 수 있게 함 */
@Composable
fun ConfirmTimeDialog(r: DoseRecord, now: LocalDateTime, onPick: (LocalDateTime) -> Unit, onDismiss: () -> Unit) {
    val opened = r.openedAt ?: return
    AppSheet(onDismiss) {
        Text("언제 드셨어요?", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("${r.slot}번 칸이 ${hm(opened)}에 열렸어요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
        Spacer(Modifier.height(18.dp))
        BigButton("열렸을 때(${hm(opened)}) 먹었어요", onClick = { onPick(opened); onDismiss() }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        SoftButton("방금(${hm(now)}) 먹었어요", onClick = { onPick(now); onDismiss() }, modifier = Modifier.fillMaxWidth())
        TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("취소", color = InkSoft, style = MaterialTheme.typography.labelLarge) }
    }
}

fun needsTimeChoice(r: DoseRecord, now: LocalDateTime): Boolean =
    r.openedAt != null && Duration.between(r.openedAt, now).toMinutes() >= 5

@Composable
fun StrongText(text: String, color: Color = MaterialTheme.colorScheme.onSurface) =
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
