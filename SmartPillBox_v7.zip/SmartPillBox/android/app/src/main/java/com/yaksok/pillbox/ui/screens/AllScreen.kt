package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.Overlay
import com.yaksok.pillbox.data.CareMode
import com.yaksok.pillbox.data.DataMode
import com.yaksok.pillbox.device.LinkState
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.ConfirmDialog
import com.yaksok.pillbox.ui.components.MenuGroup
import com.yaksok.pillbox.ui.components.MenuRow
import com.yaksok.pillbox.ui.components.PILLIGHT_SLOGAN
import com.yaksok.pillbox.ui.components.PillightLogo
import com.yaksok.pillbox.ui.components.SectionTitle
import com.yaksok.pillbox.ui.components.Segmented
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.components.TopBar
import com.yaksok.pillbox.ui.theme.Amber
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.UnconfGray

/** 전체 탭: 약 관리, 약통 연결, 알림, 보기 설정, 시연 모드 */
@Composable
fun AllScreen(vm: AppViewModel, open: (Overlay) -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val st by vm.deviceStatus.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val big by vm.bigText.collectAsStateWithLifecycle()
    val voice by vm.voice.collectAsStateWithLifecycle()
    var about by remember { mutableStateOf(false) }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { Text("전체", style = MaterialTheme.typography.headlineLarge) }
        item {
            MenuGroup {
                MenuRow(Icons.Filled.Medication, "내 약 관리", "약 ${d.meds.size}개 · 칸마다 약 1가지", onClick = { open(Overlay.Meds) })
                MenuRow(
                    Icons.Filled.Link, "약통 연결",
                    if (st.link == LinkState.CONNECTED) "연결돼 있어요" else "연결 안 됨 · 눌러서 연결해 주세요",
                    color = if (st.link == LinkState.CONNECTED) Mint else UnconfGray,
                    onClick = { open(Overlay.Device) },
                )
                MenuRow(Icons.Filled.Notifications, "알림 설정", if (d.notif.enabled) "알림 켜짐" else "알림 꺼짐", onClick = { open(Overlay.Settings) })
                MenuRow(Icons.Filled.Insights, "자세한 분석", "시간대·요일별 습관, 알림 바꾼 내역", onClick = { open(Overlay.Analysis) })
            }
        }
        item { SectionTitle("보기 편하게") }
        item {
            MenuGroup {
                MenuRow(Icons.Filled.TextFields, "큰 글씨", "글씨를 더 크게 보여 드려요", trailing = {
                    Switch(checked = big, onCheckedChange = { vm.setBigText(it) }, colors = SwitchDefaults.colors(checkedTrackColor = Mint))
                })
                MenuRow(Icons.AutoMirrored.Filled.VolumeUp, "소리로 안내", "약 드실 시간에 소리로 읽어 드려요", trailing = {
                    Switch(checked = voice, onCheckedChange = { vm.setVoice(it); if (it) vm.speak("소리 안내를 켰어요.") }, colors = SwitchDefaults.colors(checkedTrackColor = Mint))
                })
            }
        }
        item { SectionTitle("발표 · 시연") }
        item {
            MenuGroup {
                MenuRow(Icons.Filled.Science, "시연 모드", if (mode == DataMode.DEMO) "켜짐 · 연습용 데이터를 보고 있어요" else "데이터 · 의료진 연결 방식 바꾸기",
                    color = if (mode == DataMode.DEMO) LateAmber else Mint, onClick = { open(Overlay.Demo) })
                MenuRow(Icons.Filled.Info, "앱 정보", "Pillight 1.3", onClick = { about = !about })
            }
        }
        if (about) item {
            AppCard {
                PillightLogo(markSize = 34.dp)
                Spacer(Modifier.height(4.dp))
                Text(PILLIGHT_SLOGAN, style = MaterialTheme.typography.bodyLarge, color = InkSoft)
                Spacer(Modifier.height(8.dp))
                Text("복약 분석과 알림 제안은 정해진 규칙으로 동작하며, 의학적 판단이나 약 양 변경을 권하지 않아요. 약 먹는 시각·양은 의사·약사와 상의하세요.",
                    style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
        }
    }
}

/** 시연 모드: 데이터(실제/시연), 의료진 연결 방식, 약통 연결 방식 */
@Composable
fun DemoModeScreen(vm: AppViewModel, open: (Overlay) -> Unit, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val mode by vm.mode.collectAsStateWithLifecycle()
    val kind by vm.deviceKind.collectAsStateWithLifecycle()
    var confirmReset by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize()) {
        TopBar("시연 모드", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("발표·테스트할 때 쓰는 설정이에요. 평소에는 바꿀 필요가 없어요.", style = MaterialTheme.typography.bodyLarge, color = InkSoft)
            SectionTitle("보여 줄 데이터")
            AppCard {
                Segmented(DataMode.entries.map { it.label }, DataMode.entries.indexOf(mode), { vm.switchMode(DataMode.entries[it]) })
                Spacer(Modifier.height(10.dp))
                Text(
                    if (mode == DataMode.DEMO) "발표용 시연 데이터(30일치)를 보고 있어요. 실제 복용 기록과 별도 파일에 저장되어 섞이지 않아요."
                    else "실제 복용 기록을 보고 있어요. 로그인 없이 이 휴대폰에만 저장돼요.",
                    style = MaterialTheme.typography.bodyMedium, color = InkSoft,
                )
                if (mode == DataMode.DEMO) {
                    Spacer(Modifier.height(10.dp))
                    SoftButton("시연 데이터 오늘 기준으로 다시 만들기", onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth(), color = LateAmber)
                }
            }

            SectionTitle("의료진 연결")
            AppCard {
                val careMode by vm.careMode.collectAsStateWithLifecycle()
                val pid by vm.patientId.collectAsStateWithLifecycle()
                var idDraft by remember(pid) { mutableStateOf(pid) }
                var nameDraft by remember { mutableStateOf(vm.patientName) }
                var idError by remember { mutableStateOf<String?>(null) }
                Text("의료진 연결 방식", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(6.dp))
                Segmented(CareMode.entries.map { it.label }, CareMode.entries.indexOf(careMode), { vm.setCareMode(CareMode.entries[it]) })
                Spacer(Modifier.height(6.dp))
                Text(
                    if (careMode == CareMode.REALTIME) "Pillight 의료진 웹페이지와 실시간으로 메시지·처방을 주고받아요. 인터넷이 필요해요."
                    else "인터넷 없이 앱 안의 가상 의료진이 정해진 문구로 답해요. 시연 현장에서 인터넷이 안 될 때 쓰세요.",
                    style = MaterialTheme.typography.bodySmall, color = InkSoft,
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = idDraft, onValueChange = { idDraft = it.trim().take(40); idError = null }, singleLine = true,
                    label = { Text("환자 ID") }, modifier = Modifier.fillMaxWidth(), isError = idError != null,
                    supportingText = { Text(idError ?: "영문·숫자·-·_ 3~40자 · 의료진 화면에서 이 ID로 대화가 묶여요") },
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = nameDraft, onValueChange = { nameDraft = it.take(20) }, singleLine = true,
                    label = { Text("환자 이름 (의료진에게 보이는 이름)") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                BigButton(
                    "저장", modifier = Modifier.fillMaxWidth(), enabled = idDraft != pid || nameDraft != vm.patientName,
                    onClick = {
                        if (!vm.setPatientId(idDraft)) idError = "환자 ID는 영문·숫자·-·_ 3~40자로 입력해 주세요."
                        else { vm.patientName = nameDraft.ifBlank { "김하늘" }; nameDraft = vm.patientName }
                    },
                )
            }

            SectionTitle("약통 연결 방식")
            MenuGroup {
                MenuRow(Icons.Filled.Link, "약통 연결 방식 · 테스트", "지금: ${kind.label} (USB · 블루투스 · 노트북 중계 · 가상 약통)", onClick = { open(Overlay.Device) })
            }
        }
    }
    if (confirmReset) ConfirmDialog(
        "시연 데이터 다시 만들기", "시연 데이터를 오늘 기준 30일치로 새로 만들어요. 실제 데이터에는 영향이 없어요.", "다시 만들기",
        onConfirm = { vm.resetDemo() }, onDismiss = { confirmReset = false },
    )
}
