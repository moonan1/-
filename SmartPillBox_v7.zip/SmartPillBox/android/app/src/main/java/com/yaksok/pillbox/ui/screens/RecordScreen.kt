package com.yaksok.pillbox.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Insights
import androidx.compose.foundation.layout.width
import com.yaksok.pillbox.Overlay
import com.yaksok.pillbox.domain.Suggestion
import com.yaksok.pillbox.domain.SuggestionEngine
import com.yaksok.pillbox.ui.components.BigButton
import com.yaksok.pillbox.ui.components.ConfirmDialog
import com.yaksok.pillbox.ui.components.IconCircle
import com.yaksok.pillbox.ui.components.MenuGroup
import com.yaksok.pillbox.ui.components.MenuRow
import com.yaksok.pillbox.ui.components.MoreFold
import com.yaksok.pillbox.ui.components.SoftButton
import com.yaksok.pillbox.ui.theme.AmberSoft
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yaksok.pillbox.data.DoseRecord
import com.yaksok.pillbox.domain.Analytics
import com.yaksok.pillbox.domain.DayStat
import com.yaksok.pillbox.domain.Summary
import com.yaksok.pillbox.domain.koreanDay
import com.yaksok.pillbox.domain.pct
import com.yaksok.pillbox.ui.AppViewModel
import com.yaksok.pillbox.ui.components.AppCard
import com.yaksok.pillbox.ui.components.BarItem
import com.yaksok.pillbox.ui.components.BarSegment
import com.yaksok.pillbox.ui.components.EmptyState
import com.yaksok.pillbox.ui.components.Legend
import com.yaksok.pillbox.ui.components.Segmented
import com.yaksok.pillbox.ui.components.StackedBarChart
import com.yaksok.pillbox.ui.dateLong
import com.yaksok.pillbox.ui.dateShort
import com.yaksok.pillbox.ui.theme.Ink
import com.yaksok.pillbox.ui.theme.InkSoft
import com.yaksok.pillbox.ui.theme.LateAmber
import com.yaksok.pillbox.ui.theme.Line
import com.yaksok.pillbox.ui.theme.MissRed
import com.yaksok.pillbox.ui.theme.Mint
import com.yaksok.pillbox.ui.theme.MintSoft
import com.yaksok.pillbox.ui.theme.OkGreen
import com.yaksok.pillbox.ui.theme.UnconfGray
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.roundToInt

private fun dayColor(s: DayStat): Color? = when {
    s.summary.total == 0 -> null
    s.summary.missed > 0 -> MissRed
    s.summary.unconfirmed > 0 -> UnconfGray
    s.summary.late > 0 -> LateAmber
    else -> Mint
}

private fun segments(s: Summary) = listOf(
    BarSegment(s.onTime.toFloat(), Mint),
    BarSegment(s.late.toFloat(), LateAmber),
    BarSegment(s.unconfirmed.toFloat(), UnconfGray),
    BarSegment(s.missed.toFloat(), MissRed),
)

/** 기록 탭: 숫자 1개 + 문장 1개 → 알림 제안 1장 → 달력 → 그날 기록 */
@Composable
fun RecordScreen(vm: AppViewModel, open: (Overlay) -> Unit, modifier: Modifier = Modifier) {
    val d by vm.data.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val today = now.toLocalDate()
    var range by remember { mutableStateOf(0) }
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var selected by remember { mutableStateOf(today) }
    var detail by remember { mutableStateOf<DoseRecord?>(null) }
    var timeChoice by remember { mutableStateOf<DoseRecord?>(null) }
    var applying by remember { mutableStateOf<Suggestion?>(null) }
    val a = remember(d.records, now) { Analytics(d.records, now) }
    val suggestion = remember(d, now) { SuggestionEngine.suggestions(d, now).firstOrNull() }

    val week = a.summaryLast(7)
    val prevWeek = a.summaryLast(7, endOffset = 7)
    val weak = a.weakestPeriod(7)
    val oneLine = when {
        week.total == 0 -> "약을 드시면 여기에 기록이 쌓여요."
        weak != null && weak.summary.missedLike > 0 -> "${weak.period.label} 약을 자주 놓치셨어요."
        weak != null && weak.summary.late > 0 -> "${weak.period.label} 약을 자주 늦게 드셨어요."
        week.adherence != null && prevWeek.adherence != null && week.adherence!! > prevWeek.adherence!! + 0.02 -> "지난주보다 더 잘 드시고 계세요."
        else -> "이대로만 하시면 돼요. 잘하고 계세요!"
    }

    val summary = if (range == 0) week else a.summaryLast(30)
    val bars: List<BarItem> = if (range == 0) {
        val days = a.daily(today.minusDays(6), today)
        val max = days.maxOfOrNull { it.summary.total + it.pending }?.toFloat() ?: 0f
        days.map { ds ->
            BarItem(
                label = koreanDay(ds.date.dayOfWeek), segments = segments(ds.summary), max = max,
                caption = ds.summary.adherence?.let { pct(it) } ?: "", highlight = ds.date == today,
            )
        }
    } else {
        val weeks = (4 downTo 0).map { w ->
            val end = today.minusDays(w * 7L)
            val start = end.minusDays(6)
            Triple(start, end, a.summarize(a.range(start, end)))
        }
        val max = weeks.maxOfOrNull { it.third.total }?.toFloat() ?: 0f
        weeks.map { (s, _, sum) -> BarItem(dateShort(s) + "~", segments(sum), max, sum.adherence?.let { pct(it) } ?: "", highlight = false) }
    }
    val confirm: (DoseRecord) -> Unit = { r -> if (needsTimeChoice(r, now)) timeChoice = r else vm.confirm(r.key) }
    val dayRecords = d.records.filter { it.date == selected }.sortedBy { it.time }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Text("기록", style = MaterialTheme.typography.headlineLarge) }
        // 숫자 1개 + 문장 1개
        item {
            AppCard(padding = 22.dp) {
                Text("이번 주", style = MaterialTheme.typography.titleMedium, color = InkSoft)
                if (week.total == 0) {
                    Text("아직 기록이 없어요", style = MaterialTheme.typography.headlineMedium)
                } else {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(pct(week.adherence), style = MaterialTheme.typography.displaySmall, color = Mint, fontWeight = FontWeight.Bold)
                        Text(" 잘 드셨어요", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 6.dp))
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(oneLine, style = MaterialTheme.typography.bodyLarge, color = if (weak != null) LateAmber else InkSoft)
                Spacer(Modifier.height(6.dp))
                MoreFold {
                    Segmented(listOf("최근 7일", "최근 30일"), range, { range = it })
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CountBox("제때", summary.onTime, Mint, Modifier.weight(1f))
                        CountBox("늦게", summary.late, LateAmber, Modifier.weight(1f))
                        CountBox("못 드심", summary.missed, MissRed, Modifier.weight(1f))
                        CountBox("모름", summary.unconfirmed, UnconfGray, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(16.dp))
                    StackedBarChart(bars, chartHeight = 150.dp)
                    Spacer(Modifier.height(10.dp))
                    Legend(listOf("제때" to Mint, "늦게" to LateAmber, "모름" to UnconfGray, "못 드심" to MissRed))
                    Spacer(Modifier.height(10.dp))
                    Text("'모름'은 칸은 열렸지만 '먹었어요'를 누르지 않은 경우예요.", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
            }
        }
        // 스마트 제안 1장
        if (suggestion != null) item {
            AppCard(color = AmberSoft) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle(Icons.Filled.AutoAwesome, Mint, size = 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("알림을 이렇게 바꿔 볼까요?", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(10.dp))
                Text(suggestion.message, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(4.dp))
                Text(suggestion.changeSummary, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SoftButton("괜찮아요", onClick = { vm.dismiss(suggestion) }, modifier = Modifier.weight(1f), color = InkSoft)
                    BigButton("바꿀게요", onClick = { applying = suggestion }, modifier = Modifier.weight(1.3f))
                }
            }
        }
        item {
            CalendarCard(
                month = month, today = today, selected = selected, stats = a.daily(month.atDay(1), month.atEndOfMonth()).associateBy { it.date },
                onPrev = { month = month.minusMonths(1) },
                onNext = { if (month < YearMonth.from(today)) month = month.plusMonths(1) },
                onSelect = { selected = it },
            )
        }
        item { Text(if (selected == today) "오늘" else dateLong(selected), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 4.dp)) }
        if (dayRecords.isEmpty()) item { AppCard { EmptyState(Icons.Filled.EventBusy, "기록이 없어요", "이 날은 드실 약이 없었어요.") } }
        items(dayRecords, key = { it.key }) { r -> DoseRow(r, now, onConfirm = { confirm(r) }, onClick = { detail = r }) }
        item {
            MenuGroup {
                MenuRow(Icons.Filled.Insights, "자세한 분석 보기", "시간대·요일별 습관, 알림 바꾼 내역", onClick = { open(Overlay.Analysis) })
            }
        }
    }

    detail?.let { r0 ->
        val r = d.records.firstOrNull { it.key == r0.key } ?: r0
        DoseDetailDialog(r, now, onConfirm = { confirm(r) }, onUndo = { vm.undoConfirm(r.key) }, onDismiss = { detail = null })
    }
    timeChoice?.let { r -> ConfirmTimeDialog(r, now, onPick = { vm.confirm(r.key, it) }, onDismiss = { timeChoice = null }) }
    applying?.let { s ->
        ConfirmDialog(
            title = "알림 바꾸기", text = "${s.changeSummary}\n\n약 먹는 시각과 약통이 열리는 시각은 그대로예요.",
            confirmText = "바꿀게요", onConfirm = { vm.accept(s) }, onDismiss = { applying = null },
        )
    }
}

@Composable
private fun CountBox(label: String, n: Int, color: Color, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.1f)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("$n", style = MaterialTheme.typography.titleLarge, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

@Composable
private fun CalendarCard(
    month: YearMonth, today: LocalDate, selected: LocalDate, stats: Map<LocalDate, DayStat>,
    onPrev: () -> Unit, onNext: () -> Unit, onSelect: (LocalDate) -> Unit,
) {
    AppCard(padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrev, modifier = Modifier.size(52.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "이전 달") }
            Text("${month.year}년 ${month.monthValue}월", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "다음 달") }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            listOf(DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY).forEach {
                Text(koreanDay(it), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium,
                    color = when (it) { DayOfWeek.SUNDAY -> MissRed; DayOfWeek.SATURDAY -> Color(0xFF3D7DD8); else -> InkSoft })
            }
        }
        val first = month.atDay(1)
        val lead = first.dayOfWeek.value % 7   // 일요일 시작
        val cells = lead + month.lengthOfMonth()
        val rows = (cells + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val idx = r * 7 + c - lead + 1
                    if (idx < 1 || idx > month.lengthOfMonth()) { Spacer(Modifier.weight(1f).aspectRatio(1f)); continue }
                    val date = month.atDay(idx)
                    val st = stats[date]
                    val dot = st?.let { dayColor(it) }
                    val sel = date == selected
                    val future = date.isAfter(today)
                    Column(
                        Modifier.weight(1f).aspectRatio(0.9f).padding(2.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (sel) MintSoft else Color.Transparent)
                            .then(if (date == today) Modifier.border(1.5.dp, Mint, RoundedCornerShape(12.dp)) else Modifier)
                            .clickable(enabled = !future) { onSelect(date) },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                    ) {
                        Text("$idx", style = MaterialTheme.typography.bodyLarge, color = if (future) Line else Ink, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.size(9.dp).clip(CircleShape).background(dot ?: Color.Transparent))
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Legend(listOf("다 드심" to Mint, "늦게" to LateAmber, "모름" to UnconfGray, "못 드심" to MissRed))
    }
}
