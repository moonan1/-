plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.yaksok.pillbox"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.yaksok.pillbox"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "1.3"

        // 식약처 의약품 정보 인증키: GitHub Secret(DATA_GO_KR_KEY) 또는 local.properties(dataGoKrKey)에서 빌드 시 주입
        val localKey = rootProject.file("local.properties").takeIf { it.exists() }?.readLines()
            ?.firstOrNull { it.startsWith("dataGoKrKey=") }?.substringAfter("=")?.trim()
        val dataKey = (System.getenv("DATA_GO_KR_KEY") ?: localKey ?: "").trim().replace("\"", "")
        buildConfigField("String", "DATA_GO_KR_KEY", "\"$dataKey\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.06.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    // Pillight 의료진 실시간 연결 (Firestore)
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-firestore")
    // USB 유선 연결 (Arduino UNO: ATmega16U2 / CH340 / FTDI / CP210x)
    implementation("com.github.mik3y:usb-serial-for-android:3.8.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
