# Pillight 인수인계 자료 (2026-11-20 기준)

> 새 대화에서 이 파일과 `SmartPillBox_handoff.zip`을 같이 첨부하고 "이 인수인계 자료 보고 이어서 해줘"라고 하면 됩니다.

## 1. 프로젝트 한 줄 요약
대학교 공학설계 프로젝트 **Pillight**: 아두이노 우노 기반 **6칸 스마트 약통** + 안드로이드 연동 앱 + **실시간 원격 진료(의사 웹페이지)**. 대상은 노약자. 핵심 규칙은 "정해진 시간에 정해진 칸만 열고 나머지는 닫힘 유지".

## 2. 현재 상태 (완료된 것)
| 영역 | 상태 |
|---|---|
| 앱 v6 (versionName 1.2) | 빌드·설치·실시간 채팅 확인 완료 (노트9 Android 10) |
| 실시간 원격 진료 | Firestore로 앱 ↔ 의사 웹 양방향 동작 확인, 처방 전송·적용 흐름 있음 |
| 약 검색 | 식약처 공공데이터 API(e약은요·허가정보·DUR) + "직접 등록하기" |
| 펌웨어 ver7 | 호스트 테스트 43개 통과, BT 모드 테스트 통과 (실기 6서보는 아직) |
| ESP32 블루투스 브릿지 | 코드·배선도 완성, **실제 보드 미검증** |
| 배선도 | 1칸용 `docs/1칸_배선도.png`, 6칸용 `docs/6칸_배선도.png` |

## 3. 다음에 할 일 (요청 대기 중)
**앱 UI 개편 — 노약자 대상, 토스 느낌으로 정돈** (사용자에게 제안만 했고 아직 미구현)
- 우선순위 높음
  1. 하단 탭 4개로 정리: **오늘 / 기록 / 의료진 / 전체** (지금은 홈 pager 좌우 스와이프 + 여러 화면)
  2. 오늘 탭 맨 위 "지금 먹을 약 + [먹었어요]" 큰 카드, 없으면 "다음 약은 ○시예요"
  3. 문구 쉬운 말로 (예: 복용 이행률 → "이번 주 86% 잘 드셨어요", 미복용 → "못 드셨어요", 처방 적용 → "내 약통에 넣기")
  4. 기술 용어 숨기기: 기기 연결(USB/노트북 중계/시뮬레이션)·데모 데이터는 "시연 모드" 안으로, 기기 연결은 전체 탭으로
  5. 스마트 제안 탭 → 기록 탭의 카드 1장, 그래프 → 숫자 1개 + 문장 1개 (자세히 보기로 접기)
  6. 약 정보 3줄 요약 + 더 보기
- 여유 있으면: 보호자 알림(2시간 미복용 시), 큰 글씨 모드(18sp+, 버튼 56dp+), TTS 음성 안내, 의료진 채팅 빠른 답장 버튼, 약 떨어짐 → 재처방 요청, 처방 적용 시 "○번 칸에 넣어 주세요 → [넣었어요]" 단계
- 디자인: 카드 하나 = 정보 하나, 색 3개(남색 기본/앰버 강조/빨강 경고), 팝업 대신 바텀시트, 여백 넉넉히
- 기능·데이터 구조·Firestore 구조는 그대로 유지 (시연 흐름 깨지면 안 됨)

## 4. 하드웨어
- 아두이노 우노, DS1302 RTC, SG90 **360° 연속회전** 서보 6개, 부저(선택), ESP32 DevKit **WROOM-32 (CH340)**, 10kΩ 저항 3개, 빵판 1개, 점퍼선, 보조배터리. 뚜껑 감지 센서 없음.
- **5V 어댑터 없음** → 서보 6개를 우노 5V로 구동. 펌웨어가 한 번에 1개, 0.2초만 돌리고 detach해서 가능. ESP32는 **자기 USB로 별도 전원**(VIN 비움), GND만 공통.
- 핀
  | 기능 | 우노 핀 |
  |---|---|
  | 서보 칸1~6 (주황) | D3, D6, D7, D8, D10, D11 |
  | RTC CLK / DAT / RST | D5 / D4 / D2 |
  | 부저 + | D9 |
  | BT(SoftwareSerial) RX / TX | A0 / A1 |
- 우노 ↔ ESP32: 우노 A0 ← ESP32 **D25**(TX, 저항 없이). 우노 A1 → 10k → ★ → ESP32 **D26**(RX), ★ → 10k → 10k → GND (5V→3.3V 분압). 빵판 18↔22↔25↔28번 줄, 22번=★, 28번→GND. 220Ω는 사용 안 함.
- ESP32 블루투스 이름 **Pillight-Box**, 클래식 SPP(UUID 00001101-…), 우노와 9600bps. 연결 시 보드 LED(GPIO2) 켜짐.

## 5. 펌웨어 (firmware/)
- `PillBox_ver7/PillBox_ver7.ino` 기본(USB만), `PillBox_ver7_BT/PillBox_ver7_BT.ino` = 같은 코드에 `USE_BT 1`(USB+BT 동시, 출력 미러링).
- 줄 단위 시리얼 프로토콜 9600, `#id` 명령 / `@id` 응답, 중복 id 재실행 안 함. 명령: HELLO, STATUS, TIME, SB/SE/SC(스케줄), GETSCHED, LOG, REOPEN, TAKEN, REFILL, CLOSE, STOP, RECOVER. 자세한 건 `docs/PROTOCOL.md`.
- EEPROM 2뱅크+CRC, 이벤트 링 로그 24개, Fletcher-16 스케줄 체크섬, 닫기 우선 순차 구동, 동작 중 정전 시 RECOVERY, 놓친 스케줄 몰아서 실행 안 함.
- `SERVO_CONTINUOUS 1`, OPEN/CLOSE_RUN_MS = 200ms(칸별 조정 가능).
- 호스트 테스트: `firmware/host_test/` (g++ + mock). `runner.cpp`는 앱 ↔ 펌웨어 E2E용.
- `firmware/ESP32_Bridge/ESP32_Bridge.ino`: BluetoothSerial ↔ Serial2(RX=26, TX=25).
- `tools/pillbox_bridge.py`: 노트북 TCP:8765 ↔ 시리얼 중계(예전 방식).

## 6. 안드로이드 앱 (android/)
- Kotlin + Jetpack Compose(Material3). AGP 8.11.1, Kotlin 2.2.0, Compose BOM 2025.06.00, compile/target 36, min 26. 패키지 **com.yaksok.pillbox**(유지), 앱 이름 **Pillight**.
- 저장: 로컬 JSON(org.json) `AppRepository`/`JsonCodec`. 알림: AlarmManager(`notify/Notifications.kt`).
- 연결 방식 `DeviceKind`: SIMULATION / USB(usb-serial-for-android 3.8.1) / BLUETOOTH(SPP, 페어링된 기기 목록) / LAPTOP(TCP). `DeviceManager`가 시간·로그·스케줄 동기화.
- 주요 파일
  - `domain/DoseLogic.kt` 판정 규칙: 정시 = 예정+10분 이내 확인, 확인 가능 = 예정 −60분 ~ +120분, 2시간 지나면 미복용(칸 열렸으면 "확인되지 않음"). 복용 확인은 사용자 "복용 완료" 버튼만(뚜껑 센서 없음).
  - `domain/Analytics.kt` 이행률·시간대(아침4–10/점심11–15/저녁16–20/밤)·요일 패턴. `domain/Suggestions.kt` 알림 제안 규칙 3개(알림 설정만 변경, 승인 필요, 거절 7일 숨김).
  - `domain/Prescriptions.kt` 처방 적용/거절/리포트 payload.
  - `drug/DrugApi.kt` 식약처 API. 키는 `BuildConfig.DATA_GO_KR_KEY`.
  - `telehealth/Telehealth.kt` 인터페이스 + `DemoTelehealth`(가상 의료진), `telehealth/FirestoreTelehealth.kt` 실시간.
  - UI: `ui/screens/` HomeScreen(pager: PillboxPage ↔ CarePage), PillboxViews(6칸 그림·CompartmentSheet), CareScreen, MedsScreen/MedEdit, DrugViews, HistoryScreen, SmartScreen, DeviceScreen, SettingsScreen. 테마 `ui/theme/Theme.kt`, 로고 `ui/components/Brand.kt`.
- 브랜드: 남색 #14213D, 앰버 #F6B93B, 배경 #F7F5EF, 선 #E8E4D8, 캡슐 로고, 슬로건 "처방부터 복용까지, 환하게 연결". 환자 말풍선 흰색+테두리, 의사 말풍선 남색+흰 글씨, 앰버 태그. "시연용 · 실제 진료가 아니에요" 배지 유지.

## 7. 실시간 원격 진료 (Firebase)
- Firebase 프로젝트 **yaksok-demo**, `android/app/google-services.json` 포함. 로그인 없음(시연용).
- 의사 웹: **https://fastidious-youtiao-00c94e.netlify.app** (원본 `docs/doctor-web/index.html`, Netlify 배포). PC·아이패드 브라우저 OK.
- Firestore 구조 (웹과 동일해야 함, 바꾸지 말 것)
  ```
  patients/{환자ID} { name, lastText, updatedAt }
  patients/{환자ID}/messages/{자동ID} {
    from: "patient"|"doctor", kind: "text"|"report"|"request"|"prescription",
    text, payload(map|null), createdAt(serverTimestamp),
    status: "sent"|"applied"|"declined"   // 처방만
  }
  처방 payload.items[] { name, slot(1~6), doseCount, times["08:00"], days[1~7], startDate, endDate, memo }
  리포트 payload { adherence7, adherence30, avgDelayMin, missed, weakSlot, meds[{name,slot,times}] }
  ```
- 앱 설정: 의료진 연결 모드 실시간/시연용 가상 의료진, 환자 ID 기본 `demo-patient-1`(정규식 `^[A-Za-z0-9_-]{3,40}$`), 이름 기본 김하늘. 오프라인 시 "의료진 서버에 연결할 수 없어요".
- 처방은 자동 적용 금지, 사용자가 승인해야 적용. 의료 조언 생성 안 함.

## 8. 빌드·배포 방법 (안드로이드 스튜디오 없이)
- GitHub 저장소 **moonan1/-** (public, 사용자 선택). 내장 브라우저에서 moonan1로 로그인돼 있음.
- 방법: 프로젝트를 `SmartPillBox_vN.zip`(최상위 폴더 `SmartPillBox/`)으로 묶어 저장소 루트에 업로드 → `.github/workflows/build-apk.yml`이 가장 높은 버전 zip(`ls *.zip | sort -V | tail -1`)을 풀어 `assembleDebug` → 아티팩트 `yaksok-apk`(app-debug.apk).
- 다음 zip 이름은 **SmartPillBox_v7.zip**부터.
- data.go.kr 키는 GitHub Secret **DATA_GO_KR_KEY**에서 주입(워크플로가 첫 유효 토큰만 추출). **키를 코드나 공개 저장소에 넣지 말 것.** 로컬은 `local.properties`의 `dataGoKrKey=`.
- 주의: 빌드마다 디버그 서명 키가 달라서 **기존 앱 삭제 후 설치**해야 함(서명 고정은 아직 안 함 — 원하면 고정 debug keystore 추가).
- 사용자 PC: Windows, 사용자 폴더 `C:\Users\무난`(바탕화면·다운로드 접근 허용했었음). 내장 브라우저 다운로드는 `.tmp`로 남는 경우가 있어 크기로 새 파일 판별했음.
- 샌드박스에는 Android SDK·네트워크가 없어서 내장 kotlinc + org.json 스텁으로 문법 검증 후 GitHub Actions로 빌드했음.

## 9. 테스트 기기·사용자 정보
- 테스트 폰: 갤럭시 노트9(Android 10, 메인 시연용), 갤럭시 S26 울트라(Android 17, One UI 9.0). 사용자 본인 폰은 아이폰(APK 설치 불가) → 아이폰/아이패드는 의사 웹 역할.
- 팀원 공유용: `Pillight-v6.apk` + 웹 링크, zip(`Pillight-v6.zip`)으로도 배포함.
- 사용자는 결론부터 짧게 듣는 걸 선호.

## 10. 첨부 파일 안내
`SmartPillBox_handoff.zip` = 전체 소스(앱·펌웨어·ESP32·도구·문서·배선도·의사 웹 원본) + 이 문서.

---
## v7 (앱 1.3) 변경 — 노약자용 UI 개편 (2026-11-20)
- 하단 탭 4개: 오늘 / 기록 / 의료진 / 전체 (홈 pager 제거)
- 오늘: 맨 위 "지금 드실 약 + [먹었어요]" 큰 카드, 없으면 "다음 약은 ○시예요", 소리로 듣기
- 기록: "이번 주 86% 잘 드셨어요" + 문장 1개, 그래프는 '자세히 보기'로 접음, 알림 제안 카드 1장, 달력
- 의료진: 빠른 답장(네 알겠어요/약 잘 먹고 있어요/약이 떨어져 가요/몸이 불편해요), 처방 "내 약통에 넣기" → "○번 칸에 넣어 주세요 → [넣었어요]"
- 전체: 내 약 관리, 약통 연결, 알림 설정, 자세한 분석, 큰 글씨, 소리 안내, 시연 모드(데이터·의료진 연결·약통 연결 방식)
- 팝업 → 바텀시트, 색 3개(남색/앰버/빨강), 상태 문구 쉬운 말(먹었어요/못 드셨어요/늦게 먹었어요 등)
- 약 정보 3줄 요약(어디에/어떻게/주의) + 더 보기
- 기능·데이터·Firestore 구조는 그대로. 보호자 알림은 미구현.
