package com.yaksok.pillbox.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yaksok.pillbox.ui.theme.Amber
import com.yaksok.pillbox.ui.theme.Navy

const val PILLIGHT_SLOGAN = "처방부터 복용까지, 환하게 연결"

/** Pillight 로고 마크: 남색 원 위 비스듬한 캡슐(반쪽 흰색, 반쪽 호박색) + 작은 반짝임 */
@Composable
fun PillightMark(modifier: Modifier = Modifier, size: Dp = 40.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        drawCircle(Navy)
        val cw = w * 0.56f
        val ch = w * 0.24f
        val left = (w - cw) / 2
        val top = (w - ch) / 2 + w * 0.03f
        rotate(-35f, pivot = Offset(w / 2, w / 2 + w * 0.03f)) {
            clipRect(left, top, left + cw / 2, top + ch) {
                drawRoundRect(Color.White, Offset(left, top), Size(cw, ch), CornerRadius(ch / 2, ch / 2))
            }
            clipRect(left + cw / 2, top, left + cw, top + ch) {
                drawRoundRect(Amber, Offset(left, top), Size(cw, ch), CornerRadius(ch / 2, ch / 2))
            }
        }
        // 반짝임 (네 갈래 별)
        val cx = w * 0.72f; val cy = w * 0.27f; val r = w * 0.09f; val k = r * 0.3f
        val star = Path().apply {
            moveTo(cx, cy - r); lineTo(cx + k, cy - k); lineTo(cx + r, cy); lineTo(cx + k, cy + k)
            lineTo(cx, cy + r); lineTo(cx - k, cy + k); lineTo(cx - r, cy); lineTo(cx - k, cy - k); close()
        }
        drawPath(star, Amber)
    }
}

/** 글자 로고: "Pill"(남색/흰색) + "ight"(호박색) */
@Composable
fun PillightWordmark(onDark: Boolean = false, fontSize: TextUnit = 22.sp) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = if (onDark) Color.White else Navy, fontWeight = FontWeight.ExtraBold)) { append("Pill") }
            withStyle(SpanStyle(color = Amber, fontWeight = FontWeight.ExtraBold)) { append("ight") }
        },
        fontSize = fontSize, style = MaterialTheme.typography.titleLarge,
    )
}

@Composable
fun PillightLogo(modifier: Modifier = Modifier, markSize: Dp = 30.dp, onDark: Boolean = false) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        PillightMark(size = markSize)
        Spacer(Modifier.width(8.dp))
        PillightWordmark(onDark = onDark, fontSize = (markSize.value * 0.72f).sp)
    }
}
