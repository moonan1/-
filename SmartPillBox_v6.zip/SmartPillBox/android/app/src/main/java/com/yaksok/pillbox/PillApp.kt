@file:OptIn(FlowPreview::class)

package com.yaksok.pillbox

import android.app.Application
import com.yaksok.pillbox.data.AppRepository
import com.yaksok.pillbox.device.DeviceManager
import com.yaksok.pillbox.drug.DrugApi
import com.yaksok.pillbox.notify.AlarmScheduler
import com.yaksok.pillbox.notify.Notifier
import com.yaksok.pillbox.data.CareMode
import com.yaksok.pillbox.telehealth.DemoTelehealth
import com.yaksok.pillbox.telehealth.FirestoreTelehealth
import com.yaksok.pillbox.telehealth.TelehealthService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch

class PillApp : Application() {
    lateinit var repo: AppRepository
        private set
    lateinit var devices: DeviceManager
        private set
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    /** 의료진 소통: 실시간(Firestore) / 시연용 가상 의료진 */
    lateinit var demoCare: DemoTelehealth
        private set
    lateinit var realCare: FirestoreTelehealth
        private set
    lateinit var care: StateFlow<TelehealthService>
        private set
    /** 식약처 의약품 정보 (키는 빌드 시 주입) */
    val drugApi by lazy { DrugApi(BuildConfig.DATA_GO_KR_KEY) }

    override fun onCreate() {
        super.onCreate()
        repo = AppRepository(this)
        repo.loadBlocking()
        Notifier.ensureChannels(this)
        devices = DeviceManager(this, repo, appScope)
        demoCare = DemoTelehealth(appScope, repo.data) { f -> repo.update(f) }
        realCare = FirestoreTelehealth(this, repo.data, { repo.patientId.value }, { repo.patientName }) { m ->
            Notifier.showCare(this, m.text.ifBlank { "새 메시지가 왔어요" })
        }
        care = repo.careMode.map<CareMode, TelehealthService> { if (it == CareMode.REALTIME) realCare else demoCare }
            .stateIn(appScope, SharingStarted.Eagerly, if (repo.careMode.value == CareMode.REALTIME) realCare as TelehealthService else demoCare)
        // 실시간 모드에서는 앱이 살아 있는 동안 계속 구독 (백그라운드 알림용). 환자 ID가 바뀌면 다시 구독
        appScope.launch {
            combine(repo.careMode, repo.patientId) { m, id -> m to id }.collect { (m, _) ->
                if (m == CareMode.REALTIME) realCare.start() else realCare.stop()
            }
        }

        // 데이터가 바뀌면 다음 알림 다시 예약
        appScope.launch {
            repo.data.debounce(500).collect { AlarmScheduler.reschedule(this@PillApp, it, repo.lastAlarmCheck) }
        }
        // 자정이 지나면 새 날짜의 복용 회차 생성
        appScope.launch {
            while (true) { delay(60_000); repo.ensureToday() }
        }
    }
}
