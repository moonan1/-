package com.yaksok.pillbox.telehealth

import com.yaksok.pillbox.data.AppData
import com.yaksok.pillbox.data.ChatMessage
import com.yaksok.pillbox.data.Doctor
import com.yaksok.pillbox.data.MsgKind
import com.yaksok.pillbox.data.Prescription
import com.yaksok.pillbox.data.RxItem
import com.yaksok.pillbox.data.RxStatus
import com.yaksok.pillbox.domain.PrescriptionLogic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.UUID

enum class CareConn { CONNECTING, ONLINE, OFFLINE, ERROR }

data class CareStatus(val conn: CareConn, val text: String = "")

/** 진료 요청 화면의 증상 선택지 */
val SYMPTOMS = listOf("두통", "어지럼", "메스꺼움", "복통", "피로", "불면", "기침", "발열", "가려움", "기타")

/**
 * 의료진 소통 · 원격 처방 서비스.
 *  - FirestoreTelehealth: Pillight 의료진 웹페이지와 Firebase로 실시간 연결
 *  - DemoTelehealth: 인터넷 없는 시연용 가상 의료진 (정해진 문구로만 응답)
 */
interface TelehealthService {
    val doctor: Doctor
    val isDemo: Boolean
    val messages: StateFlow<List<ChatMessage>>
    val prescriptions: StateFlow<List<Prescription>>
    val status: StateFlow<CareStatus>
    fun start()
    fun stop()
    fun sendText(text: String)
    fun sendReport()
    fun requestConsult(symptoms: List<String>, note: String)
    /** 처방 반영/거절 결과를 의료진 쪽에 알린다 */
    fun setPrescriptionStatus(rx: Prescription, status: RxStatus)
}

class DemoTelehealth(
    private val scope: CoroutineScope,
    data: StateFlow<AppData>,
    private val update: suspend ((AppData) -> AppData) -> Unit,
) : TelehealthService {
    override val doctor = Doctor("Pillight 의료진", "시연용 가상 의료진", "내과")
    override val isDemo = true
    override val messages: StateFlow<List<ChatMessage>> = data.map { it.chat }.stateIn(scope, SharingStarted.Eagerly, data.value.chat)
    override val prescriptions: StateFlow<List<Prescription>> = data.map { it.prescriptions }.stateIn(scope, SharingStarted.Eagerly, data.value.prescriptions)
    private val current = data
    private val _status = MutableStateFlow(CareStatus(CareConn.ONLINE, "시연용 가상 의료진"))
    override val status: StateFlow<CareStatus> = _status.asStateFlow()

    override fun start() {}
    override fun stop() {}

    private fun msg(fromDoctor: Boolean, text: String, kind: MsgKind = MsgKind.TEXT, ref: String? = null) =
        ChatMessage(UUID.randomUUID().toString(), LocalDateTime.now(), fromDoctor, text, kind, ref)

    private fun post(m: ChatMessage) = scope.launch { update { it.copy(chat = it.chat + m) } }

    private fun replyLater(ms: Long, text: String) = scope.launch {
        delay(ms)
        update { it.copy(chat = it.chat + msg(true, text)) }
    }

    override fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        post(msg(false, t))
        replyLater(2500, autoReply(t))
    }

    override fun sendReport() {
        post(msg(false, PrescriptionLogic.buildReport(current.value, LocalDateTime.now()), MsgKind.REPORT))
        replyLater(3000, "복약 리포트 잘 받았어요. 다음 진료 때 함께 살펴볼게요.")
    }

    override fun requestConsult(symptoms: List<String>, note: String) {
        post(msg(false, consultText(symptoms, note), MsgKind.CONSULT))
        scope.launch {
            delay(3000)
            update { it.copy(chat = it.chat + msg(true, "진료 요청 확인했어요. 복약 기록을 보고 처방을 보내드릴게요.")) }
            delay(4000)
            val rx = Prescription(UUID.randomUUID().toString(), LocalDateTime.now(), doctor, demoItems(current.value))
            update { d ->
                d.copy(
                    prescriptions = d.prescriptions + rx,
                    chat = d.chat + msg(true, "처방전을 보냈어요. 약국에서 약을 받으신 뒤 확인하고 약통 칸에 넣어 주세요.", MsgKind.PRESCRIPTION, rx.id),
                )
            }
        }
    }

    // 시연 모드에서는 PrescriptionLogic이 로컬 데이터의 상태를 이미 바꾼다
    override fun setPrescriptionStatus(rx: Prescription, status: RxStatus) {}

    private fun demoItems(d: AppData): List<RxItem> {
        if (d.meds.isEmpty()) return listOf(RxItem("혈압약", 1, listOf(LocalTime.of(8, 0)), DayOfWeek.entries.toSet(), 30, "아침 식후"))
        return d.meds.sortedBy { it.slot }.map { RxItem(it.name, it.pillsPerDose, it.times, it.weekdays, 30, it.memo) }
    }

    companion object {
        fun consultText(symptoms: List<String>, note: String) = buildString {
            append("비대면 진료 요청")
            if (symptoms.isNotEmpty()) append("\n증상: ").append(symptoms.joinToString(", "))
            if (note.isNotBlank()) append("\n요청: ").append(note.trim())
        }

        /** 정해진 안내 문구만 사용 (의학적 조언을 만들지 않음) */
        fun autoReply(t: String): String {
            val emergency = listOf("숨", "가슴", "의식", "쓰러", "호흡", "마비")
            val symptom = listOf("부작용", "어지", "두통", "메스", "구토", "발진", "아파", "아픈", "통증", "가려")
            return when {
                emergency.any { t.contains(it) } -> "응급 증상이라면 지금 바로 119에 연락하거나 가까운 응급실로 가세요. 이 채팅은 응급 상황에 실시간으로 대응하지 못해요."
                symptom.any { t.contains(it) } -> "증상을 알려주셔서 감사해요. 진료 시간에 확인하고 답변드릴게요. 그전에 약을 임의로 끊거나 양을 바꾸지 마시고, 증상이 심해지면 바로 병원에 연락해 주세요."
                else -> "메시지 확인했어요. 진료 시간(평일 9시~18시)에 답변드릴게요."
            }
        }
    }
}
